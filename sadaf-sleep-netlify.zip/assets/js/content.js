/* ============================================================
   SADAF SLEEP — EDITORIAL CONTENT
   Materials & technologies, sleep guide, FAQ, showrooms, about
   ============================================================ */

/* ---------- MATERIALS & TECHNOLOGIES (12) ---------- */
window.MATERIALS = [
  {
    id: 'pocket',
    num: '01',
    name: { en: 'Pocket Spring', ar: 'النوابض الجيبية', ku: 'سپرینی گیرفانی' },
    what: {
      en: 'A spring system in which every individual spring is sewn into its own fabric pocket, then joined into a single unit.',
      ar: 'نظام نوابض يُخاط فيه كل نابض على حدة داخل جيب قماشي خاص، ثم تُوصل الوحدات معاً في وحدة واحدة.',
      ku: 'سیستەمێکی سپرین کە هەر سپرینێک بە جیا لە گیرفانێکی قوماشیدا دەدروورا و دواتر دەکرێنە یەک یەکە.'
    },
    how: {
      en: 'Because each spring moves independently, the surface responds locally: the parts under your shoulders and hips compress without pulling the rest of the mattress down with them.',
      ar: 'لأن كل نابض يتحرك باستقلال، يستجيب السطح موضعياً: تنضغط الأجزاء تحت كتفيك ووركيك دون أن تسحب بقية السرير معها.',
      ku: 'چونکە هەر سپرینێک بە سەربەخۆیی دەجووڵێت، ڕووکە بە شێوەی خۆجێیی وەڵام دەداتەوە: ئەو بەشانەی ژێر شان و کەمەرت دەگوشێن بەبێ ئەوەی هەموو دۆشەکەکە لەگەڵ خۆیاندا بخەنە خوارەوە.'
    },
    chars: {
      en: ['Local support', 'Motion isolation', 'Air movement through the core', 'Progressive resistance'],
      ar: ['دعم موضعي', 'عزل الحركة', 'حركة هواء في القلب', 'مقاومة تدريجية'],
      ku: ['پاڵپشتی خۆجێیی', 'جیاکردنەوەی جووڵە', 'جووڵەی هەوا لە ناوەند', 'بەرگری پلەپلە']
    },
    why: {
      en: 'It is the most effective way to combine support with contouring. In Silver Tech and Biolatex the system is doubled — two 1500C units — for added depth; other models use a single 1000C unit.',
      ar: 'إنها الطريقة الأكثر فاعلية للجمع بين الدعم ومجاراة الجسم. في سيلفر تك وبيولاتكس يتضاعف النظام — وحدتا 1500C — لمزيد من العمق، بينما تستخدم نماذج أخرى وحدة 1000C واحدة.',
      ku: 'کاریگەرترین ڕێگایە بۆ کۆکردنەوەی پاڵپشتی لەگەڵ گونجان لەگەڵ لەش. لە سیلڤەر تێک و بیولاتێکس سیستەمەکە دوو هێندەیە — دوو یەکەی 1500C — بۆ قووڵی زیاتر؛ مۆدێلەکانی تر یەک یەکەی 1000C بەکاردەهێنن.'
    },
    usedIn: ['silver-tech', 'biolatex', 'thermo-memory', 'four-seasons', 'biolux', 'rabbit-comfort', 'luxerest', 'luna']
  },
  {
    id: 'latex',
    num: '02',
    name: { en: 'Natural Latex', ar: 'اللاتكس الطبيعي', ku: 'لاتێکسی سروشتی' },
    what: {
      en: 'A foam made from natural rubber sap, used as a resilient comfort layer rather than a synthetic polyurethane foam.',
      ar: 'إسفنج مصنوع من عصارة المطاط الطبيعية، يُستخدم كطبقة راحة مرنة بدل الإسفنج الصناعي.',
      ku: 'فۆمێک کە لە شیراوی لاستیکی سروشتی دروست دەکرێت و وەک چینی ئاسوودەیی فنەر بەکاردێت لە جیاتی فۆمی دەستکرد.'
    },
    how: {
      en: 'Latex is elastic: it compresses where you press and returns immediately. That makes it conform to the body without letting you sink into it.',
      ar: 'اللاتكس مطاطي: ينضغط حيث تضغط ويعود فوراً، فيجاري الجسم دون أن تغرق فيه.',
      ku: 'لاتێکس کشۆڵەیە: لە شوێنی گوشار دەگوشێت و خێرا دەگەڕێتەوە، بۆیە لەگەڵ لەش دەگونجێت بەبێ ئەوەی نوقمی بیت.'
    },
    chars: {
      en: ['Resilient and springy', 'Naturally breathable', 'Durable recovery', 'Vegetable-origin material'],
      ar: ['مرن ونابض', 'قابل للتنفس طبيعياً', 'استعادة عالية للشكل', 'مادة ذات أصل نباتي'],
      ku: ['فنەر و بەهێز', 'بە سروشتی هەناسەدەر', 'گەڕانەوەی بەردەوام', 'کەرەستەی سەرچاوە ڕوەکی']
    },
    why: {
      en: 'It gives soft mattresses support without making them feel dead. Biolatex uses natural latex as its main comfort layer.',
      ar: 'يمنح الأسرّة الناعمة دعماً دون أن يجعلها عديمة الاستجابة. يستخدم بيولاتكس اللاتكس الطبيعي كطبقة راحة رئيسية.',
      ku: 'پاڵپشتی بە دۆشەک نەرمەکان دەدات بەبێ ئەوەی بێهەست بن. بیولاتێکس لاتێکسی سروشتی وەک چینی ئاسوودەیی سەرەکی بەکاردەهێنێت.'
    },
    usedIn: ['biolatex']
  },
  {
    id: 'horsehair',
    num: '03',
    name: { en: 'Horsehair', ar: 'شعر الخيل', ku: 'مووی ئەسپ' },
    what: {
      en: 'A natural filling made from crimped horsehair, historically one of the most respected materials in premium mattress-making.',
      ar: 'حشوة طبيعية من شعر الخيل المموج، وهي تاريخياً من أكثر المواد تقديراً في صناعة الأسرّة الفاخرة.',
      ku: 'پڕکەرەوەیەکی سروشتی لە مووی چەماوەی ئەسپ، کە بە مێژوویی یەکێکە لە ڕێزدارترین کەرەستەکان لە دروستکردنی دۆشەکی لوکسدا.'
    },
    how: {
      en: 'The crimped fibres do not pack flat, so they leave open channels for air. The layer stays springy and lets heat and moisture move away from the body.',
      ar: 'لا تنضغط الألياف المموجة بشكل مستوٍ، فتُبقي قنوات مفتوحة للهواء. تبقى الطبقة نابضة وتسمح للحرارة والرطوبة بالابتعاد عن الجسم.',
      ku: 'ڕیشاڵە چەماوەکان بە تەختى پەستێن نابن، بۆیە کەناڵی کراوە بۆ هەوا دەهێڵنەوە. چینەکە فنەر دەمێنێتەوە و ڕێگە بە گەرمی و شێ دەدات لە لەش دوور بکەوێتەوە.'
    },
    chars: {
      en: ['Open, breathable structure', 'Natural resilience', 'Temperature-neutral', 'Long-established material'],
      ar: ['بنية مفتوحة قابلة للتنفس', 'مرونة طبيعية', 'محايد حرارياً', 'مادة عريقة'],
      ku: ['پێکهاتەی کراوە و هەناسەدەر', 'فنەری سروشتی', 'بێ لایەنگری گەرمی', 'کەرەستەی کۆن و ناسراو']
    },
    why: {
      en: 'It is the natural answer to overheating — a breathable layer that also adds body to a soft surface. Found in Biolatex.',
      ar: 'إنها الإجابة الطبيعية لارتفاع الحرارة — طبقة قابلة للتنفس تمنح السطح الناعم امتلاءً أيضاً. موجودة في بيولاتكس.',
      ku: 'وەڵامی سروشتییە بۆ گەرمی زیادە — چینێکی هەناسەدەر کە قەبارەش بە ڕووی نەرم زیاد دەکات. لە بیولاتێکسدا هەیە.'
    },
    usedIn: ['biolatex']
  },
  {
    id: 'memory',
    num: '04',
    name: { en: 'Memory Foam', ar: 'إسفنج الذاكرة', ku: 'فۆمی بیرگە' },
    what: {
      en: 'A viscoelastic foam that softens with body heat and slowly returns to its original shape.',
      ar: 'إسفنج لزج مرن يلين بحرارة الجسم ويعود ببطء إلى شكله الأصلي.',
      ku: 'فۆمێکی لینج و کشۆڵە کە بە گەرمی لەش نەرم دەبێت و بە هێواشی دەگەڕێتەوە بۆ شێوەی سەرەکی.'
    },
    how: {
      en: 'Under warmth and weight it moulds around your outline, spreading contact pressure across a larger area instead of concentrating it at the hips and shoulders.',
      ar: 'تحت الحرارة والوزن يتشكل حول حدود جسمك، فيوزع ضغط التلامس على مساحة أكبر بدل تركيزه عند الوركين والكتفين.',
      ku: 'لە ژێر گەرمی و کێشدا لەگەڵ شێوەی لەشت دەگونجێت و گوشاری پەیوەندی بەسەر ڕووبەرێکی گەورەتردا دابەش دەکات لە جیاتی چڕکردنەوەی لە کەمەر و شان.'
    },
    chars: {
      en: ['Deep pressure distribution', 'Slow, enveloping response', 'Low motion transfer', 'Soft first contact'],
      ar: ['توزيع عميق للضغط', 'استجابة بطيئة ومحيطة', 'نقل حركة منخفض', 'تلامس أولي ناعم'],
      ku: ['دابەشکردنی قووڵی گوشار', 'وەڵامدانەوەی هێواش و گشتگیر', 'گواستنەوەی کەمی جووڵە', 'پەیوەندی یەکەمی نەرم']
    },
    why: {
      en: 'For sleepers who feel pressure at the shoulders and hips. Thermo Memory uses gel memory foam; Neocomfort uses Gel Fusion memory foam.',
      ar: 'لمن يشعر بالضغط عند الكتفين والوركين. يستخدم ثيرمو ميموري إسفنج الذاكرة بالجل، ويستخدم نيو كومفورت إسفنج Gel Fusion.',
      ku: 'بۆ ئەو کەسانەی گوشار لە شان و کەمەردا هەست پێدەکەن. تێرمۆ مێمۆری فۆمی بیرگەی جێل بەکاردەهێنێت و نیو کۆمفۆرت فۆمی بیرگەی Gel Fusion.'
    },
    usedIn: ['thermo-memory', 'neocomfort']
  },
  {
    id: 'pcm',
    num: '05',
    name: { en: 'PCM', ar: 'PCM — مادة تغيّر الطور', ku: 'PCM — کەرەستەی گۆڕەری قۆناغ' },
    what: {
      en: 'PCM stands for phase change material: a substance that absorbs and releases heat as it changes between solid and liquid states at skin temperature.',
      ar: 'PCM اختصار لمادة تغيّر الطور: مادة تمتص الحرارة وتحررها عند تحولها بين الحالة الصلبة والسائلة في نطاق حرارة الجلد.',
      ku: 'PCM کورتەبۆ کەرەستەی گۆڕەری قۆناغ: ماددەیەک کە گەرمی هەڵدەمژێت و بەری دەداتەوە کاتێک لە نێوان باروی ڕەق و شلدا دەگۆڕێت لە پلەی گەرمی پێست.'
    },
    how: {
      en: 'When the surface starts to warm up, the PCM absorbs part of that heat; as it cools again, the stored heat is released. It buffers temperature swings instead of letting them build.',
      ar: 'عندما يبدأ السطح بالدفء، تمتص المادة جزءاً من الحرارة؛ وعندما يبرد، تُحرَّر الحرارة المخزنة. بهذا تخفف تقلبات الحرارة بدل أن تسمح بتراكمها.',
      ku: 'کاتێک ڕووکە دەست دەکات بە گەرمبوون، PCM بەشێک لەو گەرمییە هەڵدەمژێت؛ و کاتێک سارد دەبێتەوە، گەرمی هەڵگیرساو بەری دەداتەوە. بەم شێوەیە گۆڕانەکانی گەرمی کەم دەکاتەوە.'
    },
    chars: {
      en: ['Temperature buffering', 'Works at skin temperature', 'No power required', 'Used in the surface layer'],
      ar: ['تخفيف تقلبات الحرارة', 'يعمل في نطاق حرارة الجلد', 'بدون طاقة', 'يُستخدم في الطبقة السطحية'],
      ku: ['کەمکردنەوەی گۆڕانی گەرمی', 'کار لە پلەی گەرمی پێست دەکات', 'بێ وزە', 'لە چینی ڕووی سەرەوە بەکاردێت']
    },
    why: {
      en: 'It is the clearest technology we offer for sleepers who overheat. Found in Thermo Memory, directly under the quilted surface.',
      ar: 'إنها أوضح تقنية نقدمها لمن يشعرون بالحرارة الزائدة. موجودة في ثيرمو ميموري، تحت السطح المبطّن مباشرة.',
      ku: 'ڕوونترین تەکنەلۆژیایە کە پێشکەشی دەکەین بۆ ئەو کەسانەی گەرمیان لێدێت. لە تێرمۆ مێمۆریدا هەیە، ڕاستەوخۆ لە ژێر ڕووی چنارەکراو.'
    },
    usedIn: ['thermo-memory']
  },
  {
    id: 'silver',
    num: '06',
    name: { en: 'Silver Ions', ar: 'أيونات الفضة', ku: 'زیو ئایۆن' },
    what: {
      en: 'Silver ions are incorporated into the cover fabric, where they act on the surface of the textile rather than in the fill.',
      ar: 'تُدمج أيونات الفضة في قماش الغطاء، حيث تعمل على سطح النسيج لا في الحشوة.',
      ku: 'زیو ئایۆن لە قوماشی ڕووپۆشدا دانراون و لە ڕووی پارچەکەدا کار دەکەن، نەک لە پڕکەرەوەکە.'
    },
    how: {
      en: 'The ions are bound into the fibre, so the property belongs to the fabric itself and does not wash out in the way a topical coating would.',
      ar: 'ترتبط الأيونات بالألياف، فتصبح الخاصية جزءاً من القماش نفسه ولا تزول بالغسل كما يحدث مع الطلاء السطحي.',
      ku: 'ئایۆنەکان بە ڕیشاڵەکەوە بەستراوەتەوە، بۆیە تایبەتمەندییەکە بەشێکە لە قوماشەکە و بە شوشتن ناڕوات وەک چۆن پۆشینی ڕووکە دەڕوات.'
    },
    chars: {
      en: ['Antibacterial fabric treatment', 'Confirmed 99.9% figure for the Silver Tech cover', 'Part of the fibre, not a coating', 'Hygiene-focused'],
      ar: ['معالجة مضادة للبكتيريا للقماش', 'نسبة مؤكدة ٩٩.٩٪ لغطاء سيلفر تك', 'جزء من الألياف لا طلاء سطحي', 'تركيز على النظافة'],
      ku: ['چارەسەری دژە بەکتریا بۆ قوماش', 'ڕێژەی ٩٩.٩٪ بۆ ڕووپۆشی سیلڤەر تێک', 'بەشێک لە ڕیشاڵەکە نەک پۆشین', 'سەرنج لەسەر پاکوخاوێنی']
    },
    why: {
      en: 'Hygiene matters most in the layer closest to you. Silver Tech is the model built around it.',
      ar: 'النظافة أهم ما تكون في الطبقة الأقرب إليك. سيلفر تك هو النموذج المبني حولها.',
      ku: 'پاکوخاوێنی زیاتر لەو چینەدا گرنگە کە لە نزیکترین لە تۆیە. سیلڤەر تێک ئەو مۆدێلەیە کە لەسەر ئەم بنیات نراوە.'
    },
    usedIn: ['silver-tech']
  },
  {
    id: 'rock-salt',
    num: '07',
    name: { en: 'Rock Salt', ar: 'الملح الصخري', ku: 'خوێی بەرد' },
    what: {
      en: 'A mineral salt used in the linen cover of Biolatex as part of the model’s natural material story.',
      ar: 'ملح معدني يُستخدم في غطاء الكتان في بيولاتكس كجزء من هوية النموذج القائمة على المواد الطبيعية.',
      ku: 'خوێیەکی کانزایی کە لە ڕووپۆشی کەتانی بیولاتێکسدا بەکاردێت وەک بەشێک لە ناسنامەی کەرەستەی سروشتی ئەم مۆدێلە.'
    },
    how: {
      en: 'It is integrated into the linen fabric itself, giving Biolatex a distinctive mineral-finish surface rather than a synthetic sheen.',
      ar: 'يُدمج في قماش الكتان نفسه، فيمنح بيولاتكس سطحاً مميزاً بلمسة معدنية بدل اللمعان الصناعي.',
      ku: 'لە خۆی قوماشی کەتانییەکەدا تێکەڵ کراوە، بۆیە ڕوویەکی کانزایی جیاواز بە بیولاتێکس دەبەخشێت لە جیاتی درەوشانەوەی دەستکرد.'
    },
    chars: {
      en: ['Mineral-finished linen', 'Natural material direction', 'Pairs with latex and horsehair', 'Distinctive hand-feel'],
      ar: ['كتان بلمسة معدنية', 'اتجاه المواد الطبيعية', 'يُلازم اللاتكس وشعر الخيل', 'ملمس مميز'],
      ku: ['کەتانی بە دەنگی کانزایی', 'ئاراستەی کەرەستەی سروشتی', 'لەگەڵ لاتێکس و مووی ئەسپ دێت', 'دەستێکی جیاواز']
    },
    why: {
      en: 'Biolatex is our most natural build, and every layer of it follows that logic — including the cover.',
      ar: 'بيولاتكس هو أكثر بنياتنا طبيعية، وكل طبقة فيه تتبع هذا المنطق — بما في ذلك الغطاء.',
      ku: 'بیولاتێکس سروشتیترین پێکهاتەمانە و هەر چینێکی شوێن ئەم لۆژیکە دەکەوێت — لەگەڵ ڕووپۆشەکەش.'
    },
    usedIn: ['biolatex']
  },
  {
    id: 'icetech',
    num: '08',
    name: { en: 'Ice Tech', ar: 'تقنية Ice', ku: 'تەکنیکی ساردی' },
    what: {
      en: 'The cooling side of a reversible mattress: a surface engineered to feel cooler to the touch in warm weather.',
      ar: 'الجانب المبرد في سرير قابل للقلب: سطح مصمم ليبدو أكثر برودة عند اللمس في الطقس الحار.',
      ku: 'لای ساردکەرەوەی دۆشەکێکی ئەگەڕاو: ڕوویەک کە دروستکراوە بۆ ئەوەی لە کەشی گەرمدا ساردتر هەست پێبکرێت.'
    },
    how: {
      en: 'It works at the surface: the fabric construction is selected for a cooler hand-feel and for allowing heat to move away from the body. You turn this face up in summer and flip the mattress in winter.',
      ar: 'تعمل على السطح: يُختار بناء القماش ليمنح إحساساً أكثر برودة ويسمح بانتقال الحرارة بعيداً عن الجسم. تقلب هذا الوجه للأعلى في الصيف وتقلب السرير في الشتاء.',
      ku: 'لە ڕووکەوە کار دەکات: پێکهاتەی قوماشەکە هەڵبژێردراوە بۆ هەستی ساردتر و بۆ ڕێگەدان بە دوورکەوتنەوەی گەرمی لە لەش. لە هاویندا ئەم لایە بەرەو سەرەوە دەگەڕێنیت و لە زستاندا دۆشەکەکە ئەگەڕێنیتەوە.'
    },
    chars: {
      en: ['Cool-touch summer surface', 'Reversible with the wool side', 'Seasonal by design', 'Paired with 1000C pocket springs'],
      ar: ['سطح صيفي بارد الملمس', 'قابل للقلب مع جانب الصوف', 'موسمي بالتصميم', 'مع نوابض جيبية 1000C'],
      ku: ['ڕووی هاوینی سارد', 'ئەگەڕاو لەگەڵ لای خوری', 'بە دیزاین وەرزییە', 'لەگەڵ سپرینی گیرفانی 1000C']
    },
    why: {
      en: 'Because a mattress should not need replacing when the season changes. Four Seasons uses Ice Tech on one face and wool on the other.',
      ar: 'لأن السرير لا يجب أن يُستبدل عند تغيّر الفصل. يستخدم فور سيزونز تقنية Ice على وجه والصوف على الوجه الآخر.',
      ku: 'چونکە دۆشەک نابێت بگۆڕدرێت کاتێک وەرز دەگۆڕێت. فۆر سیزنس Ice Tech لە یەک لا و خوری لە لایەکەی تردا بەکاردەهێنێت.'
    },
    usedIn: ['four-seasons']
  },
  {
    id: 'tencel',
    num: '09',
    name: { en: 'Tencel', ar: 'تينسيل', ku: 'تێنسێل' },
    what: {
      en: 'A lyocell fibre made from wood pulp in a closed-loop process, known for softness and moisture handling.',
      ar: 'ليف ليوسيل يُصنع من لبّ الخشب بعملية مغلقة، ويُعرف بنعومته وقدرته على التعامل مع الرطوبة.',
      ku: 'ڕیشاڵێکی لایۆسێل کە لە پووخی دار دروست دەکرێت بە پرۆسەیەکی داخراو، بە نەرمی و مامەڵەکردن لەگەڵ شێ ناسراوە.'
    },
    how: {
      en: 'The fibre absorbs and releases moisture efficiently, which is why it appears in premium upholstery and bedding fabrics.',
      ar: 'يمتص الليف الرطوبة ويحررها بكفاءة، ولهذا يظهر في الأقمشة الفاخرة والمفروشات.',
      ku: 'ڕیشاڵەکە بە کارایی شێ هەڵدەمژێت و بەری دەداتەوە، بۆیە لە قوماشی لوکسدا دەبینرێت.'
    },
    chars: {
      en: ['Soft hand-feel', 'Moisture management', 'Closed-loop fibre production', 'Breathable fabric direction'],
      ar: ['ملمس ناعم', 'إدارة الرطوبة', 'إنتاج ليفي بعملية مغلقة', 'اتجاه الأقمشة القابلة للتنفس'],
      ku: ['دەستی نەرم', 'بەڕێوەبردنی شێ', 'بەرهەمهێنانی ڕیشاڵی داخراو', 'ئاراستەی قوماشی هەناسەدەر']
    },
    why: {
      en: 'Tencel is not currently part of a production model in the collection — it remains a fibre we evaluate for future breathable covers. We list it here for transparency.',
      ar: 'تينسيل ليس جزءاً من أي نموذج إنتاجي في المجموعة حالياً — وهو ليف نقيّمه لأغطية قابلة للتنفس مستقبلاً. نذكره هنا للشفافية.',
      ku: 'تێنسێل لە ئێستادا بەشێک نییە لە هیچ مۆدێلێکی بەرهەمهێنراوی کۆلێکشنەکە — ڕیشاڵێکە کە بۆ ڕووپۆشی هەناسەدەری داهاتوو هەڵدەسەنگێنین. لێرە بۆ ڕوونی باسی دەکەین.'
    },
    usedIn: []
  },
  {
    id: 'linen',
    num: '10',
    name: { en: 'Linen', ar: 'الكتان', ku: 'کەتان' },
    what: {
      en: 'A woven fabric from the flax plant, used as the outer cover on two models where its texture and breathability carry the design.',
      ar: 'قماش منسوج من نبات الكتان، يُستخدم كغطاء خارجي في نموذجين حيث يحمل ملمسه وقابليته للتنفس التصميم.',
      ku: 'قوماشێکی چنین لە ڕوەکی کەتان، وەک ڕووپۆشی دەرەوە لە دوو مۆدێلدا بەکاردێت کە دەست و هەناسەدانی دیزاینەکە هەڵدەگرێت.'
    },
    how: {
      en: 'Linen is a strong natural fibre with good airflow, and it is easy to combine with treatments — silver ions in Silver Tech, rock salt in Biolatex.',
      ar: 'الكتان ليف طبيعي قوي بتدفق هواء جيد، ويسهل دمجه مع المعالجات — أيونات الفضة في سيلفر تك، والملح الصخري في بيولاتكس.',
      ku: 'کەتان ڕیشاڵێکی سروشتی بەهێزە بە تێپەڕینی باشی هەوا، و ئاسانە لەگەڵ چارەسەرەکان تێکەڵ بکرێت — زیو ئایۆن لە سیلڤەر تێک و خوێی بەرد لە بیولاتێکس.'
    },
    chars: {
      en: ['Natural fibre', 'Breathable weave', 'Textured surface', 'Works with functional treatments'],
      ar: ['ليف طبيعي', 'نسيج قابل للتنفس', 'سطح ذو ملمس', 'يتوافق مع المعالجات الوظيفية'],
      ku: ['ڕیشاڵی سروشتی', 'چنینی هەناسەدەر', 'ڕووی بە دەست', 'لەگەڵ چارەسەری کارا دەگونجێت']
    },
    why: {
      en: 'It gives a mattress a natural, dry hand-feel instead of the slickness of synthetic covers. Used in Silver Tech and Biolatex.',
      ar: 'يمنح السرير إحساساً طبيعياً جافاً بدل نعومة الأغطية الصناعية. يُستخدم في سيلفر تك وبيولاتكس.',
      ku: 'هەستێکی سروشتی و وشکی بە دۆشەک دەبەخشێت لە جیاتی نەرمی ڕووپۆشی دەستکرد. لە سیلڤەر تێک و بیولاتێکس بەکاردێت.'
    },
    usedIn: ['silver-tech', 'biolatex']
  },
  {
    id: 'viscose',
    num: '11',
    name: { en: 'Viscose', ar: 'الفيسكوز', ku: 'ڤیسکۆس' },
    what: {
      en: 'A semi-synthetic fibre made from cellulose, used as a smooth, breathable cover fabric.',
      ar: 'ليف شبه صناعي من السليلوز، يُستخدم كقماش غطاء ناعم وقابل للتنفس.',
      ku: 'ڕیشاڵێکی نیوە دەستکرد لە سێلولۆز، وەک قوماشی ڕووپۆشی نەرم و هەناسەدەر بەکاردێت.'
    },
    how: {
      en: 'Viscose drapes smoothly over the construction and feels cool and dry to the touch, which helps the surface feel fresher in warm rooms.',
      ar: 'ينسدل الفيسكوز بسلاسة على البنية ويبدو بارداً وجافاً عند اللمس، ما يساعد السطح على الإحساس بالانتعاش في الغرف الدافئة.',
      ku: 'ڤیسکۆس بە نەرمی بەسەر پێکهاتەکەدا دەڕوات و سارد و وشک هەست پێدەکرێت، ئەمەیش یارمەتی ڕووکە دەدات لە ژووری گەرمدا زیندووتر هەست پێبکرێت.'
    },
    chars: {
      en: ['Smooth and cool hand-feel', 'Good airflow', 'Soft drape over the pillow top', 'Used on LuxeRest'],
      ar: ['ملمس ناعم وبارد', 'تدفق هواء جيد', 'انسدال ناعم على سطح الوسادة', 'يُستخدم في لوكس ريست'],
      ku: ['دەستی نەرم و سارد', 'تێپەڕینی باشی هەوا', 'ڕۆیشتنی نەرم بەسەر سەرەوەی سەرین', 'لە لوکس ڕێست بەکاردێت']
    },
    why: {
      en: 'It lets a plush pillow top stay breathable — one of the reasons LuxeRest suits warm sleepers who still want softness.',
      ar: 'يسمح لسطح الوسادة الفاخر بالبقاء قابلاً للتنفس — وهو أحد أسباب ملاءمة لوكس ريست لمن يشعرون بالحرارة ويريدون النعومة.',
      ku: 'ڕێگە دەدات سەرەوەی سەرینی نەرم هەناسەدەر بێت — یەکێک لە هۆکارەکانی گونجاوی لوکس ڕێست بۆ ئەو کەسانەی گەرم دەبن و نەرمیش دەوێت.'
    },
    usedIn: ['luxerest']
  },
  {
    id: 'gel-fusion',
    num: '12',
    name: { en: 'Gel Fusion Memory Foam', ar: 'إسفنج ذاكرة Gel Fusion', ku: 'فۆمی بیرگەی Gel Fusion' },
    what: {
      en: 'A memory foam with gel integrated into the foam structure, used as the comfort layer of a foam-only mattress.',
      ar: 'إسفنج ذاكرة مع جل مدمج في بنية الإسفنج، يُستخدم كطبقة راحة في سرير إسفنجي بالكامل.',
      ku: 'فۆمی بیرگە کە جێل لە پێکهاتەکەیدا تێکەڵ کراوە، وەک چینی ئاسوودەیی لە دۆشەکێکی تەواو فۆم بەکاردێت.'
    },
    how: {
      en: 'The foam contours to the body and relieves pressure; the gel is added to help the foam feel less warm than a traditional memory foam.',
      ar: 'يجاري الإسفنج الجسم ويخفف الضغط، ويُضاف الجل ليجعل الإسفنج أقل حرارة في الإحساس من إسفنج الذاكرة التقليدي.',
      ku: 'فۆمەکە لەگەڵ لەش دەگونجێت و گوشار کەم دەکاتەوە؛ جێلەکە زیاد کراوە بۆ ئەوەی فۆمەکە لە فۆمی بیرگەی کلاسیک کەمتر گەرم هەست پێبکرێت.'
    },
    chars: {
      en: ['Conforming pressure relief', 'Cooler-feeling foam', 'No springs anywhere', 'Quiet, motion-absorbing core'],
      ar: ['تخفيف ضغط مجارٍ للجسم', 'إحساس أقل حرارة', 'بدون نوابض إطلاقاً', 'قلب هادئ يمتص الحركة'],
      ku: ['کەمکردنەوەی گوشار بە گونجان لەگەڵ لەش', 'هەستی کەمتر گەرم', 'هیچ سپرینێک نییە', 'ناوەندێکی هێمن کە جووڵە هەڵدەمژێت']
    },
    why: {
      en: 'It is the heart of Neocomfort — the collection’s foam-only model, for sleepers who prefer foam to springs.',
      ar: 'إنه قلب نيو كومفورت — النموذج الإسفنجي الوحيد في المجموعة، لمن يفضّل الإسفنج على النوابض.',
      ku: 'دڵی نیو کۆمفۆرتە — تاکە مۆدێلی تەواو فۆمی کۆلێکشن، بۆ ئەو کەسانەی فۆم بە سپرین ترجیح دەدەن.'
    },
    usedIn: ['neocomfort']
  }
];

/* Short labels for technology tags shown on product pages */
window.TECH_LABELS = {
  'pocket': { en: 'Pocket spring', ar: 'نوابض جيبية', ku: 'سپرینی گیرفانی' },
  'pocket-twin': { en: 'Double 1500C pocket springs', ar: 'نوابض جيبية مزدوجة 1500C', ku: 'سپرینی گیرفانی دووانە 1500C' },
  'silver': { en: 'Silver ions', ar: 'أيونات الفضة', ku: 'زیو ئایۆن' },
  'linen': { en: 'Linen', ar: 'كتان', ku: 'کەتان' },
  'latex': { en: 'Natural latex', ar: 'لاتكس طبيعي', ku: 'لاتێکسی سروشتی' },
  'horsehair': { en: 'Horsehair', ar: 'شعر الخيل', ku: 'مووی ئەسپ' },
  'rock-salt': { en: 'Rock salt', ar: 'ملح صخري', ku: 'خوێی بەرد' },
  'pcm': { en: 'PCM', ar: 'PCM', ku: 'PCM' },
  'gel-memory': { en: 'Gel memory foam', ar: 'إسفنج ذاكرة بالجل', ku: 'فۆمی بیرگەی جێل' },
  'memory': { en: 'Memory foam', ar: 'إسفنج الذاكرة', ku: 'فۆمی بیرگە' },
  'gel-fusion': { en: 'Gel Fusion memory foam', ar: 'إسفنج Gel Fusion', ku: 'فۆمی Gel Fusion' },
  'foam': { en: 'All-foam core', ar: 'قلب إسفنجي', ku: 'ناوەندی فۆم' },
  'icetech': { en: 'Ice Tech', ar: 'تقنية Ice', ku: 'تەکنیکی ساردی' },
  'wool': { en: 'Wool-infused side', ar: 'جانب بالصوف', ku: 'لای خوری' },
  'jacquard': { en: 'Double jacquard silky fabric', ar: 'قماش حريري جاكار مزدوج', ku: 'قاوماشی جاکاردی دووانە' },
  'rabbit': { en: 'Rabbit-touch fabric', ar: 'قماش بملمس الأرنب', ku: 'قوماشی دەستی کەروێشک' },
  'ergo': { en: 'Ergo-Support foam', ar: 'إسفنج Ergo-Support', ku: 'فۆمی Ergo-Support' },
  'viscose': { en: 'Breathable viscose', ar: 'فيسكوز قابل للتنفس', ku: 'ڤیسکۆسی هەناسەدەر' },
  'nano': { en: 'Nano-knitted fabric', ar: 'قماش نانو مضغوط', ku: 'قوماشی نانۆ' },
  'spine-layer': { en: 'Spine-support layer', ar: 'طبقة دعم العمود الفقري', ku: 'چینی پاڵپشتی بڕبڕە' }
};

/* ---------- SLEEP GUIDE (8) ---------- */
window.GUIDE = [
  {
    num: '01',
    title: { en: 'Why sleep matters', ar: 'لماذا النوم مهم', ku: 'بۆچی خەو گرنگە' },
    body: {
      en: 'Sleep is when the body repairs tissue, consolidates memory and regulates appetite, mood and immune function. It is not lost time — it is the process that makes the next day possible. Because we spend roughly a third of our lives in bed, the surface we sleep on shapes that process more than any other piece of furniture.',
      ar: 'النوم هو وقت إصلاح الأنسجة وتثبيت الذاكرة وتنظيم الشهية والمزاج والمناعة. وهو ليس وقتاً ضائعاً، بل العملية التي تجعل اليوم التالي ممكناً. ولأننا نقضي نحو ثلث حياتنا في السرير، فإن السطح الذي ننام عليه يؤثر في هذه العملية أكثر من أي قطعة أثاث أخرى.',
      ku: 'خەو ئەو کاتەیە کە لەش شانەکان چاک دەکاتەوە، بیرەوەری جێگیر دەکات و ئارەزووی خواردن، مۆد و بەرگری لەش ڕێکدەخات. کاتی لەدەستچوو نییە — ئەو پرۆسەیەیە کە ڕۆژی دواتر پێدەکرێت. چونکە نزیکەی سێیەکی ژیانمان لەسەر جێخەوتن بەسەر دەبەین، ئەو ڕووەی لەسەری دەنوێین زیاتر لە هەر کەلوپەلێکی تر کاریگەری لەسەر ئەم پرۆسەیە هەیە.'
    }
  },
  {
    num: '02',
    title: { en: 'Sleep stages', ar: 'مراحل النوم', ku: 'قۆناغەکانی خەو' },
    body: {
      en: 'Across the night the body cycles through light sleep, deeper slow-wave sleep and REM sleep. Deep sleep is associated with physical recovery; REM with memory and emotional processing. Each cycle takes roughly 90 minutes, and interruptions fragment both. A mattress that causes pressure or heat builds micro-interruptions you may not remember but still feel the next morning.',
      ar: 'خلال الليل ينتقل الجسم بين النوم الخفيف والنوم العميق البطيء الموجات ونوم حركة العين السريعة. يرتبط النوم العميق بالتعافي الجسدي، وحركة العين السريعة بالذاكرة ومعالجة المشاعر. تستغرق كل دورة نحو ٩٠ دقيقة، والانقطاعات تجزّئ الاثنين. والسرير الذي يسبب الضغط أو الحرارة يُحدث انقطاعات دقيقة قد لا تتذكرها لكنك تشعر بها في الصباح.',
      ku: 'بە درێژایی شەو لەش بە خەوی سووک، خەوی قووڵی شەپۆل-هێواش و خەوی REMدا دەسووڕێتەوە. خەوی قووڵ پەیوەندی بە چاکبوونەوەی جەستەیی هەیە و REM بە بیرەوەری و مامەڵەکردن لەگەڵ هەستەکان. هەر سووڕێک نزیکەی ٩٠ خولەکە و پچڕان هەردووکیان پارچەپارچە دەکات. ئەو دۆشەکە کە گوشار یان گەرمی دروست دەکات، پچڕانی ورد دروست دەکات کە لەوانەیە لەبیرت نەبێت بەڵام بەیانیان هەستی پێدەکەیت.'
    }
  },
  {
    num: '03',
    title: { en: 'Sleeping positions', ar: 'وضعيات النوم', ku: 'شێوازەکانی نوستن' },
    body: {
      en: 'Side sleepers load the shoulder and hip and usually need a softer, pressure-relieving surface with a support layer beneath it. Back sleepers generally need a level, supportive surface that keeps the pelvis and shoulders from sinking unevenly. Stomach sleepers tend to over-arch the lower back on soft mattresses, so firmer support — often with latex or a firmer foam — usually suits them better. Combination sleepers need the compromise: enough softness to move easily, enough support to stay aligned.',
      ar: 'من ينام على جنبه يُحمّل الكتف والورك ويحتاج عادة إلى سطح أنعم يخفف الضغط مع طبقة دعم تحته. ومن ينام على ظهره يحتاج عادة سطحاً مستوياً وداعماً يمنع نزول الحوض والكتفين بشكل غير متساوٍ. ومن ينام على بطنه يميل إلى تقويس أسفل ظهره على الأسرّة الناعمة، لذا يناسبه عادة سرير أكثر صلابة — غالباً باللاتكس أو إسفنج أصلب. أما من يغيّر وضعيته فيحتاج الحل الوسط: نعومة كافية للحركة ودعم كافٍ للاستقامة.',
      ku: 'ئەوەی لەسەر لاتەنیشت دەنوێت شان و کەمەر بار دەکات و زۆرجار ڕوویەکی نەرمتر و کەمکەرەوەی گوشاری پێویستە لەگەڵ چینی پاڵپشتی لە ژێرەوە. ئەوەی لەسەر پشت دەنوێت بەگشتی ڕوویەکی ڕێک و پاڵپشتیکەری پێویستە کە ڕێگە نەدات حەوز و شان بە نایەکسانی نوقم بن. ئەوەی لەسەر سک دەنوێت زۆرجار خوارەوەی پشت لە دۆشەکی نەرمدا دەچەمێنێت، بۆیە پاڵپشتی ڕەقتر — زۆرجار بە لاتێکس یان فۆمی ڕەقتر — باشترە. ئەوەی شێواز دەگۆڕێت پێویستی بە ڕێککەوتنە: نەرمی پێویست بۆ جووڵە و پاڵپشتی پێویست بۆ ڕاستی.'
    }
  },
  {
    num: '04',
    title: { en: 'Mattress pressure relief', ar: 'تخفيف الضغط في السرير', ku: 'کەمکردنەوەی گوشار لە دۆشەک' },
    body: {
      en: 'Pressure builds where your body meets the mattress with the most weight on the smallest area — the shoulders and hips. A surface that is too firm concentrates pressure there; one that is too soft makes the body sink until the joints take the tension instead. Pressure-relieving layers such as memory foam and natural latex spread the load over a larger area, which is why they appear in the models we recommend for side sleepers.',
      ar: 'يتراكم الضغط حيث يلتقي جسمك بالسرير بأكبر وزن على أصغر مساحة — الكتفان والوركان. السطح الأكثر صلابة يركّز الضغط هناك، والأكثر نعومة يجعل الجسم يغرق حتى تتحمل المفاصل التوتر بدلاً منه. طبقات تخفيف الضغط مثل إسفنج الذاكرة واللاتكس الطبيعي توزع الحمل على مساحة أكبر، ولهذا تظهر في النماذج التي نوصي بها لمن ينام على جنبه.',
      ku: 'گوشار لەو شوێنەدا کۆدەبێتەوە کە لەشت لەگەڵ دۆشەکەکە یەکدەگرێت و زۆرترین کێش لەسەر بچووکترین ڕووبەرە — شان و کەمەر. ڕوویەکی زۆر ڕەق گوشار لەوێ کۆدەکاتەوە و ڕوویەکی زۆر نەرم وای دەکات لەش نوقم بێت تا جومگەکان گرژییەکە هەڵبگرن. چینەکانی کەمکردنەوەی گوشار وەک فۆمی بیرگە و لاتێکسی سروشتی بارەکە بەسەر ڕووبەرێکی گەورەتردا دابەش دەکەن، بۆیە لەو مۆدێلانەدا هەن کە بۆ نوستنی لاتەنیشت پێشنیاری دەکەین.'
    }
  },
  {
    num: '05',
    title: { en: 'Spinal support', ar: 'دعم العمود الفقري', ku: 'پاڵپشتی بڕبڕەی پشت' },
    body: {
      en: 'Support is about keeping the spine in a neutral line from the pelvis to the shoulders. Too much sink and the lower back arches; too little and the body bridges, leaving the waist unsupported. Pocket springs help because each spring responds to the load above it, and a firmer base under a softer top lets the surface contour without collapsing. Luna, Silver Tech and Rabbit Comfort are the models we position around this need.',
      ar: 'الدعم يعني الحفاظ على العمود الفقري في خط محايد من الحوض إلى الكتفين. الغرق الزائد يقوّس أسفل الظهر، والصلابة الزائدة تجعل الجسم يتقوّس تاركاً الوسط بلا دعم. تساعد النوابض الجيبية لأن كل نابض يستجيب للحمل فوقه، وقاعدة أكثر صلابة تحت سطح ناعم تسمح بمجاراة الجسم دون انهيار. لونا وسيلفر تك ورابيت كومفورت هي النماذج التي نضعها حول هذه الحاجة.',
      ku: 'پاڵپشتی بەو مانایەیە کە بڕبڕەی پشت لە هێڵێکی ناوەندیدا بهێڵرێتەوە لە حەوزەوە بۆ شان. نوقمبوونی زۆر خوارەوەی پشت دەچەمێنێت و ڕەقی زۆریش وای دەکات لەش پرد دروست بکات و ناوەڕاست بێ پاڵپشتی بمێنێتەوە. سپرینی گیرفانی یارمەتی دەدات چونکە هەر سپرینێک بۆ بارەکەی سەرەوەی خۆی وەڵام دەداتەوە، و بنکەیەکی ڕەقتر لە ژێر ڕوویەکی نەرم ڕێگە دەدات ڕووکە لەگەڵ لەش بگونجێت بەبێ ڕووخان. لونا، سیلڤەر تێک و ڕابیت کۆمفۆرت ئەو مۆدێلانەن کە بۆ ئەم پێداویستییە دانراون.'
    }
  },
  {
    num: '06',
    title: { en: 'Motion isolation', ar: 'عزل الحركة', ku: 'جیاکردنەوەی جووڵە' },
    body: {
      en: 'When one sleeper turns, a shared surface can carry that movement across to the other side. Pocket springs limit it because the springs are not wired to each other; foam limits it further because foam absorbs movement rather than transmitting it. If you share a bed and wake easily, this is one of the most practical specifications to check — and it is why Neocomfort, a foam-only mattress, is often chosen by couples.',
      ar: 'عندما يتحرك أحد النائمين، قد ينقل السطح المشترك تلك الحركة إلى الطرف الآخر. تحدّ النوابض الجيبية من ذلك لأن النوابض غير موصولة ببعضها، ويحدّ الإسفنج أكثر لأنه يمتص الحركة بدل نقلها. إذا كنت تشارك السرير وتستيقظ بسهولة، فهذا من أكثر المواصفات العملية التي يجب التحقق منها — ولهذا يختار الأزواج كثيراً نيو كومفورت، السرير الإسفنجي بالكامل.',
      ku: 'کاتێک یەکێک لە نوستەکان دەسووڕێتەوە، ڕووی هاوبەش لەوانەیە ئەو جووڵەیە بگوازێتەوە بۆ لایەکەی تر. سپرینی گیرفانی ئەمە کەم دەکاتەوە چونکە سپرینەکان بە یەکەوە نەبەستراوە؛ فۆم زیاتر کەمی دەکاتەوە چونکە جووڵە هەڵدەمژێت نەک بگوازێتەوە. ئەگەر جێخەوتنێکی هاوبەشت هەیە و بە ئاسانی هەڵدەستیت، ئەمە یەکێکە لە کرداریترین تایبەتمەندییەکان کە دەبێت بپشکنیت — و هۆکاری ئەوەیە کە نیو کۆمفۆرت، دۆشەکی تەواو فۆم، زۆرجار لەلایەن هاوسەرەکان هەڵدەبژێردرێت.'
    }
  },
  {
    num: '07',
    title: { en: 'Temperature regulation', ar: 'تنظيم الحرارة', ku: 'ڕێکخستنی گەرمی' },
    body: {
      en: 'Body temperature naturally falls as you fall asleep, and a mattress that traps heat works against that. Breathable covers, open spring cores, natural fibres such as horsehair and linen, and phase change materials each help in a different way. Reversible construction adds a seasonal option. If you wake warm, prioritise airflow and a cooler surface before softness.',
      ar: 'تنخفض حرارة الجسم طبيعياً عند النوم، والسرير الذي يحتفظ بالحرارة يعمل ضد ذلك. الأغطية القابلة للتنفس، وقلوب النوابض المفتوحة، والألياف الطبيعية كشعر الخيل والكتان، ومواد تغيّر الطور — كل منها يساعد بطريقة مختلفة. وتضيف البنية القابلة للقلب خياراً موسمياً. إذا استيقظت وأنت تشعر بالحرارة، فاعطِ الأولوية لتدفق الهواء والسطح الأبرد قبل النعومة.',
      ku: 'پلەی گەرمی لەش بە سروشتی دادەبەزێت کاتێک دەنوێیت، و ئەو دۆشەکە کە گەرمی ڕادەگرێت دژی ئەمە کار دەکات. ڕووپۆشی هەناسەدەر، ناوەندی سپرینی کراوە، ڕیشاڵی سروشتی وەک مووی ئەسپ و کەتان، و کەرەستەی گۆڕەری قۆناغ هەریەکە بە شێوەیەک یارمەتی دەدەن. پێکهاتەی ئەگەڕاو بژاردەیەکی وەرزیش زیاد دەکات. ئەگەر بە گەرمی هەڵدەستیت، پێش نەرمی پێشینە بە تێپەڕینی هەوا و ڕووی ساردتر بدە.'
    }
  },
  {
    num: '08',
    title: { en: 'Choosing a mattress', ar: 'اختيار السرير', ku: 'هەڵبژاردنی دۆشەک' },
    body: {
      en: 'Start with position and comfort, then temperature, then the support you need. Size matters more than most people expect — a mattress too small for two sleepers reduces the space each person has to find a comfortable position. Try before you buy where possible, give a new mattress several weeks, and use our finder if you want a structured starting point: it is a weighted recommendation tool based on your answers, not a medical assessment.',
      ar: 'ابدأ بالوضعية والراحة، ثم الحرارة، ثم الدعم الذي تحتاجه. المقاس أهم مما يتوقع معظم الناس — فالسرير الأصغر من اللازم لنائمين يقلل المساحة المتاحة لكل منهما لإيجاد وضعية مريحة. جرّب قبل الشراء إن أمكن، وامنح السرير الجديد عدة أسابيع، واستخدم أداة البحث لدينا إن أردت نقطة بداية منظمة: فهي أداة توصية مرجّحة مبنية على إجاباتك، وليست تقييماً طبياً.',
      ku: 'بە شێوازی نوستن و ئاسوودەیی دەست پێبکە، دواتر گەرمی، دواتر ئەو پاڵپشتییەی پێویستتە. قەبارە لەوەی زۆر کەس چاوەڕوانی دەکەن گرنگترە — دۆشەکی بچووکتر لە پێویست بۆ دوو کەس ئەو شوێنەی کەم دەکاتەوە کە هەریەکە بۆ دۆزینەوەی شێوازێکی ئاسوودە پێویستی پێیەتی. ئەگەر کراوە پێش کڕین تاقیی بکەرەوە، چەند هەفتەیەک بە دۆشەک نوێیەکە بدە، و ئەگەر خاڵێکی دەستپێکی ڕێکخراوت دەوێت دۆزەرەوەکەمان بەکاربهێنە: ئامرازێکی پێشنیارکردنی کێشکراوە لەسەر بنەمای وەڵامەکانت، نەک هەڵسەنگاندنێکی پزیشکی.'
    }
  }
];

/* ---------- FAQ (12) ---------- */
window.FAQ = [
  {
    q: { en: 'How do I choose the right mattress?', ar: 'كيف أختار السرير المناسب؟', ku: 'چۆن دۆشەکی گونجاو هەڵبژێرم؟' },
    a: {
      en: 'Start with your sleeping position and the comfort level you actually enjoy, then factor in temperature, the support you need and finally price and size. Our mattress finder scores all nine models against those answers. If you can, lie on your two or three favourites in a showroom before deciding.',
      ar: 'ابدأ بوضعية نومك ومستوى الراحة الذي تحبه فعلاً، ثم أضف الحرارة والدعم الذي تحتاجه، وأخيراً السعر والمقاس. يقيّم مستشار السرير لدينا النماذج التسعة وفق هذه الإجابات. وإن أمكن، استلقِ على الخيارين أو الثلاثة المفضلة لديك في المعرض قبل القرار.',
      ku: 'بە شێوازی نوستنت و ئاستی ئاسوودەیی کە بەڕاستی حەزت لێیە دەست پێبکە، دواتر گەرمی و پاڵپشتی پێویست و لە کۆتاییدا نرخ و قەبارە. دۆزەرەوەی دۆشەکەکەمان هەموو نۆ مۆدێلەکە بەپێی ئەو وەڵامانە هەڵدەسەنگێنێت. ئەگەر بوارت هەبوو، لە نمایشگە لەسەر دوو یان سێ هەڵبژاردەی دڵخوازت پاڵبکەوە پێش بڕیاردان.'
    }
  },
  {
    q: { en: 'What is a pocket spring mattress?', ar: 'ما هو سرير النوابض الجيبية؟', ku: 'دۆشەکی سپرینی گیرفانی چییە؟' },
    a: {
      en: 'It is a mattress in which each spring is sewn into an individual fabric pocket. Because the springs are not wired together, each one compresses independently, giving local support and reducing how much movement travels across the surface. Several Sadaf Sleep models use pocket springs, and Silver Tech and Biolatex use two 1500C units.',
      ar: 'هو سرير يُخاط فيه كل نابض داخل جيب قماشي مستقل. ولأن النوابض غير موصولة ببعضها، ينضغط كل منها باستقلال، ما يوفر دعماً موضعياً ويقلل انتقال الحركة عبر السطح. تستخدم عدة نماذج من صدف للنوم النوابض الجيبية، ويستخدم سيلفر تك وبيولاتكس وحدتي 1500C.',
      ku: 'ئەو دۆشەکەیە کە هەر سپرینێک لە گیرفانێکی قوماشی سەربەخۆدا دەدروورێت. چونکە سپرینەکان بە یەکەوە نەبەستراوە، هەریەکە بە سەربەخۆیی دەگوشێت، پاڵپشتی خۆجێیی دەبەخشێت و گواستنەوەی جووڵە کەم دەکاتەوە. چەند مۆدێلێکی سەدەف خەو سپرینی گیرفانی بەکاردەهێنن، و سیلڤەر تێک و بیولاتێکس دوو یەکەی 1500C بەکاردەهێنن.'
    }
  },
  {
    q: { en: 'What is the difference between foam and pocket springs?', ar: 'ما الفرق بين الإسفنج والنوابض الجيبية؟', ku: 'جیاوازی نێوان فۆم و سپرینی گیرفانی چییە؟' },
    a: {
      en: 'Foam is a solid core: quieter, better at absorbing movement and typically lower in height. Pocket springs use air-filled coils, which feel more responsive and allow air to move through the core. Neither is better in general — it depends on whether you prioritise motion isolation and a soft, contouring feel, or a springier, more ventilated support. Neocomfort is our foam-only model; the rest of the collection uses springs.',
      ar: 'الإسفنج قلب صلب: أهدأ، وأفضل في امتصاص الحركة، وعادة أقل ارتفاعاً. أما النوابض الجيبية فتستخدم نوابض مملوءة بالهواء، فتبدو أكثر استجابة وتسمح بمرور الهواء في القلب. لا يوجد أفضل بشكل عام — يتوقف الأمر على ما تعطيه الأولوية: عزل الحركة وإحساس ناعم يحتضن الجسم، أو دعم نابض وأكثر تهوية. نيو كومفورت هو نموذجنا الإسفنجي بالكامل، وبقية المجموعة تستخدم النوابض.',
      ku: 'فۆم ناوەندێکی ڕەقە: هێمنترە، باشترە لە هەڵمژینی جووڵە و بەگشتی نزمترە. سپرینی گیرفانی کۆیلی پڕ لە هەوا بەکاردەهێنێت، کە وەڵامدانەوەی زیاترە و ڕێگە بە هەوا دەدات بە ناوەندەکەدا تێپەڕێت. هیچیان بە گشتی باشتر نییە — پەیوەندی بەوە هەیە کە پێشینە بە جیاکردنەوەی جووڵە و هەستی نەرم دەدەیت، یان بە پاڵپشتییەکی فنەرتر و هەوادارتر. نیو کۆمفۆرت مۆدێلی تەواو فۆمە؛ باقی کۆلێکشنەکە سپرین بەکاردەهێنێت.'
    }
  },
  {
    q: { en: 'What is memory foam?', ar: 'ما هو إسفنج الذاكرة؟', ku: 'فۆمی بیرگە چییە؟' },
    a: {
      en: 'Memory foam is a viscoelastic foam that softens with body heat and slowly returns to shape. It conforms closely to the body and spreads pressure across a wider area, which makes it useful for shoulder and hip pressure. The trade-off is that it can feel warmer and slower to move on. In our collection it appears as gel memory foam in Thermo Memory and Gel Fusion memory foam in Neocomfort.',
      ar: 'إسفنج الذاكرة إسفنج لزج مرن يلين بحرارة الجسم ويعود ببطء إلى شكله. يجاري الجسم عن قرب ويوزع الضغط على مساحة أوسع، ما يجعله مفيداً لضغط الكتفين والوركين. المقابل أنه قد يبدو أكثر حرارة وأبطأ في الاستجابة للحركة. في مجموعتنا يظهر كإسفنج ذاكرة بالجل في ثيرمو ميموري وإسفنج Gel Fusion في نيو كومفورت.',
      ku: 'فۆمی بیرگە فۆمێکی لینج و کشۆڵەیە کە بە گەرمی لەش نەرم دەبێت و بە هێواشی دەگەڕێتەوە بۆ شێوەکەی. بە نزیکی لەگەڵ لەش دەگونجێت و گوشار بەسەر ڕووبەرێکی فراوانتردا دابەش دەکات، بۆیە بۆ گوشاری شان و کەمەر بەکەڵکە. بەرامبەرەکەی ئەوەیە کە لەوانەیە گەرمتر هەست پێبکرێت و هێواشتر بێت لە جووڵەدا. لە کۆلێکشنەکەماندا وەک فۆمی بیرگەی جێل لە تێرمۆ مێمۆری و فۆمی Gel Fusion لە نیو کۆمفۆرتدا هەیە.'
    }
  },
  {
    q: { en: 'What is PCM?', ar: 'ما هو PCM؟', ku: 'PCM چییە؟' },
    a: {
      en: 'PCM stands for phase change material. It absorbs heat as it warms and releases it as it cools, buffering temperature swings at the surface rather than letting warmth build up. It needs no power and is integrated into the fabric layer. You will find it in Thermo Memory, in the layer directly beneath the quilted surface.',
      ar: 'PCM اختصار لمادة تغيّر الطور. تمتص الحرارة عند الدفء وتحررها عند البرودة، فتخفف تقلبات الحرارة على السطح بدل السماح بتراكم الدفء. لا تحتاج إلى طاقة وتُدمج في طبقة القماش. تجدها في ثيرمو ميموري، في الطبقة التي تحت السطح المبطّن مباشرة.',
      ku: 'PCM کورتەبۆ کەرەستەی گۆڕەری قۆناغ. گەرمی هەڵدەمژێت کاتێک گەرم دەبێت و بەری دەداتەوە کاتێک سارد دەبێتەوە، بەم شێوەیە گۆڕانی گەرمی لە ڕووکە کەم دەکاتەوە لە جیاتی ڕێگەدان بە کۆبوونەوەی گەرمی. پێویستی بە وزە نییە و لە چینی قوماشەکەدا دانراوە. لە تێرمۆ مێمۆریدا دەیدۆزیتەوە، لەو چینەی ڕاستەوخۆ لە ژێر ڕووی چنارەکراودایە.'
    }
  },
  {
    q: { en: 'What makes Silver Tech different?', ar: 'ما الذي يميّز سيلفر تك؟', ku: 'چی سیلڤەر تێک جیاواز دەکات؟' },
    a: {
      en: 'Silver Tech is built around hygiene and support at the same time: a silver-ion linen cover with a confirmed 99.9% antibacterial figure, a double 1500C pocket spring system, reinforced edge support and a structured box top at 30 cm. It is the model we point to when a cleaner surface matters as much as the feel.',
      ar: 'بُني سيلفر تك حول النظافة والدعم في الوقت نفسه: غطاء كتان بأيونات الفضة بنسبة مؤكدة ٩٩.٩٪ ضد البكتيريا، ونظام نوابض جيبية مزدوج 1500C، ودعم محيطي معزّز، وسطح صندوقي متماسك بارتفاع ٣٠ سم. وهو النموذج الذي نشير إليه عندما يكون السطح الأنظف مهماً بقدر الإحساس.',
      ku: 'سیلڤەر تێک لە دەوری پاکوخاوێنی و پاڵپشتی پێکەوە بنیات نراوە: ڕووپۆشی کەتانی زیو ئایۆن بە ڕێژەی ٩٩.٩٪ دژە بەکتریا، سیستەمی سپرینی گیرفانی دووانەی 1500C، پاڵپشتی لاتەنیشتی بەهێزکراو و سەرەوەی سندوقی بەهێز بە ٣٠ سم. ئەو مۆدێلەیە کە ئاماژەی پێدەکەین کاتێک ڕوویەکی پاکتر هێندەی هەست گرنگە.'
    }
  },
  {
    q: { en: 'What is the difference between Biolux and Biolatex?', ar: 'ما الفرق بين بيولوكس وبيولاتكس؟', ku: 'جیاوازی نێوان بیولۆکس و بیولاتێکس چییە؟' },
    a: {
      en: 'Both are soft, luxurious models, but they are built differently. Biolux is 30 cm with a pillow top and a double jacquard silky cover over pocket springs — its focus is the silky, hotel-like surface. Biolatex is 40 cm, uses natural latex and horsehair under a rock-salt linen cover, and doubles the pocket spring system; its focus is natural materials and deeper comfort. Choose Biolux for the touch, Biolatex for the material story and the extra height.',
      ar: 'كلاهما نموذجان ناعمان فاخران، لكن بنيتهما مختلفة. بيولوكس بارتفاع ٣٠ سم بسطح وسادة وغطاء حريري جاكار مزدوج فوق نوابض جيبية — تركيزه على السطح الحريري بأسلوب الفنادق. أما بيولاتكس فبارتفاع ٤٠ سم، ويستخدم اللاتكس الطبيعي وشعر الخيل تحت غطاء كتان بالملح الصخري، ويضاعف نظام النوابض الجيبية — تركيزه على المواد الطبيعية والراحة الأعمق. اختر بيولوكس للملمس، وبيولاتكس لقصة المواد والارتفاع الإضافي.',
      ku: 'هەردووکیان مۆدێلی نەرم و لوکسن، بەڵام بە شێوەی جیاواز دروستکراون. بیولۆکس ٣٠ سمە بە سەرەوەی سەرین و ڕووپۆشی ئاوریشمی جاکاردی دووانە لەسەر سپرینی گیرفانی — سەرنجی لەسەر ڕووی ئاوریشمی وەک هۆتێلە. بیولاتێکس ٤٠ سمە، لاتێکسی سروشتی و مووی ئەسپ بەکاردەهێنێت لە ژێر ڕووپۆشی کەتانی خوێی بەرد و سیستەمی سپرینی گیرفانی دوو هێندە دەکات — سەرنجی لەسەر کەرەستەی سروشتی و ئاسوودەیی قووڵترە. بیولۆکس بۆ دەست هەڵبژێرە و بیولاتێکس بۆ چیرۆکی کەرەستە و بەرزی زیاتر.'
    }
  },
  {
    q: { en: 'How does Four Seasons work?', ar: 'كيف يعمل فور سيزونز؟', ku: 'فۆر سیزنس چۆن کار دەکات؟' },
    a: {
      en: 'Four Seasons is reversible. One face is built with Ice Technology for summer; the other incorporates wool for winter. Both faces share a 1000C pocket spring unit inside, and the mattress is 30 cm with a Euro top. You simply turn it over when the season changes — one mattress, two climates.',
      ar: 'فور سيزونز قابل للقلب. أحد الوجهين مبني بتقنية Ice للصيف، والآخر يحتوي على الصوف للشتاء. يشترك الوجهان في وحدة نوابض جيبية 1000C في الداخل، وارتفاع السرير ٣٠ سم بسطح أوروبي. تقلبه ببساطة عند تغيّر الفصل — سرير واحد، مناخان.',
      ku: 'فۆر سیزنس ئەگەڕاوە. یەک ڕوو بە Ice Technology بۆ هاوین دروستکراوە و ڕوویەکەی تر خوری تێدایە بۆ زستان. هەردوو ڕووەکە یەکەی سپرینی گیرفانی 1000C لە ناوەوە هاوبەشن، و دۆشەکەکە ٣٠ سمە بە سەرەوەی ئەوروپی. تەنها کاتێک وەرز دەگۆڕێت ئەگەڕێنەوە — یەک دۆشەک، دوو کەشوهەوا.'
    }
  },
  {
    q: { en: 'Which mattress is suitable for hot sleepers?', ar: 'أي سرير يناسب من يشعر بالحرارة؟', ku: 'کام دۆشەک بۆ ئەو کەسانە گونجاوە کە گەرم دەبن؟' },
    a: {
      en: 'Look for airflow and a cooler surface first: Thermo Memory for PCM technology and gel memory foam, LuxeRest for a breathable viscose cover and plush feel, and the Ice Technology side of Four Seasons in summer. If you overheat and still prefer natural materials, Biolatex uses horsehair and latex precisely for breathability.',
      ar: 'ابحث أولاً عن تدفق الهواء والسطح الأبرد: ثيرمو ميموري لتقنية PCM وإسفنج الذاكرة بالجل، ولوكس ريست لغطاء الفيسكوز القابل للتنفس وإحساسه الفاخر، وجانب تقنية Ice في فور سيزونز في الصيف. وإذا كنت تشعر بالحرارة وتفضّل المواد الطبيعية، فبيولاتكس يستخدم شعر الخيل واللاتكس تحديداً لقابلية التنفس.',
      ku: 'سەرەتا بەدوای تێپەڕینی هەوا و ڕووی ساردتر بگەڕێ: تێرمۆ مێمۆری بۆ تەکنەلۆژیای PCM و فۆمی بیرگەی جێل، لوکس ڕێست بۆ ڕووپۆشی ڤیسکۆسی هەناسەدەر و هەستی نەرم، و لای Ice Technology ی فۆر سیزنس لە هاویندا. ئەگەر گەرم دەبیت و هێشتا کەرەستەی سروشتیت ترجیح دەدەیت، بیولاتێکس بە تایبەتی مووی ئەسپ و لاتێکس بۆ هەناسەدان بەکاردەهێنێت.'
    }
  },
  {
    q: { en: 'What sizes are available?', ar: 'ما المقاسات المتوفرة؟', ku: 'کام قەبارە بەردەستە؟' },
    a: {
      en: 'Across the collection we offer 100 × 200, 120 × 200, 160 × 200, 180 × 200 and 200 × 200 cm — but not every model is made in every size, and each size has its own price. Sizes are listed individually on each product page, and our finder only recommends a size the model is actually available in. For example, Luna is available up to 180 × 200 and is not offered in 200 × 200.',
      ar: 'نوفر في المجموعة مقاسات ١٠٠ × ٢٠٠ و١٢٠ × ٢٠٠ و١٦٠ × ٢٠٠ و١٨٠ × ٢٠٠ و٢٠٠ × ٢٠٠ سم — لكن ليس كل نموذج يُصنع بكل مقاس، ولكل مقاس سعره. المقاسات مدرجة بشكل فردي في صفحة كل منتج، ومستشار السرير يوصي فقط بمقاس متوفر فعلاً في النموذج. مثلاً لونا متوفرة حتى ١٨٠ × ٢٠٠ وغير متوفرة بمقاس ٢٠٠ × ٢٠٠.',
      ku: 'لە کۆلێکشنەکەدا قەبارەی ١٠٠ × ٢٠٠، ١٢٠ × ٢٠٠، ١٦٠ × ٢٠٠، ١٨٠ × ٢٠٠ و ٢٠٠ × ٢٠٠ سم پێشکەش دەکەین — بەڵام هەموو مۆدێلێک بە هەموو قەبارەیەک دروست ناکرێت و هەر قەبارەیەک نرخی خۆی هەیە. قەبارەکان بە جیا لە پەڕەی هەر بەرهەمێکدا لیستکراون، و دۆزەرەوەکەمان تەنها ئەو قەبارەیە پێشنیار دەکات کە مۆدێلەکە بەڕاستی پێی هەیە. بۆ نموونە لونا تا ١٨٠ × ٢٠٠ بەردەستە و بە ٢٠٠ × ٢٠٠ نییە.'
    }
  },
  {
    q: { en: 'How can I compare mattresses?', ar: 'كيف أقارن بين الأسرّة؟', ku: 'چۆن دۆشەکەکان بەراورد بکەم؟' },
    a: {
      en: 'Open the collection and select up to three models with the compare control. You will get a side-by-side table of height, top style, construction, technologies, sizes and price by size. The finder also offers a compare view for its two alternatives, so you can see why the top match won.',
      ar: 'افتح المجموعة واختر حتى ثلاثة نماذج بأداة المقارنة. ستحصل على جدول جنباً إلى جنب للارتفاع ونوع السطح والبنية والتقنيات والمقاسات والسعر لكل مقاس. ويوفر مستشار السرير أيضاً عرض مقارنة لبديليه، لترى لماذا فاز الخيار الأول.',
      ku: 'کۆلێکشنەکە بکەرەوە و تا سێ مۆدێل بە ئامرازی بەراورد هەڵبژێرە. خشتەیەکی لاتەنیشت بە لاتەنیشت دەست دەکەوێت بۆ بەرزی، جۆری سەرەوە، پێکهاتە، تەکنەلۆژیا، قەبارە و نرخی هەر قەبارەیەک. دۆزەرەوەکەش بینینی بەراورد بۆ دوو بەدیلەکەی پێشکەش دەکات، بۆ ئەوەی بزانیت بۆچی هەڵبژاردەی یەکەم بردییەوە.'
    }
  },
  {
    q: { en: 'Where are Sadaf showrooms located?', ar: 'أين تقع معارض صدف؟', ku: 'نمایشگەکانی سەدەف لە کوێن؟' },
    a: {
      en: 'We have six: Sadaf Plaza and Sadaf Office on 100m Street in Erbil (opposite Empire Square), Sadaf Outlet on Koya Road in Hiwa City, Sadaf Group on 60m Street near Ainkawa Bridge in Erbil, Sadaf Plaza on 60m Street near Kobani Bridge in Sulaymaniyah, and Sadaf Plaza on Malta Street opposite the old Duhok stadium in Duhok. Full contact details are on the contact page.',
      ar: 'لدينا ستة معارض: صدف بلازا وصدف أوفيس في شارع ١٠٠ متر في أربيل (مقابل ساحة الإمبراطورية)، وصدف أوتلت على طريق كوية في حيوا سيتي، وصدف جروب في شارع ٦٠ متر قرب جسر عينكاوا في أربيل، وصدف بلازا في شارع ٦٠ متر قرب جسر كوباني في السليمانية، وصدف بلازا في شارع مالطا مقابل ملعب دهوك القديم في دهوك. تفاصيل التواصل الكاملة في صفحة الاتصال.',
      ku: 'شەش نمایشگەمان هەیە: سەدەف پلازا و سەدەف ئۆفیس لە شەقامی ١٠٠ مەتری هەولێر (بەرامبەر گۆڕەپانی ئێمپایەر)، سەدەف ئاوتلێت لە ڕێگای کۆیە لە هێوا سیتی، سەدەف گروپ لە شەقامی ٦٠ مەتری نزیک پردی عەینکاوا لە هەولێر، سەدەف پلازا لە شەقامی ٦٠ مەتری نزیک پردی کۆبانێ لە سلێمانی، و سەدەف پلازا لە شەقامی ماڵتا بەرامبەر یاریگای کۆنی دهۆک. وردەکاری تەواوی پەیوەندی لە پەڕەی پەیوەندیدایە.'
    }
  }
];

/* ---------- SHOWROOMS ---------- */
window.BRANCHES = [
  {
    id: 'plaza-erbil',
    mapUrl: 'https://maps.app.goo.gl/etiPuCgZrqGSLK167',
    name: { en: 'Sadaf Plaza, Erbil', ar: 'صدف بلازا، أربيل', ku: 'سەدەف پلازا، هەولێر' },
    city: { en: 'Erbil', ar: 'أربيل', ku: 'هەولێر' },
    address: {
      en: '100m Street, opposite Empire Square',
      ar: 'شارع ١٠٠ متر، مقابل ساحة الإمبراطورية',
      ku: 'شەقامی ١٠٠ مەتری، بەرامبەر گۆڕەپانی ئێمپایەر'
    },
    phone: '0750 432 2001',
    tel: '+9647504322001',
    role: { en: 'Main showroom', ar: 'المعرض الرئيسي', ku: 'نمایشگای سەرەکی' },
    mapQuery: 'Sadaf Plaza 100m Street Empire Square Erbil'
  },
  {
    id: 'office-erbil',
    mapUrl: 'https://maps.app.goo.gl/etiPuCgZrqGSLK167',
    name: { en: 'Sadaf Office, Erbil', ar: 'صدف أوفيس، أربيل', ku: 'سەدەف ئۆفیس، هەولێر' },
    city: { en: 'Erbil', ar: 'أربيل', ku: 'هەولێر' },
    address: {
      en: '100m Street, opposite Empire Square',
      ar: 'شارع ١٠٠ متر، مقابل ساحة الإمبراطورية',
      ku: 'شەقامی ١٠٠ مەتری، بەرامبەر گۆڕەپانی ئێمپایەر'
    },
    phone: '0750 140 6111',
    tel: '+9647501406111',
    role: { en: 'Orders and offices', ar: 'الطلبات والمكاتب', ku: 'داواکاری و ئۆفیسەکان' },
    mapQuery: 'Sadaf Office 100m Street Erbil'
  },
  {
    id: 'outlet',
    mapUrl: 'https://maps.app.goo.gl/dtwQFskCYYreWwFw9',
    name: { en: 'Sadaf Outlet', ar: 'صدف أوتلت', ku: 'سەدەف ئاوتلێت' },
    city: { en: 'Erbil', ar: 'أربيل', ku: 'هەولێر' },
    address: {
      en: 'Koya Road, Hiwa City',
      ar: 'طريق كويا، هيوا سيتي',
      ku: 'شەقامی کۆیە، هیوا سیتی'
    },
    phone: '0750 500 1940',
    tel: '+9647505001940',
    role: { en: 'Outlet prices', ar: 'أسعار الأوتلت', ku: 'نرخی ئاوتلێت' },
    mapQuery: 'Sadaf Outlet Koya Road Hiwa City Erbil'
  },
  {
    id: 'sleep-more',
    mapUrl: 'https://maps.app.goo.gl/dtwQFskCYYreWwFw9',
    name: { en: 'Sadaf Sleep & More', ar: 'صدف سليب أند مور', ku: 'سەدەف سلێپ ئەند مۆر' },
    city: { en: 'Erbil', ar: 'أربيل', ku: 'هەولێر' },
    address: {
      en: 'Koya Road, Hiwa City',
      ar: 'طريق كويا، هيوا سيتي',
      ku: 'شەقامی کۆیە، هیوا سیتی'
    },
    phone: '0750 659 7182',
    tel: '+9647506597182',
    role: { en: 'Mattresses, bedding and more', ar: 'أسرّة ومفروشات وأكثر', ku: 'دۆشەک و جێگا و زیاتر' },
    mapQuery: 'Sadaf Sleep and More Koya Road Hiwa City Erbil'
  },
  {
    id: 'group-erbil',
    mapUrl: 'https://maps.app.goo.gl/6GTgwH4foYfHXum46',
    name: { en: 'Sadaf Group, Erbil', ar: 'صدف جروب، أربيل', ku: 'سەدەف گروپ، هەولێر' },
    city: { en: 'Erbil', ar: 'أربيل', ku: 'هەولێر' },
    address: {
      en: '60m Street, near Ainkawa Bridge',
      ar: 'شارع ٦٠ متر، قرب جسر عينكاوا',
      ku: 'شەقامی ٦٠ مەتری، نزیک پردی عەینکاوا'
    },
    phone: '0750 432 2003',
    tel: '+9647504322003',
    role: { en: 'Group headquarters', ar: 'مقر المجموعة', ku: 'سەرۆکایەتی گروپ' },
    mapQuery: 'Sadaf Group 60m Street Ainkawa Bridge Erbil'
  },
  {
    id: 'plaza-sulaymaniyah',
    mapUrl: 'https://maps.app.goo.gl/8VesY1KrNBNbgGR56',
    name: { en: 'Sadaf Plaza, Sulaymaniyah', ar: 'صدف بلازا، السليمانية', ku: 'سەدەف پلازا، سلێمانی' },
    city: { en: 'Sulaymaniyah', ar: 'السليمانية', ku: 'سلێمانی' },
    address: {
      en: '60m Street, near Kobani Bridge',
      ar: 'شارع ٦٠ متر، قرب جسر كوباني',
      ku: 'شەقامی ٦٠ مەتری، نزیک پردی کۆبانێ'
    },
    phone: '0772 500 0400',
    tel: '+9647725000400',
    role: { en: 'Showroom', ar: 'معرض', ku: 'نمایشگا' },
    mapQuery: 'Sadaf Plaza 60m Street Kobani Bridge Sulaymaniyah'
  },
  {
    id: 'plaza-duhok',
    mapUrl: 'https://maps.app.goo.gl/PobbB9vJzoJuDD4aA',
    name: { en: 'Sadaf Plaza, Duhok', ar: 'صدف بلازا، دهوك', ku: 'سەدەف پلازا، دهۆک' },
    city: { en: 'Duhok', ar: 'دهوك', ku: 'دهۆک' },
    address: {
      en: 'Malta Street, opposite the old Duhok stadium',
      ar: 'شارع مالطا، مقابل ملعب دهوك القديم',
      ku: 'شەقامی ماڵتا، بەرامبەر یاریگای کۆنی دهۆک'
    },
    phone: '0750 600 0100',
    tel: '+9647506000100',
    role: { en: 'Showroom', ar: 'معرض', ku: 'نمایشگا' },
    mapQuery: 'Sadaf Plaza Malta Street Duhok'
  }
];

window.CONTACT = {
  website: 'www.sadafiq.com',
  websiteUrl: 'https://www.sadafiq.com',
  email: 'Info@sadaf-group.com',
  whatsapp: '+964 750 432 2001',
  whatsappUrl: 'https://wa.me/9647504322001',
  fastCall: '7940',
  fastCallTel: '7940',
  fastCallNote: {
    en: 'Dial 7940 from any Iraqi network — the short number reaches the showroom desk directly.',
    ar: 'اتصل بـ ٧٩٤٠ من أي شبكة عراقية — الرقم القصير يوصل مباشرة إلى مكتب المعرض.',
    ku: 'لە هەر تۆڕێکی عێراقی ژمارە ٧٩٤٠ بکە — ژمارە کورتەکە ڕاستەوخۆ دەگاتە مێزی نمایشگا.'
  },
  phones: [
    '+964 750 432 2001',
    '+964 750 140 6111',
    '+964 750 500 1940',
    '+964 750 659 7182',
    '+964 750 432 2003',
    '+964 772 500 0400',
    '+964 750 600 0100'
  ]
};

/* ---------- ABOUT ---------- */
window.ABOUT_VALUES = [
  {
    num: '01',
    title: { en: 'Sleep first', ar: 'النوم أولاً', ku: 'خەو لە پێشەوە' },
    body: {
      en: 'Every decision is judged against one question: does this help someone sleep better? Not does it look impressive on a spec sheet.',
      ar: 'كل قرار يُقاس بسؤال واحد: هل يساعد هذا أحداً على النوم بشكل أفضل؟ لا هل يبدو مثيراً في ورقة المواصفات.',
      ku: 'هەر بڕیارێک بە یەک پرسیار هەڵدەسەنگێنرێت: ئایا ئەمە یارمەتی کەسێک دەدات باشتر بنوێت؟ نەک ئایا لە لیستی تایبەتمەندیدا سەرنجڕاکێشە.'
    }
  },
  {
    num: '02',
    title: { en: 'Honest specifications', ar: 'مواصفات صادقة', ku: 'تایبەتمەندی ڕاستگۆ' },
    body: {
      en: 'We publish what we can confirm — heights, spring counts, sizes and prices — and we do not invent the rest.',
      ar: 'ننشر ما يمكننا تأكيده — الارتفاعات وعدد النوابض والمقاسات والأسعار — ولا نخترع الباقي.',
      ku: 'ئەوە بڵاودەکەینەوە کە دەتوانین دڵنیا بین لێی — بەرزی، ژمارەی سپرین، قەبارە و نرخ — و ئەوانی تر دروست ناکەین.'
    }
  },
  {
    num: '03',
    title: { en: 'Different sleepers, different mattresses', ar: 'نوّام مختلفون، أسرّة مختلفة', ku: 'نوستەی جیاواز، دۆشەکی جیاواز' },
    body: {
      en: 'A nine-model collection exists so that the answer can be specific. There is no single best mattress — only a best match.',
      ar: 'وجود مجموعة من تسعة نماذج يسمح بأن تكون الإجابة محددة. لا يوجد سرير واحد هو الأفضل — بل التوافق الأفضل.',
      ku: 'کۆلێکشنی نۆ مۆدێلی هەیە بۆ ئەوەی وەڵامەکە تایبەت بێت. هیچ دۆشەکێکی تاک نییە کە باشترین بێت — تەنها باشترین گونجان هەیە.'
    }
  },
  {
    num: '04',
    title: { en: 'Education, not pressure', ar: 'توعية لا ضغط', ku: 'فێرکردن، نەک گوشار' },
    body: {
      en: 'Our showrooms and this website are built to explain, not to push. The recommendation engine shows its reasoning, including what it did not pick.',
      ar: 'معارضنا وهذا الموقع مبنيان للشرح لا للإلحاح. ويعرض محرك التوصية منطقه، بما في ذلك ما لم يختره.',
      ku: 'نمایشگەکانمان و ئەم وێبسایتە بۆ ڕوونکردنەوە دروستکراون، نەک بۆ گوشار. بەرنامەی پێشنیارکردن هۆکارەکانی پیشان دەدات، لەگەڵ ئەوەی هەڵینەبژاردووە.'
    }
  }
];

/* ---------- RECOMMENDATION REASONING (used by the finder results) ---------- */
window.WHY = {
  pos: {
    side: {
      en: 'You sleep on your side. This model pairs a softer, pressure-relieving surface with support underneath it.',
      ar: 'تنام على جنبك. يجمع هذا النموذج بين سطح أنعم يخفف الضغط ودعم أسفله.',
      ku: 'لەسەر لاتەنیشت دەنوێیت. ئەم مۆدێلە ڕوویەکی نەرمتر کە گوشار کەم دەکاتەوە لەگەڵ پاڵپشتی ژێرەوە پێکەوە دەبەستێت.'
    },
    back: {
      en: 'You sleep on your back. The level support underneath helps keep the pelvis and shoulders from sinking unevenly.',
      ar: 'تنام على ظهرك. يساعد الدعم المستوي تحته في منع نزول الحوض والكتفين بشكل غير متساوٍ.',
      ku: 'لەسەر پشت دەنوێیت. پاڵپشتی ڕێکی ژێرەوە یارمەتی دەدات حەوز و شان بە نایەکسانی نوقم نەبن.'
    },
    stomach: {
      en: 'You sleep on your stomach. A firmer support profile is the better match, and this model scores well on it.',
      ar: 'تنام على بطنك. الدعم الأكثر صلابة هو الأنسب، وهذا النموذج يحقق نتيجة جيدة فيه.',
      ku: 'لەسەر سک دەنوێیت. پاڵپشتی ڕەقتر گونجاوترە و ئەم مۆدێلە ئەنجامی باشی تێدا دەگرێت.'
    },
    combination: {
      en: 'You change position during the night, so this model balances easy movement with support that keeps you aligned.',
      ar: 'تغيّر وضعيتك خلال الليل، لذا يوازن هذا النموذج بين سهولة الحركة والدعم الذي يحافظ على استقامتك.',
      ku: 'لە شەودا شێواز دەگۆڕیت، بۆیە ئەم مۆدێلە هاوسەنگی لە نێوان جووڵەی ئاسان و پاڵپشتی ڕێکخەر دەکات.'
    }
  },
  comfort: {
    'very-soft': {
      en: 'You asked for a very soft, cushiony feel — this is one of the softest surfaces in the collection.',
      ar: 'طلبت إحساساً ناعماً جداً ووثيراً — وهذا من أنعم الأسطح في المجموعة.',
      ku: 'ڕوویەکی زۆر نەرم و ناسکت داوا کرد — ئەمە یەکێکە لە نەرمترین ڕووەکانی کۆلێکشن.'
    },
    soft: {
      en: 'You asked for softness with support, which is exactly how this model is layered.',
      ar: 'طلبت نعومة مع دعم، وهذا تماماً أسلوب بناء هذا النموذج.',
      ku: 'نەرمی لەگەڵ پاڵپشتی داوا کرد، کە بە ڕاستی شێوازی چینکردنی ئەم مۆدێلەیە.'
    },
    medium: {
      en: 'You asked for medium support, which is where this model’s construction sits.',
      ar: 'طلبت دعماً متوسطاً، وهو مستوى بنية هذا النموذج.',
      ku: 'پاڵپشتی مامناوەندت داوا کرد، کە ئاستی پێکهاتەی ئەم مۆدێلەیە.'
    },
    firm: {
      en: 'You asked for a firm, supportive feel — this model’s support profile is on the firmer side.',
      ar: 'طلبت إحساساً صلباً وداعماً — ومستوى الدعم في هذا النموذج يميل إلى الصلابة.',
      ku: 'هەستێکی ڕەق و پاڵپشتیکەرت داوا کرد — ئاستی پاڵپشتی ئەم مۆدێلە بەرەو ڕەقی دەچێت.'
    },
    unsure: {
      en: 'Since you were not sure about comfort, your position, temperature and support answers carried more weight.',
      ar: 'بما أنك لم تكن متأكداً من الراحة، أخذت إجابات الوضعية والحرارة والدعم وزناً أكبر.',
      ku: 'چونکە دڵنیا نەبوویت لە ئاسوودەیی، وەڵامی شێواز و گەرمی و پاڵپشتی کێشی زیاتریان هەبوو.'
    }
  },
  temp: {
    hot: {
      en: 'You often feel warm in bed, so airflow and surface temperature were weighted heavily in your result.',
      ar: 'تشعر بالحرارة كثيراً في السرير، لذا أُعطي تدفق الهواء وحرارة السطح وزناً كبيراً في نتيجتك.',
      ku: 'زۆرجار لە جێخەوتن گەرم دەبیت، بۆیە تێپەڕینی هەوا و گەرمی ڕووکە کێشی زۆریان هەبوو لە ئەنجامەکەتدا.'
    },
    comfortable: {
      en: 'Your temperature is usually comfortable, so the build simply avoids trapping heat at the surface.',
      ar: 'حرارتك مريحة عادةً، لذا يكتفي البناء بتجنب احتجاز الحرارة على السطح.',
      ku: 'گەرمی لەشت بەگشتی ئاسوودەیە، بۆیە پێکهاتەکە تەنها لە گیرساندنی گەرمی لە ڕووکە دوور دەکەوێت.'
    },
    cold: {
      en: 'You get cold easily, so the layers closest to you are the ones that matter most here.',
      ar: 'تشعر بالبرودة بسهولة، لذا فإن الطبقات الأقرب إليك هي الأهم هنا.',
      ku: 'بە ئاسانی سارد دەبیتەوە، بۆیە ئەو چینانەی لە نزیکترین لە تۆن لێرە گرنگترینن.'
    },
    seasonal: {
      en: 'Your comfort changes between summer and winter, which is exactly the problem this construction was designed around.',
      ar: 'تتغير راحتك بين الصيف والشتاء، وهي بالضبط المشكلة التي صُممت هذه البنية من أجلها.',
      ku: 'ئاسوودەییت لە نێوان هاوین و زستان دەگۆڕێت، کە بە ڕاستی ئەو کێشەیەیە کە ئەم پێکهاتەیە بۆی دروستکراوە.'
    }
  },
  phys: {
    pressure: {
      en: 'Pressure relief around the shoulders and hips was your priority, so conforming comfort layers scored highest.',
      ar: 'كان تخفيف الضغط حول الكتفين والوركين أولويتك، لذا حصلت طبقات الراحة المجارية على أعلى الدرجات.',
      ku: 'کەمکردنەوەی گوشار لە شان و کەمەر پێشینەی تۆ بوو، بۆیە چینەکانی ئاسوودەیی گونجاو بەرزترین نمرەیاند گرت.'
    },
    spine: {
      en: 'Back and spine support was your priority, so support quality and alignment were weighted highest.',
      ar: 'كان دعم الظهر والعمود الفقري أولويتك، لذا حصلت جودة الدعم والاستقامة على أعلى الأوزان.',
      ku: 'پاڵپشتی پشت و بڕبڕە پێشینەی تۆ بوو، بۆیە کوالیتی پاڵپشتی و ڕێکخستن بەرزترین کێشیان هەبوو.'
    },
    joint: {
      en: 'Joint comfort was your priority, so softer, more conforming surfaces ranked higher in your result.',
      ar: 'كانت راحة المفاصل أولويتك، لذا حصلت الأسطح الأنعم والأكثر مجاراةً على ترتيب أفضل.',
      ku: 'ئاسوودەیی جومگە پێشینەی تۆ بوو، بۆیە ڕووە نەرمترەکان ترتیبی باشتریان هەبوو.'
    },
    muscle: {
      en: 'Muscle relaxation was your priority, so deeper, contouring comfort layers scored higher.',
      ar: 'كان استرخاء العضلات أولويتك، لذا حصلت طبقات الراحة الأعمق والأكثر احتضاناً على درجات أعلى.',
      ku: 'ئارامبوونەوەی ماسولکە پێشینەی تۆ بوو، بۆیە چینەکانی ئاسوودەیی قووڵتر نمرەی بەرزتریان گرت.'
    },
    general: {
      en: 'You asked for general body comfort, which keeps the balance between softness and support central.',
      ar: 'طلبت راحة عامة للجسم، وهو ما يجعل التوازن بين النعومة والدعم في المركز.',
      ku: 'ئاسوودەیی گشتی لەشت داوا کرد، کە هاوسەنگی نێوان نەرمی و پاڵپشتی دەکاتە ناوەند.'
    }
  }
};
