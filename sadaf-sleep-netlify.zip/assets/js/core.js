/* ============================================================
   SADAF SLEEP — CORE APPLICATION
   Language engine · chrome · loader · motion · compare · screensaver
   ============================================================ */
(function () {
  'use strict';

  var SS = window.SS = {};

  /* ---------------- storage (safe in sandboxed frames) ---------------- */
  var mem = {};
  var store = {
    get: function (k) {
      try { var v = localStorage.getItem(k); return v === null ? (mem[k] || null) : v; }
      catch (e) { return mem[k] || null; }
    },
    set: function (k, v) {
      mem[k] = v;
      try { localStorage.setItem(k, v); } catch (e) {}
    },
    del: function (k) {
      delete mem[k];
      try { localStorage.removeItem(k); } catch (e) {}
    }
  };
  SS.store = store;

  /* ---------------- language ---------------- */
  var LANGS = ['en', 'ku', 'ar'];
  var qs = new URLSearchParams(window.location.search);
  var current = qs.get('lang');
  if (LANGS.indexOf(current) === -1) current = store.get('sadaf.lang');
  if (LANGS.indexOf(current) === -1) current = 'en';

  SS.lang = function () { return current; };
  SS.dir = function () { return I18N.meta[current] ? I18N.meta[current].dir : 'ltr'; };
  SS.t = function (key) {
    var d = I18N[current] || {};
    return d[key] !== undefined ? d[key] : (I18N.en[key] !== undefined ? I18N.en[key] : key);
  };
  /* localised field from {en,ar,ku} */
  SS.L = function (obj) {
    if (!obj) return '';
    if (typeof obj === 'string') return obj;
    return obj[current] || obj.en || '';
  };
  /* translate a single string through the plain-text dictionary */
  SS.tx = function (str) {
    var d = (window.I18N_TEXT && window.I18N_TEXT[current]) || null;
    if (!d || !str) return str;
    var key = String(str).trim().replace(/\s+/g, ' ');
    return d[key] !== undefined ? d[key] : str;
  };

  SS.money = function (n) {
    return Number(n).toLocaleString('en-US') + ' ' + SS.t('common.currency');
  };
  SS.sizeLabel = function (w, h, withUnit) {
    return w + ' × ' + h + (withUnit === false ? '' : ' ' + SS.t('common.cm'));
  };
  /* studio product images are transparent webp cut-outs */
  SS.pimg = function (p, which) {
    if (which === 'room') return 'assets/img/' + p.room + '.jpg';
    return 'assets/img/' + p.image + '.webp';
  };
  SS.priceFrom = function (p) {
    return SS.t('common.from') + ' ' + SS.money(p.priceFrom);
  };

  /* internal link that carries the language */
  SS.href = function (path) {
    if (!path) return path;
    if (/^(https?:|mailto:|tel:|#)/.test(path)) return path;
    if (current === 'en') return path;
    var u = path.split('#')[0];
    var hash = path.indexOf('#') > -1 ? '#' + path.split('#')[1] : '';
    return u + (u.indexOf('?') > -1 ? '&' : '?') + 'lang=' + current + hash;
  };

  var langListeners = [];
  SS.onLang = function (fn) { langListeners.push(fn); };

  SS.setLang = function (lang) {
    if (LANGS.indexOf(lang) === -1 || lang === current) return;
    current = lang;
    store.set('sadaf.lang', lang);
    /* a full reload keeps server-rendered copy, data-driven copy and the
       dictionary in step, and drops any half-translated intermediate state */
    var url = new URL(window.location.href);
    if (lang === 'en') url.searchParams.delete('lang');
    else url.searchParams.set('lang', lang);
    window.location.replace(url.toString());
  };
;

  function applyLang() {
    var meta = I18N.meta[current];
    document.documentElement.setAttribute('lang', meta.htmlLang);
    document.documentElement.setAttribute('dir', meta.dir);

    document.querySelectorAll('[data-i18n]').forEach(function (el) {
      var k = el.getAttribute('data-i18n');
      el.textContent = SS.t(k);
    });
    document.querySelectorAll('[data-i18n-html]').forEach(function (el) {
      el.innerHTML = SS.t(el.getAttribute('data-i18n-html'));
    });
    document.querySelectorAll('[data-i18n-attr]').forEach(function (el) {
      el.getAttribute('data-i18n-attr').split('|').forEach(function (pair) {
        var bits = pair.split(':');
        if (bits.length === 2) el.setAttribute(bits[0].trim(), SS.t(bits[1].trim()));
      });
    });
    var titleKey = document.body.getAttribute('data-title-key');
    if (titleKey) document.title = SS.t(titleKey) + ' — Sadaf Sleep';

    // keep language in internal links
    document.querySelectorAll('a[href]').forEach(function (a) {
      var raw = a.getAttribute('href');
      if (!raw || /^(https?:|mailto:|tel:|#|javascript:)/.test(raw)) return;
      var parts = raw.split('#');
      var base = parts[0], hash = parts.length > 1 ? '#' + parts.slice(1).join('#') : '';
      var url = base.split('?');
      var params = new URLSearchParams(url[1] || '');
      if (current === 'en') params.delete('lang'); else params.set('lang', current);
      var q = params.toString();
      a.setAttribute('href', url[0] + (q ? '?' + q : '') + hash);
    });

    // language buttons
    document.querySelectorAll('[data-lang]').forEach(function (b) {
      b.classList.toggle('is-active', b.getAttribute('data-lang') === current);
      b.setAttribute('aria-checked', b.getAttribute('data-lang') === current ? 'true' : 'false');
    });
    var langBtn = document.querySelector('.lang__btn span');
    if (langBtn) langBtn.textContent = I18N.meta[current].label;
    document.querySelectorAll('[data-lang-name]').forEach(function (b) {
      b.textContent = I18N.meta[current].name;
    });
  }

  /* ---------------- plain-text dictionary layer ----------------
     Pages carry editorial English copy in the markup. Instead of tagging
     every sentence with a key, the dictionary is keyed by the English
     sentence itself, and this pass swaps the rendered text nodes.       */
  function dict() {
    return (window.I18N_TEXT && window.I18N_TEXT[current]) || null;
  }

  var SKIP = /^(SCRIPT|STYLE|NOSCRIPT|CODE|PRE|TEXTAREA)$/;

  function translateString(str) {
    var d = dict();
    if (!d) return null;
    var key = str.trim().replace(/\s+/g, ' ');
    if (!key) return null;
    if (d[key] !== undefined) return str.replace(key, d[key]);
    var pats = (window.I18N_PATTERNS && window.I18N_PATTERNS[current]) || [];
    for (var i = 0; i < pats.length; i++) {
      var m = key.match(pats[i][0]);
      if (m) {
        var out = pats[i][1];
        for (var g = 1; g < m.length; g++) out = out.replace('$' + g, m[g]);
        return str.replace(key, out);
      }
    }
    return null;
  }

  var registry = [];

  function restoreAll() {
    registry.forEach(function (e) {
      if (e.type === 'text') e.node.nodeValue = e.en;
      else e.el.setAttribute(e.attr, e.en);
    });
    registry = [];
  }

  SS.translateDom = function (root) {
    restoreAll();
    if (document.title) document.title = SS.tx(document.title);
    if (!dict()) return;
    var scope = root || document.body;
    if (!scope) return;

    var walker = document.createTreeWalker(scope, NodeFilter.SHOW_TEXT, null);
    var node;
    while ((node = walker.nextNode())) {
      if (SKIP.test(node.parentNode.nodeName)) continue;
      var raw = node.nodeValue;
      var t = translateString(raw);
      if (t !== null && t !== raw) {
        registry.push({ type: 'text', node: node, en: raw });
        node.nodeValue = t;
      }
    }

    scope.querySelectorAll('[alt],[aria-label],[placeholder],[title]').forEach(function (el) {
      ['alt', 'aria-label', 'placeholder', 'title'].forEach(function (attr) {
        var v = el.getAttribute(attr);
        if (!v) return;
        var t = translateString(v);
        if (t !== null && t !== v) {
          registry.push({ type: 'attr', el: el, attr: attr, en: v });
          el.setAttribute(attr, t);
        }
      });
    });
  };

  /* ---------------- icons ---------------- */
  SS.icon = {
    arrow: '<svg class="arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 12h15M13 5.5l6.5 6.5-6.5 6.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    arrowLong: '<svg class="arrow" width="18" height="12" viewBox="0 0 24 12" fill="none" aria-hidden="true"><path d="M0 6h22M17 1l5 5-5 5" stroke="currentColor" stroke-width="1.2"/></svg>',
    chevron: '<svg width="10" height="6" viewBox="0 0 10 6" fill="none" aria-hidden="true"><path d="M1 1l4 4 4-4" stroke="currentColor" stroke-width="1.2"/></svg>',
    close: '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true"><path d="M1 1l12 12M13 1L1 13" stroke="currentColor" stroke-width="1.2"/></svg>',
    globe: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.2"/><path d="M3 12h18M12 3c2.6 3 2.6 15 0 18M12 3c-2.6 3-2.6 15 0 18" stroke="currentColor" stroke-width="1"/></svg>',
    play: '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M3 1.5l7 4.5-7 4.5V1.5z" fill="currentColor"/></svg>',
    plus: '<svg width="10" height="10" viewBox="0 0 10 10" aria-hidden="true"><path d="M5 0v10M0 5h10" stroke="currentColor" stroke-width="1.2"/></svg>',
    phone: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 3h3l2 5-2 2a12 12 0 006 6l2-2 5 2v3a2 2 0 01-2 2A17 17 0 013 5a2 2 0 012-2z" stroke="currentColor" stroke-width="1.3"/></svg>',
    pin: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 21s7-6.3 7-11a7 7 0 10-14 0c0 4.7 7 11 7 11z" stroke="currentColor" stroke-width="1.3"/><circle cx="12" cy="10" r="2.5" stroke="currentColor" stroke-width="1.3"/></svg>',
    mail: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3" y="5" width="18" height="14" stroke="currentColor" stroke-width="1.3"/><path d="M3 6l9 7 9-7" stroke="currentColor" stroke-width="1.3"/></svg>'
  };

  /* ---------------- product card ---------------- */
  SS.cardHTML = function (p, opts) {
    opts = opts || {};
    var lang = current;
    var name = SS.L(p.name);
    var tagline = SS.L(p.tagline);
    var cls = 'mcard' + (opts.wide ? ' mcard--wide' : '') + (opts.tall ? ' mcard--tall' : '');
    var inCompare = SS.compare.has(p.id);
    var href = SS.href('product.html?model=' + p.id);
    return '' +
      '<article class="' + cls + '" data-reveal>' +
        '<div class="mcard__media">' +
          '<a href="' + href + '" aria-label="' + name + '">' +
            '<img src="' + SS.pimg(p) + '" alt="' + name + ' — ' + tagline + '" loading="lazy">' +
          '</a>' +
          '<span class="mcard__num">' + p.num + '</span>' +
          '<span class="mcard__h">' + p.height + ' ' + SS.t('common.cm') + '</span>' +
          '<div class="mcard__overlay"></div>' +
          (opts.compare ? '<button class="card-compare' + (inCompare ? ' is-on' : '') + '" data-compare="' + p.id + '" aria-pressed="' + (inCompare ? 'true' : 'false') + '">' +
            (inCompare ? '<svg width="10" height="8" viewBox="0 0 10 8" fill="none"><path d="M1 4l2.5 2.5L9 1" stroke="currentColor" stroke-width="1.4"/></svg>' : SS.icon.plus) +
            '<span>' + (inCompare ? SS.t('prod.inCompare') : SS.t('common.compare')) + '</span></button>' : '') +
        '</div>' +
        '<h3 class="mcard__name"><a href="' + href + '">' + name + '</a></h3>' +
        '<p class="mcard__tag">' + tagline + '</p>' +
        '<div class="mcard__meta">' +
          '<span>' + SS.L(p.top) + '</span><span>' + SS.L(p.construction) + '</span><span>' + SS.L(p.mainTech) + '</span>' +
        '</div>' +
        '<div class="mcard__foot">' +
          '<span class="mcard__price"><small>' + SS.t('common.from') + '</small>' + SS.money(p.priceFrom) + '</span>' +
          '<a class="link-line" href="' + href + '">' + SS.t('common.exploreDetails') + SS.icon.arrow + '</a>' +
        '</div>' +
      '</article>';
  };

  /* ---------------- compare ---------------- */
  var compareIds = [];
  try { compareIds = JSON.parse(store.get('sadaf.compare') || '[]') || []; } catch (e) { compareIds = []; }
  compareIds = compareIds.filter(function (id) { return !!window.PRODUCT_BY_ID[id]; }).slice(0, 3);

  SS.compare = {
    ids: function () { return compareIds.slice(); },
    has: function (id) { return compareIds.indexOf(id) !== -1; },
    toggle: function (id) {
      var i = compareIds.indexOf(id);
      if (i > -1) compareIds.splice(i, 1);
      else {
        if (compareIds.length >= 3) return { ok: false, reason: 'limit' };
        compareIds.push(id);
      }
      store.set('sadaf.compare', JSON.stringify(compareIds));
      SS.compare.renderTray();
      document.dispatchEvent(new CustomEvent('comparechange', { detail: { ids: compareIds.slice() } }));
      return { ok: true };
    },
    clear: function () {
      compareIds = [];
      store.set('sadaf.compare', '[]');
      SS.compare.renderTray();
      document.dispatchEvent(new CustomEvent('comparechange', { detail: { ids: [] } }));
    },
    renderTray: function () {
      var tray = document.querySelector('.compare-tray');
      if (!tray) return;
      var items = tray.querySelector('.compare-tray__items');
      var btn = tray.querySelector('[data-compare-open]');
      if (!items || !btn) return;
      if (!compareIds.length) {
        tray.classList.remove('is-on');
        items.innerHTML = '<span class="compare-tray__empty">' + SS.t('col.compare.empty') + '</span>';
        btn.setAttribute('disabled', '');
        return;
      }
      tray.classList.add('is-on');
      btn.removeAttribute('disabled');
      items.innerHTML = compareIds.map(function (id) {
        var p = PRODUCT_BY_ID[id];
        return '<span class="compare-chip">' + SS.L(p.name) +
          '<button data-compare-remove="' + id + '" aria-label="' + SS.t('col.compare.remove') + '">×</button></span>';
      }).join('');
      document.querySelectorAll('[data-compare]').forEach(function (b) {
        var on = compareIds.indexOf(b.getAttribute('data-compare')) > -1;
        b.classList.toggle('is-on', on);
        b.setAttribute('aria-pressed', on ? 'true' : 'false');
        var span = b.querySelector('span');
        if (span) span.textContent = on ? SS.t('prod.inCompare') : SS.t('common.compare');
      });
    },
    open: function () {
      if (!compareIds.length) return;
      var modal = document.getElementById('compareModal');
      if (!modal) return;
      var rows = [
        [SS.t('common.height'), function (p) { return p.height + ' ' + SS.t('common.cm'); }],
        [SS.t('prod.top'), function (p) { return SS.L(p.top); }],
        [SS.t('common.construction'), function (p) { return SS.L(p.springs); }],
        [SS.t('prod.tech'), function (p) { return p.techKeys.map(function (k) { return SS.L(TECH_LABELS[k]); }).join(', '); }],
        [SS.t('common.availableSizes'), function (p) { return p.sizes.map(function (s) { return SS.sizeLabel(s.w, s.h, false); }).join(' · '); }],
        [SS.t('common.price'), function (p) { return SS.money(p.priceFrom); }]
      ];
      var html = '<table class="ctable"><thead><tr><th>' + SS.t('col.compare.feature') + '</th>' +
        compareIds.map(function (id) {
          var p = PRODUCT_BY_ID[id];
          return '<th><img src="' + SS.pimg(p) + '" alt="' + SS.L(p.name) + '"><div>' + SS.L(p.name) + '</div></th>';
        }).join('') + '</tr></thead><tbody>' +
        rows.map(function (r) {
          return '<tr><th>' + r[0] + '</th>' + compareIds.map(function (id) {
            return '<td>' + r[1](PRODUCT_BY_ID[id]) + '</td>';
          }).join('') + '</tr>';
        }).join('') +
        '<tr><th>' + SS.t('common.priceBySize') + '</th>' + compareIds.map(function (id) {
          var p = PRODUCT_BY_ID[id];
          return '<td class="price-row">' + p.sizes.map(function (s) {
            return SS.sizeLabel(s.w, s.h, false) + ' — ' + SS.money(s.price);
          }).join('<br>') + '</td>';
        }).join('') + '</tr>' +
        '</tbody></table>' +
        '<div style="display:flex;gap:.6rem;flex-wrap:wrap;margin-top:1.4rem">' +
        compareIds.map(function (id) {
          return '<a class="btn btn--sm" href="' + SS.href('product.html?model=' + id) + '">' + SS.L(PRODUCT_BY_ID[id].name) + SS.icon.arrow + '</a>';
        }).join('') + '<button class="btn btn--sm btn--ghost" data-compare-clear>' + SS.t('common.clearAll') + '</button></div>';

      var body = modal.querySelector('[data-compare-body]');
      if (body) body.innerHTML = html;
      var title = modal.querySelector('[data-compare-title]');
      if (title) title.textContent = SS.t('col.compare.pageTitle');
      modal.classList.add('is-open');
      document.documentElement.classList.add('is-locked');
    },
    close: function () {
      var modal = document.getElementById('compareModal');
      if (modal) modal.classList.remove('is-open');
      document.documentElement.classList.remove('is-locked');
    }
  };

  /* ---------------- chrome ---------------- */
  function navItems() {
    return [
      { key: 'nav.collection', href: 'collection.html', page: 'collection', label: 'Mattresses' },
      { key: 'nav.find', href: 'find.html', page: 'find', label: 'Find my mattress' },
      { key: 'nav.tech', href: 'materials.html', page: 'materials', label: 'Materials' },
      { key: 'nav.about', href: 'about.html', page: 'about', label: 'About' },
      { key: 'nav.contact', href: 'contact.html', page: 'contact', label: 'Showrooms' }
    ];
  }

  function buildHeader() {
    var page = document.body.getAttribute('data-page') || '';
    var items = navItems();
    var links = items.map(function (i) {
      return '<li><a class="nav__link' + (i.page === page ? ' is-active' : '') + '" href="' + SS.href(i.href) + '">' + i.label + '</a></li>';
    }).join('');

    return '' +
      '<a class="skip-link" href="#main" data-i18n="nav.skip">' + SS.t('nav.skip') + '</a>' +
      '<div class="header__inner">' +
        '<a class="brand" href="' + SS.href('index.html') + '" aria-label="Sadaf Sleep">' +
          '<img class="brand__logo brand__logo--dark" src="assets/img/logo-white.png" alt="Sadaf Sleep" width="874" height="311">' +
          '<img class="brand__logo brand__logo--light" src="assets/img/logo-black.png" alt="Sadaf Sleep" width="874" height="311">' +
        '</a>' +
        '<nav class="nav" aria-label="Main"><ul class="nav__list">' + links + '</ul></nav>' +
        '<div class="header__right">' +
          '<div class="lang">' +
            '<button class="lang__btn" aria-expanded="false" aria-haspopup="true">' + SS.icon.globe + '<span>' + I18N.meta[current].label + '</span></button>' +
            '<div class="lang__menu" role="menu">' +
              LANGS.map(function (l) {
                return '<button class="lang__opt" role="menuitemradio" data-lang="' + l + '" aria-checked="' + (l === current) + '">' +
                  '<span>' + I18N.meta[l].name + '</span><small>' + I18N.meta[l].label + '</small></button>';
              }).join('') +
            '</div>' +
          '</div>' +
          '<button class="theme-btn" data-theme-toggle aria-label="Switch theme" aria-pressed="false">' +
            '<svg class="i-sun" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="4.2" stroke="currentColor" stroke-width="1.4"/><path d="M12 2.6v2.2M12 19.2v2.2M2.6 12h2.2M19.2 12h2.2M5.4 5.4l1.6 1.6M17 17l1.6 1.6M18.6 5.4L17 7M7 17l-1.6 1.6" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>' +
            '<svg class="i-moon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20 14.4A8.4 8.4 0 019.6 4a8.4 8.4 0 1010.4 10.4z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>' +
          '</button>' +
          '<a class="btn btn--gold btn--sm header__cta" href="find.html">Find my mattress</a>' +
          '<button class="burger" aria-label="Menu" aria-expanded="false" data-burger><span></span><span></span></button>' +
        '</div>' +
      '</div>';
  }

  function buildMenu() {
    var items = navItems().concat([{ key: 'nav.faq', href: 'faq.html', page: 'faq', label: 'Questions' }]);
    return '<ul class="menu__list">' + items.map(function (i, n) {
        return '<li class="menu__item"><a class="menu__link" href="' + SS.href(i.href) + '">' + i.label +
          '<small>0' + (n + 1) + '</small></a></li>';
      }).join('') + '</ul>' +
      '<div class="menu__foot">' +
        '<a class="btn btn--gold btn--block" href="' + SS.href('find.html') + '">Find my mattress</a>' +
        '<a class="link-line" href="' + SS.href('contact.html') + '">Showrooms &amp; addresses</a>' +
      '</div>';
  }

  function buildFooter() {
    var col = function (title, links) {
      return '<div class="footer__col"><h4>' + title + '</h4><ul>' +
        links.map(function (l) { return '<li><a href="' + l.href + '">' + l.label + '</a></li>'; }).join('') +
        '</ul></div>';
    };
    var models = PRODUCTS.slice(0, 4).map(function (p) {
      return { href: 'product.html?model=' + p.id, label: p.name.en };
    });
    models.push({ href: 'collection.html', label: 'All nine mattresses' });

    var shop = [
      { href: 'collection.html', label: 'Mattresses' },
      { href: 'find.html', label: 'Find my mattress' },
      { href: 'materials.html', label: 'Materials' },
      { href: 'faq.html', label: 'Questions' }
    ];
    var company = [
      { href: 'about.html', label: 'About Sadaf' },
      { href: 'contact.html', label: 'Showrooms' },
      { href: 'faq.html', label: 'Questions' },
      { href: 'contact.html', label: 'Contact us' }
    ];

    return '<div class="shell">' +
      '<div class="footer__grid">' +
        '<div class="footer__brand">' +
          '<a class="brand" href="index.html"><img class="brand__logo brand__logo--dark" src="assets/img/logo-white.png" alt="Sadaf Sleep" width="874" height="311"><img class="brand__logo brand__logo--light" src="assets/img/logo-black.png" alt="Sadaf Sleep" width="874" height="311"></a>' +
          '<p class="footer__tag">Mattresses built for how you actually sleep.</p>' +
          '<p class="small" style="max-width:32ch">Nine models, seven showrooms in Erbil, Sulaymaniyah and Duhok.</p>' +
        '</div>' +
        col('Shop', shop) +
        col('Mattresses', models) +
        col('Company', company) +
      '</div>' +
      '<div class="footer__bottom">' +
        '<span>© ' + new Date().getFullYear() + ' Sadaf Sleep. All rights reserved.</span>' +
        '<span>Erbil · Sulaymaniyah · Duhok</span>' +
      '</div>' +
    '</div>';
  }

  function buildCompareTray() {
    return '<div class="compare-tray__inner">' +
      '<span class="compare-tray__empty" style="letter-spacing:.18em;text-transform:uppercase;font-size:.58rem;color:var(--gold)">' + SS.t('col.compare.tray') + '</span>' +
      '<div class="compare-tray__items"></div>' +
      '<button class="btn btn--sm btn--gold" data-compare-open disabled>' + SS.t('col.compare.button') + '</button>' +
      '</div>';
  }

  function buildCompareModal() {
    return '<div class="modal__veil" data-close-modal></div>' +
      '<div class="modal__panel" role="dialog" aria-modal="true" aria-labelledby="compareTitle">' +
        '<button class="modal__close" data-close-modal aria-label="' + SS.t('common.close') + '">' + SS.icon.close + '</button>' +
        '<h2 id="compareTitle" data-compare-title style="font-size:clamp(1.3rem,2.4vw,2rem);font-weight:300;margin-bottom:1.4rem">' + SS.t('col.compare.pageTitle') + '</h2>' +
        '<div data-compare-body></div>' +
      '</div>';
  }

  function buildLoader() {
    return '<div class="loader__inner">' +
      '<div class="loader__stage">' +
        '<svg viewBox="0 0 600 340" fill="none" aria-hidden="true">' +
          '<polygon class="ld-fill" points="90,150 300,86 512,150 300,214"/>' +
          '<path class="ld-line" pathLength="1" style="animation-delay:calc(.05s * var(--ld-k, 1))" d="M90 150 L300 86 L512 150 L300 214 Z"/>' +
          '<path class="ld-line" pathLength="1" style="animation-delay:calc(.28s * var(--ld-k, 1))" d="M90 150 L90 206 L300 270 L300 214"/>' +
          '<path class="ld-line" pathLength="1" style="animation-delay:calc(.42s * var(--ld-k, 1))" d="M512 150 L512 206 L300 270"/>' +
          '<path class="ld-line ld-line--gold" pathLength="1" style="animation-delay:calc(.62s * var(--ld-k, 1))" d="M90 172 L300 236 L512 172"/>' +
          '<path class="ld-line" pathLength="1" style="animation-delay:calc(.74s * var(--ld-k, 1))" d="M90 194 L300 258 L512 194"/>' +
          '<path class="ld-line" pathLength="1" style="animation-delay:calc(.88s * var(--ld-k, 1))" d="M300 214 L300 270"/>' +
          '<path class="ld-line" pathLength="1" style="animation-delay:calc(1s * var(--ld-k, 1))" d="M195 118 L195 174"/>' +
          '<path class="ld-line" pathLength="1" style="animation-delay:calc(1.06s * var(--ld-k, 1))" d="M405 118 L405 174"/>' +
          '<path class="ld-line ld-line--gold" pathLength="1" style="animation-delay:calc(1.12s * var(--ld-k, 1))" d="M90 150 L300 86"/>' +
        '</svg>' +
      '</div>' +
      '<div class="loader__word">' +
        '<div class="loader__name">SADAF SLEEP</div>' +
        '<div class="loader__bar"><span></span></div>' +
        '<div class="loader__sub">Erbil · Iraq</div>' +
      '</div>' +
    '</div>';
  }

  function buildScreensaver() {
    return '<div class="screensaver__inner" data-ss-dismiss>' +
      '<div class="ss-orbit"><span class="ss-ring"></span><span class="ss-ring"></span><span class="ss-ring"></span><div class="ss-core"></div></div>' +
      '<h2 class="ss-title" data-i18n="screensaver.line1">' + SS.t('screensaver.line1') + '</h2>' +
      '<p class="ss-sub" data-i18n="screensaver.line2">' + SS.t('screensaver.line2') + '</p>' +
      '<p class="small" style="letter-spacing:.24em;text-transform:uppercase;font-size:.55rem;color:var(--muted-2)" data-i18n="screensaver.hint">' + SS.t('screensaver.hint') + '</p>' +
    '</div>';
  }

  /* ---------------- screensaver logic ---------------- */
  var IDLE_MS = 45000;
  var idleTimer = null, ssOn = false, lastTouch = Date.now();

  function blocked() {
    return document.body.classList.contains('menu-open') ||
      document.documentElement.classList.contains('is-locked') ||
      document.body.classList.contains('finder-busy') ||
      !!document.querySelector('.modal.is-open') ||
      !!document.querySelector('.lang.is-open');
  }
  function activateSS() {
    if (blocked() || ssOn) return;
    ssOn = true;
    var el = document.querySelector('.screensaver');
    if (el) { el.classList.add('is-on'); el.setAttribute('aria-hidden', 'false'); }
  }
  function dismissSS() {
    if (!ssOn) return;
    ssOn = false;
    var el = document.querySelector('.screensaver');
    if (el) { el.classList.remove('is-on'); el.setAttribute('aria-hidden', 'true'); }
    resetIdle();
  }
  function resetIdle() {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(function () { if (!blocked()) activateSS(); }, IDLE_MS);
  }
  SS.pauseScreensaver = function () { clearTimeout(idleTimer); dismissSS(); };
  SS.resumeScreensaver = function () { resetIdle(); };

  /* ---------------- reveal ---------------- */
  function initReveal(root) {
    var nodes = (root || document).querySelectorAll('[data-reveal]:not(.is-in), .line-mask:not(.is-in)');
    if (!('IntersectionObserver' in window)) {
      nodes.forEach(function (n) { n.classList.add('is-in'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          e.target.classList.add('is-in');
          io.unobserve(e.target);
        }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: .08 });
    nodes.forEach(function (n) { io.observe(n); });
  }
  SS.initReveal = initReveal;

  /* ---------------- rails ---------------- */
  SS.railify = function (rail) {
    if (!rail || rail.dataset.railified) return;
    rail.dataset.railified = '1';
    var down = false, startX = 0, startScroll = 0, moved = 0;
    rail.addEventListener('pointerdown', function (e) {
      if (e.pointerType === 'touch') return;
      down = true; moved = 0;
      startX = e.clientX; startScroll = rail.scrollLeft;
      rail.classList.add('is-dragging');
    });
    rail.addEventListener('pointermove', function (e) {
      if (!down) return;
      var dx = e.clientX - startX;
      moved = Math.abs(dx);
      if (moved > 3) rail.scrollLeft = startScroll - dx;
    });
    ['pointerup', 'pointerleave', 'pointercancel'].forEach(function (ev) {
      rail.addEventListener(ev, function () {
        down = false; rail.classList.remove('is-dragging');
      });
    });
    rail.addEventListener('click', function (e) {
      if (moved > 6) { e.preventDefault(); e.stopPropagation(); }
    }, true);
  };

  /* ---------------- init ---------------- */
  function init() {
    setTimeout(function () { SS.translateDom(); }, 20);
    var page = document.body.getAttribute('data-page');

    // loader — created here if the page markup does not carry one, so the
    // isometric mattress never goes missing again
    var loader = document.getElementById('loader');
    if (!loader) {
      loader = document.createElement('div');
      loader.id = 'loader';
      loader.className = 'loader';
      loader.setAttribute('aria-hidden', 'true');
      document.body.insertBefore(loader, document.body.firstChild);
      document.body.classList.add('loading');
    }
    if (loader) {
      var seen = false;
      try { seen = sessionStorage.getItem('sadaf.seen') === '1'; } catch (e) {}
      loader.innerHTML = buildLoader();
      var minTime = seen ? 900 : 1750;
      if (seen) loader.style.setProperty('--ld-k', '.55');
      var done = function () {
        setTimeout(function () {
          loader.classList.add('is-done');
          try { sessionStorage.setItem('sadaf.seen', '1'); } catch (e) {}
          setTimeout(function () { loader.style.display = 'none'; }, 900);
          loader.setAttribute('data-done', '1');
          setTimeout(function () { document.body.classList.remove('loading'); }, 200);
        }, Math.max(0, minTime - performance.now()));
      };
      if (document.readyState === 'complete') done();
      else window.addEventListener('load', done);
      setTimeout(function () { loader.classList.add('is-done'); }, 6000); // failsafe
    }

    // header
    var header = document.getElementById('header');
    if (header) {
      header.innerHTML = buildHeader();
      var onScroll = function () {
        header.classList.toggle('is-stuck', window.scrollY > 24);
      };
      onScroll();
      window.addEventListener('scroll', onScroll, { passive: true });
    }

    // menu
    var menu = document.getElementById('menu');
    if (menu) menu.innerHTML = buildMenu();

    // footer
    var footer = document.getElementById('footer');
    if (footer) footer.innerHTML = buildFooter();

    // compare UI
    var tray = document.getElementById('compareTray');
    if (tray) {
      tray.innerHTML = buildCompareTray();
      tray.classList.add('compare-tray');
    }
    var modal = document.getElementById('compareModal');
    if (modal) { modal.classList.add('modal'); modal.innerHTML = buildCompareModal(); }

    // screensaver
    var ss = document.getElementById('screensaver');
    if (ss) { ss.classList.add('screensaver'); ss.innerHTML = buildScreensaver(); }

    applyLang();

    // interactions
    document.addEventListener('click', function (e) {
      var t = e.target;

      var themeBtn = t.closest('[data-theme-toggle]');
      if (themeBtn) {
        var next = (document.documentElement.getAttribute('data-theme') === 'light') ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', next);
        themeBtn.setAttribute('aria-pressed', next === 'light' ? 'true' : 'false');
        try { localStorage.setItem('sadaf.theme', next); } catch (e) {}
        return;
      }

      var burger = t.closest('[data-burger]');
      if (burger) {
        var open = document.body.classList.toggle('menu-open');
        burger.setAttribute('aria-expanded', open ? 'true' : 'false');
        document.documentElement.classList.toggle('is-locked', open);
        if (open) SS.pauseScreensaver(); else SS.resumeScreensaver();
        return;
      }

      var langBtn = t.closest('.lang__btn');
      if (langBtn) {
        var wrap = langBtn.closest('.lang');
        var isOpen = wrap.classList.toggle('is-open');
        langBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        return;
      }
      var langOpt = t.closest('[data-lang]');
      if (langOpt) {
        SS.setLang(langOpt.getAttribute('data-lang'));
        var w = langOpt.closest('.lang');
        if (w) { w.classList.remove('is-open'); var b = w.querySelector('.lang__btn'); if (b) b.setAttribute('aria-expanded', 'false'); }
        return;
      }
      if (!t.closest('.lang')) {
        document.querySelectorAll('.lang.is-open').forEach(function (l) { l.classList.remove('is-open'); });
      }

      if (t.closest('[data-ss-dismiss]') || t.closest('.screensaver')) { dismissSS(); return; }

      var cmp = t.closest('[data-compare]');
      if (cmp) {
        e.preventDefault();
        var res = SS.compare.toggle(cmp.getAttribute('data-compare'));
        if (!res.ok) { flash(SS.t('col.compare.limit')); }
        else {
          document.querySelectorAll('[data-compare]').forEach(function (b) {
            var on = SS.compare.has(b.getAttribute('data-compare'));
            b.classList.toggle('is-on', on);
            b.setAttribute('aria-pressed', on ? 'true' : 'false');
            var s = b.querySelector('span'); if (s) s.textContent = on ? SS.t('prod.inCompare') : SS.t('common.compare');
          });
        }
        return;
      }
      var rm = t.closest('[data-compare-remove]');
      if (rm) { SS.compare.toggle(rm.getAttribute('data-compare-remove')); return; }
      if (t.closest('[data-compare-open]')) { SS.compare.open(); return; }
      if (t.closest('[data-compare-clear]')) { SS.compare.clear(); SS.compare.close(); return; }
      if (t.closest('[data-close-modal]')) { SS.compare.close(); return; }

      // rail nav
      var railBtn = t.closest('[data-rail]');
      if (railBtn) {
        var rail = document.querySelector(railBtn.getAttribute('data-rail'));
        var dir = railBtn.getAttribute('data-dir') === 'next' ? 1 : -1;
        if (document.documentElement.dir === 'rtl') dir *= -1;
        if (rail) rail.scrollBy({ left: dir * Math.min(rail.clientWidth * .8, 520), behavior: 'smooth' });
        return;
      }
    });

    // screensaver activity
    ['pointerdown', 'pointermove', 'keydown', 'wheel', 'touchstart', 'scroll'].forEach(function (ev) {
      window.addEventListener(ev, function () {
        lastTouch = Date.now();
        if (ssOn) { dismissSS(); return; }
        if (!blocked()) resetIdle();
      }, { passive: true });
    });
    resetIdle();

    // rails
    document.querySelectorAll('.rail, .rel-rail').forEach(SS.railify);

    // reveals
    initReveal();

    // mark compare state
    SS.compare.renderTray();

    // hero content should always be visible immediately (first impression)
    setTimeout(function () {
      document.querySelectorAll('.hero [data-reveal], .hero .line-mask').forEach(function (n) { n.classList.add('is-in'); });
    }, 120);

    // reduce motion preference
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      document.documentElement.classList.add('reduce-motion');
    }

    // expose re-render on language change
    SS.onLang(function () {
      SS.compare.renderTray();
      initReveal();
    });
  }

  /* tiny toast */
  function flash(msg) {
    var el = document.createElement('div');
    el.textContent = msg;
    el.setAttribute('role', 'status');
    el.style.cssText = 'position:fixed;inset-block-end:24px;inset-inline:0;margin:auto;width:max-content;max-width:90vw;background:#CFAE6B;color:#202126;padding:.7rem 1.1rem;font-size:.78rem;font-weight:500;z-index:400;border-radius:2px;font-family:inherit';
    document.body.appendChild(el);
    setTimeout(function () { el.style.transition = 'opacity .5s'; el.style.opacity = '0'; }, 2600);
    setTimeout(function () { el.remove(); }, 3200);
  }
  SS.flash = flash;

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
