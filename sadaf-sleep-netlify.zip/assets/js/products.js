/* ============================================================
   SADAF SLEEP — PRODUCT DATA (single source of truth)
   Used by: collection grid, product pages, comparison,
   recommendation engine, home page, finder results.
   ============================================================ */

window.PRODUCTS = [
  /* ---------------- 01 SILVER TECH ---------------- */
  {
    id: 'silver-tech',
    num: '01',
    order: 1,
    image: 'silver-tech',
    room: 'silver-tech-room',
    name: { en: 'Silver Tech', ar: 'سيلفر تك', ku: 'سیلڤەر تێک' },
    tagline: {
      en: 'Silver ion protection. Double pocket spring support.',
      ar: 'حماية بأيونات الفضة. دعم بنوابض جيبية مزدوجة.',
      ku: 'پاراستن بە زیو ئایۆن. پاڵپشتی سپرینی گیرفانی دووانە.'
    },
    height: 30,
    topKey: 'box',
    top: { en: 'Box top', ar: 'سطح صندوقي', ku: 'سەرەوەی سندوقی' },
    springKey: 'pocket',
    springs: {
      en: '1500C + 1500C double pocket springs',
      ar: 'نوابض جيبية مزدوجة 1500C + 1500C',
      ku: 'سپرینی گیرفانی دووانە 1500C + 1500C'
    },
    construction: { en: 'Pocket spring', ar: 'نوابض جيبية', ku: 'سپرینی گیرفانی' },
    mainTech: { en: 'Silver-ion linen', ar: 'كتان بأيونات الفضة', ku: 'کەتانی زیو ئایۆن' },
    techKeys: ['pocket-twin', 'silver', 'linen'],
    filters: ['hygiene', 'spine', 'support'],
    sizes: [
      { w: 180, h: 200, price: 1350000 },
      { w: 200, h: 200, price: 1240000 }
    ],
    overview: {
      en: 'Silver Tech pairs a silver-ion linen cover with a double pocket spring system — two 1500C spring units working together. The box top gives the mattress a structured, even surface, while reinforced edge support keeps the perimeter stable. It is our most hygiene-focused model, built around a fabric with a confirmed 99.9% antibacterial figure.',
      ar: 'يجمع سيلفر تك بين غطاء من الكتان بأيونات الفضة ونظام نوابض جيبية مزدوج، أي وحدتي نوابض 1500C تعملان معاً. يمنح السطح الصندوقي السرير سطحاً منتظماً ومتماسكاً، ويحافظ الدعم المحيطي المعزّز على ثبات الأطراف. وهو النموذج الأكثر تركيزاً على النظافة في مجموعتنا، ويقوم على قماش مؤكد بنسبة ٩٩.٩٪ ضد البكتيريا.',
      ku: 'سیلڤەر تێک ڕووپۆشێکی کەتانی زیو ئایۆن لەگەڵ سیستەمی سپرینی گیرفانی دووانە پێکەوە دەبەستێت — دوو یەکەی سپرینی 1500C کە پێکەوە کار دەکەن. سەرەوەی سندوقی ڕوویەکی ڕێک و بەهێز دەبەخشێت، و پاڵپشتی لاتەنیشتی بەهێزکراو لاتەنیشتەکان جێگیر دەهێڵێت. زیاترین مۆدێلە لە ڕووی پاکوخاوێنییەوە، لەسەر قوماشێک کە ٩٩.٩٪ دژە بەکتریا بۆی دەستنیشان کراوە.'
    },
    who: {
      en: 'Designed for sleepers who want structured medium support with a cleaner surface, and for households where hygiene and easy maintenance matter.',
      ar: 'مصممة لمن يريد دعماً متوسطاً متماسكاً بسطح أنظف، وللمنازل التي تُعطي النظافة وسهولة العناية أهمية.',
      ku: 'بۆ ئەو کەسانە دروستکراوە کە پاڵپشتی مامناوەندی بەهێز و ڕوویەکی پاکتر دەوێت، و بۆ ئەو ماڵانەی پاکوخاوێنی و ئاسانی چاودێری گرنگە.'
    },
    features: {
      en: [
        'Silver-ion linen cover with a confirmed 99.9% antibacterial figure',
        '1500C + 1500C double pocket spring support — two spring units',
        'Reinforced edge support for a stable perimeter',
        'Box top surface for an even, structured feel',
        '30 cm total height, medium support'
      ],
      ar: [
        'غطاء كتان بأيونات الفضة بنسبة مؤكدة ٩٩.٩٪ ضد البكتيريا',
        'دعم بنوابض جيبية مزدوجة 1500C + 1500C — وحدتا نوابض',
        'دعم محيطي معزّز لأطراف ثابتة',
        'سطح صندوقي لإحساس منتظم ومتماسك',
        'ارتفاع ٣٠ سم، دعم متوسط'
      ],
      ku: [
        'ڕووپۆشی کەتانی زیو ئایۆن بە ڕێژەی ٩٩.٩٪ دژە بەکتریا',
        'پاڵپشتی سپرینی گیرفانی دووانە 1500C + 1500C — دوو یەکە',
        'پاڵپشتی لاتەنیشتی بەهێزکراو بۆ لاتەنیشتی جێگیر',
        'سەرەوەی سندوقی بۆ هەستی ڕێک و بەهێز',
        'بەرزی ٣٠ سم، پاڵپشتی مامناوەند'
      ]
    },
    layers: [
      {
        name: { en: 'Silver-ion linen cover', ar: 'غطاء كتان بأيونات الفضة', ku: 'ڕووپۆشی کەتانی زیو ئایۆن' },
        pos: { en: 'Top surface', ar: 'السطح العلوي', ku: 'ڕووی سەرەوە' },
        desc: {
          en: 'A linen fabric treated with silver ions. A 99.9% antibacterial figure is confirmed for this cover, making the sleeping surface the model’s defining feature.',
          ar: 'قماش كتان معالج بأيونات الفضة. النسبة المؤكدة ٩٩.٩٪ ضد البكتيريا لهذا الغطاء، وهو ما يجعل سطح النوم السمة المميزة للنموذج.',
          ku: 'قوماشی کەتانی بە زیو ئایۆن چارەسەرکراو. ڕێژەی ٩٩.٩٪ دژە بەکتریا بۆ ئەم ڕووپۆشە دەستنیشان کراوە، و ئەمە ڕووی نوستن دەکاتە تایبەتمەندی سەرەکی مۆدێلەکە.'
        }
      },
      {
        name: { en: 'Box top comfort panel', ar: 'لوح راحة للسطح الصندوقي', ku: 'پانێلی ئاسوودەیی سەرەوەی سندوقی' },
        pos: { en: 'Upper construction', ar: 'البنية العلوية', ku: 'پێکهاتەی سەرەوە' },
        desc: {
          en: 'The box-top build gives the surface a flat, structured character rather than a pillow-top curve — an even platform across the whole sleeping area.',
          ar: 'تمنح بنية السطح الصندوقي السطح طابعاً مستوياً ومتماسكاً بدل انحناء سطح الوسادة — منصة منتظمة على كامل مساحة النوم.',
          ku: 'پێکهاتەی سەرەوەی سندوقی ڕووەکە ڕێک و بەهێز دەکات، نەک چەماوەی سەرینی — سەکۆیەکی ڕێک بەسەر هەموو ڕووی نوستن.'
        }
      },
      {
        name: { en: 'Upper 1500C pocket spring unit', ar: 'وحدة نوابض جيبية 1500C العلوية', ku: 'یەکەی سپرینی گیرفانی 1500C ی سەرەوە' },
        pos: { en: 'Support core', ar: 'قلب الدعم', ku: 'ناوەندی پاڵپشتی' },
        desc: {
          en: 'The first of two 1500C spring units. Each spring is individually pocketed, so it responds to the load directly above it instead of pulling its neighbours.',
          ar: 'أول وحدتي نوابض 1500C. كل نابض موضوع في جيب مستقل، فيستجيب للحمل الذي فوقه بدل أن يشد جيرانه.',
          ku: 'یەکەمین لە دوو یەکەی سپرینی 1500C. هەر سپرینێک لە گیرفانی سەربەخۆدایە، بۆیە بۆ ئەو گوشارەی لە سەرووی خۆیەتی وەڵام دەداتەوە.'
        }
      },
      {
        name: { en: 'Lower 1500C pocket spring unit', ar: 'وحدة نوابض جيبية 1500C السفلية', ku: 'یەکەی سپرینی گیرفانی 1500C ی خوارەوە' },
        pos: { en: 'Support core', ar: 'قلب الدعم', ku: 'ناوەندی پاڵپشتی' },
        desc: {
          en: 'The second 1500C unit completes the double-spring construction, adding depth and progressive resistance to the support.',
          ar: 'تكمل وحدة 1500C الثانية بنية النوابض المزدوجة، مضيفةً عمقاً ومقاومة تدريجية للدعم.',
          ku: 'دووەم یەکەی 1500C پێکهاتەی سپرینی دووانە تەواو دەکات و قووڵی و بەرگری پلەپلە زیاد دەکات.'
        }
      },
      {
        name: { en: 'Reinforced edge support', ar: 'دعم محيطي معزّز', ku: 'پاڵپشتی لاتەنیشتی بەهێزکراو' },
        pos: { en: 'Perimeter', ar: 'المحيط', ku: 'دەوروبەر' },
        desc: {
          en: 'A reinforced border stabilises the mattress edge, so the usable sleeping surface holds up when you sit on the side or sleep close to it.',
          ar: 'إطار معزّز يثبّت حافة السرير، فيبقى سطح النوم القابل للاستخدام متماسكاً عند الجلوس على الحافة أو النوم قريباً منها.',
          ku: 'سنوورێکی بەهێزکراو لاتەنیشتی دۆشەکەکە جێگیر دەکات، بۆ ئەوەی ڕووی نوستن بەهێز بێت کاتێک لە لاتەنیشتەوە دادەنیشیت یان لە نزیکەوە دەنوێیت.'
        }
      }
    ],
    score: {
      position: { side: 0.72, back: 0.92, stomach: 0.84, combination: 0.82 },
      comfort: 3.2,
      temp: { hot: 0.62, comfortable: 0.82, cold: 0.6, seasonal: 0.5 },
      physical: { pressure: 0.72, spine: 0.92, joint: 0.86, muscle: 0.62, general: 0.84 },
      materials: { natural: 0.42, memory: 0.2, pocket: 1, antibacterial: 0.98, cooling: 0.45, foam: 0.1 },
      extras: { motion: 0.95, breathable: 0.82, hotel: 0.35, extraSoft: 0.15, supportive: 1, seasonal: 0.45, antibacterial: 0.98 }
    }
  },

  /* ---------------- 02 BIOLATEX ---------------- */
  {
    id: 'biolatex',
    num: '02',
    order: 2,
    image: 'biolatex',
    room: 'biolatex-room',
    name: { en: 'Biolatex', ar: 'بيولاتكس', ku: 'بیولاتێکس' },
    tagline: {
      en: 'From nature to your bedroom. Antistress protection.',
      ar: 'من الطبيعة إلى غرفتك. حماية من الإجهاد.',
      ku: 'لە سروشتەوە بۆ ژوورەکەت. پاراستن لە فشار.'
    },
    height: 40,
    topKey: 'pillow',
    top: { en: 'Pillow top', ar: 'سطح وسادة', ku: 'سەرەوەی سەرین' },
    springKey: 'pocket',
    springs: {
      en: '1500C + 1500C double pocket springs',
      ar: 'نوابض جيبية مزدوجة 1500C + 1500C',
      ku: 'سپرینی گیرفانی دووانە 1500C + 1500C'
    },
    construction: { en: 'Pocket spring with natural latex', ar: 'نوابض جيبية مع لاتكس طبيعي', ku: 'سپرینی گیرفانی لەگەڵ لاتێکسی سروشتی' },
    mainTech: { en: 'Natural latex & horsehair', ar: 'لاتكس طبيعي وشعر خيل', ku: 'لاتێکسی سروشتی و مووی ئەسپ' },
    techKeys: ['pocket-twin', 'latex', 'horsehair', 'rock-salt'],
    filters: ['natural', 'luxury', 'spine', 'soft'],
    sizes: [
      { w: 180, h: 200, price: 2100000 },
      { w: 200, h: 200, price: 2292000 }
    ],
    overview: {
      en: 'Biolatex is the most natural model in the collection and the tallest at 40 cm. A rock-salt linen cover wraps a pillow-top construction built with horsehair and natural latex over a 1500C + 1500C double pocket spring system. Latex gives a resilient, springy comfort; horsehair is used for its natural breathability. The result is a soft-but-supportive surface with the closest thing to a hotel feel we make in natural materials.',
      ar: 'بيولاتكس هو النموذج الأكثر طبيعية في المجموعة والأعلى بارتفاع ٤٠ سم. غطاء من الكتان بالملح الصخري يحيط ببنية سطح وسادة مصنوعة من شعر الخيل واللاتكس الطبيعي فوق نظام نوابض جيبية مزدوج 1500C + 1500C. يمنح اللاتكس راحة مرنة ونابضة، ويُستخدم شعر الخيل لقابليته الطبيعية للتنفس. النتيجة سطح ناعم لكنه داعم، بأقرب إحساس فندقي نقدمه بالمواد الطبيعية.',
      ku: 'بیولاتێکس سروشتیترین مۆدێلی کۆلێکشنەکەیە و بەرزترینیشە بە ٤٠ سم. ڕووپۆشێکی کەتانی خوێی بەرد بە دەوری پێکهاتەی سەرەوەی سەرین دەدات کە لە مووی ئەسپ و لاتێکسی سروشتی پێکهاتووە لەسەر سیستەمی سپرینی گیرفانی دووانە 1500C + 1500C. لاتێکس ئاسوودەییەکی فنەری و بەهێز دەدات، و مووی ئەسپ بۆ هەناسەدانی سروشتی بەکاردێت. ئەنجام ڕوویەکی نەرم بەڵام پاڵپشتیکەرە، بە نزیکترین هەستی هۆتێل کە بە کەرەستەی سروشتی پێشکەشی دەکەین.'
    },
    who: {
      en: 'Designed for sleepers who want a tall, plush, natural surface, who lie on their side or move between positions, and who react to warmth with synthetic foams.',
      ar: 'مصممة لمن يريد سطحاً عالياً وناعماً وطبيعياً، وينام على جنبه أو يغيّر وضعيته، ويتأثر بالحرارة مع الإسفنج الصناعي.',
      ku: 'بۆ ئەو کەسانە دروستکراوە کە ڕوویەکی بەرز و نەرم و سروشتیان دەوێت، لەسەر لاتەنیشت دەنوێن یان شێواز دەگۆڕن، و لە فۆمی دەستکرد گەرم دەبن.'
    },
    features: {
      en: [
        'Natural latex comfort layer',
        'Horsehair layer for natural breathability',
        'Rock-salt linen cover',
        '1500C + 1500C double pocket spring support',
        'Pillow top surface, 40 cm — the tallest model in the collection'
      ],
      ar: [
        'طبقة راحة من اللاتكس الطبيعي',
        'طبقة شعر خيل لقابلية تنفس طبيعية',
        'غطاء كتان بالملح الصخري',
        'دعم بنوابض جيبية مزدوجة 1500C + 1500C',
        'سطح وسادة بارتفاع ٤٠ سم — الأعلى في المجموعة'
      ],
      ku: [
        'چینی ئاسوودەیی لاتێکسی سروشتی',
        'چینی مووی ئەسپ بۆ هەناسەدانی سروشتی',
        'ڕووپۆشی کەتانی خوێی بەرد',
        'پاڵپشتی سپرینی گیرفانی دووانە 1500C + 1500C',
        'سەرەوەی سەرین بە ٤٠ سم — بەرزترین مۆدێلی کۆلێکشن'
      ]
    },
    layers: [
      {
        name: { en: 'Rock-salt linen cover', ar: 'غطاء كتان بالملح الصخري', ku: 'ڕووپۆشی کەتانی خوێی بەرد' },
        pos: { en: 'Top surface', ar: 'السطح العلوي', ku: 'ڕووی سەرەوە' },
        desc: {
          en: 'A linen cover incorporating rock salt, the material that gives Biolatex its natural, mineral-led character.',
          ar: 'غطاء كتان يحتوي على الملح الصخري، المادة التي تمنح بيولاتكس طابعه الطبيعي المعدني.',
          ku: 'ڕووپۆشێکی کەتانی تێیدا خوێی بەرد هەیە، ئەو کەرەستەیەی کە تایبەتمەندی سروشتی و کانزایی بە بیولاتێکس دەبەخشێت.'
        }
      },
      {
        name: { en: 'Pillow top', ar: 'سطح وسادة', ku: 'سەرەوەی سەرین' },
        pos: { en: 'Upper comfort', ar: 'الراحة العلوية', ku: 'ئاسوودەیی سەرەوە' },
        desc: {
          en: 'An integrated pillow-top layer gives the mattress its soft, generous first impression — the surface you feel before the support underneath.',
          ar: 'طبقة سطح الوسادة المدمجة تمنح السرير انطباعه الأول الناعم والكريم — السطح الذي تشعر به قبل الدعم الذي تحته.',
          ku: 'چینی سەرەوەی سەرینی یەکگرتوو هەستی یەکەمی نەرم و فراوان دەبەخشێت — ئەو ڕووەی کە پێش پاڵپشتی ژێرەوە هەستی پێدەکەیت.'
        }
      },
      {
        name: { en: 'Horsehair layer', ar: 'طبقة شعر الخيل', ku: 'چینی مووی ئەسپ' },
        pos: { en: 'Comfort layer', ar: 'طبقة الراحة', ku: 'چینی ئاسوودەیی' },
        desc: {
          en: 'Horsehair is one of the oldest natural mattress fillings. Its crimped fibres create open space for air to move, which is why it is used as a breathable comfort layer.',
          ar: 'شعر الخيل من أقدم حشوات الأسرّة الطبيعية. أليافه المموجة تخلق فراغات لحركة الهواء، ولهذا يُستخدم كطبقة راحة قابلة للتنفس.',
          ku: 'مووی ئەسپ یەکێکە لە کۆنترین پڕکەرەوە سروشتییەکانی دۆشەک. ڕیشاڵە چەماوەکانی بۆشایی دەهێڵن بۆ جووڵەی هەوا، بۆیە وەک چینی ئاسوودەیی هەناسەدەر بەکاردێت.'
        }
      },
      {
        name: { en: 'Natural latex layer', ar: 'طبقة لاتكس طبيعي', ku: 'چینی لاتێکسی سروشتی' },
        pos: { en: 'Comfort layer', ar: 'طبقة الراحة', ku: 'چینی ئاسوودەیی' },
        desc: {
          en: 'Natural latex is resilient and elastic: it pushes back where you press and recovers immediately, giving a springy, contouring comfort without sinking.',
          ar: 'اللاتكس الطبيعي مرن ومطاطي: يدفع في موضع الضغط ويعود فوراً، فيمنح راحة نابضة تتبع الجسم دون غرق.',
          ku: 'لاتێکسی سروشتی فنەر و کشۆڵەیە: لە شوێنی گوشار پاڵ دەنێت و خێرا دەگەڕێتەوە، ئاسوودەییەکی بەهێز دەدات بەبێ نوقمبوون.'
        }
      },
      {
        name: { en: 'Upper 1500C pocket spring unit', ar: 'وحدة نوابض جيبية 1500C العلوية', ku: 'یەکەی سپرینی گیرفانی 1500C ی سەرەوە' },
        pos: { en: 'Support core', ar: 'قلب الدعم', ku: 'ناوەندی پاڵپشتی' },
        desc: {
          en: 'Individually pocketed springs respond locally to each part of the body, which is what allows a soft top to remain supportive.',
          ar: 'تستجيب النوابض الجيبية المستقلة محلياً لكل جزء من الجسم، وهذا ما يسمح لسطح ناعم بأن يبقى داعماً.',
          ku: 'سپرینە گیرفانییە سەربەخۆکان بە شێوەی خۆجێیی بۆ هەر بەشێکی لەش وەڵام دەدەنەوە، ئەمەیش ڕێگە دەدات ڕوویەکی نەرم پاڵپشتیکەر بمێنێتەوە.'
        }
      },
      {
        name: { en: 'Lower 1500C pocket spring unit', ar: 'وحدة نوابض جيبية 1500C السفلية', ku: 'یەکەی سپرینی گیرفانی 1500C ی خوارەوە' },
        pos: { en: 'Support core', ar: 'قلب الدعم', ku: 'ناوەندی پاڵپشتی' },
        desc: {
          en: 'The second spring unit adds the depth that carries a 40 cm mattress — more travel in the support, so the comfort layers above can do their work.',
          ar: 'تضيف وحدة النوابض الثانية العمق الذي يحمل سرير بارتفاع ٤٠ سم — مساحة حركة أكبر في الدعم، لتعمل طبقات الراحة فوقها كما يجب.',
          ku: 'دووەم یەکەی سپرین ئەو قووڵییە دەبەخشێت کە دۆشەکی ٤٠ سم هەڵدەگرێت — جووڵەی زیاتر لە پاڵپشتیدا، بۆ ئەوەی چینەکانی سەرەوە کارەکەیان بکەن.'
        }
      }
    ],
    score: {
      position: { side: 0.94, back: 0.82, stomach: 0.62, combination: 0.9 },
      comfort: 2.5,
      temp: { hot: 0.86, comfortable: 0.86, cold: 0.66, seasonal: 0.7 },
      physical: { pressure: 0.94, spine: 0.8, joint: 0.82, muscle: 0.96, general: 0.9 },
      materials: { natural: 1, memory: 0.2, pocket: 1, antibacterial: 0.55, cooling: 0.72, foam: 0.05 },
      extras: { motion: 0.95, breathable: 1, hotel: 0.98, extraSoft: 0.6, supportive: 0.8, seasonal: 0.62, antibacterial: 0.55 }
    }
  },

  /* ---------------- 03 THERMO MEMORY ---------------- */
  {
    id: 'thermo-memory',
    num: '03',
    order: 3,
    image: 'thermo-memory',
    room: 'thermo-memory-room',
    name: { en: 'Thermo Memory', ar: 'ثيرمو ميموري', ku: 'تێرمۆ مێمۆری' },
    tagline: {
      en: 'Smart cooling fabric. Deep muscle relief.',
      ar: 'قماش تبريد ذكي. راحة عميقة للعضلات.',
      ku: 'قوماشی ساردکردنەوەی زیرەک. ئارامی قووڵی ماسولکە.'
    },
    height: 39,
    topKey: 'quilted',
    top: { en: 'Quilted', ar: 'مبطّن', ku: 'چنارەکراو' },
    springKey: 'pocket',
    springs: { en: '1000C pocket springs', ar: 'نوابض جيبية 1000C', ku: 'سپرینی گیرفانی 1000C' },
    construction: { en: 'Pocket spring with gel memory foam', ar: 'نوابض جيبية مع إسفنج ذاكرة بالجل', ku: 'سپرینی گیرفانی لەگەڵ فۆمی بیرگەی جێل' },
    mainTech: { en: 'PCM cooling fabric', ar: 'قماش تبريد PCM', ku: 'قوماشی ساردکردنەوەی PCM' },
    techKeys: ['pcm', 'gel-memory', 'pocket'],
    filters: ['cooling', 'soft', 'spine'],
    sizes: [{ w: 180, h: 200, price: 804000 }],
    overview: {
      en: 'Thermo Memory is built for sleepers who run warm. A PCM (phase change material) fabric sits in the quilted surface and works to regulate temperature at the skin, while gel memory foam below it conforms to the body and helps distribute pressure. The 1000C pocket spring unit underneath provides the support. At 39 cm it is the second-tallest model in the collection.',
      ar: 'صُممت ثيرمو ميموري لمن يشعر بالحرارة أثناء النوم. قماش PCM (مادة تغيّر الطور) في السطح المبطّن يعمل على تنظيم الحرارة عند الجلد، بينما يتبع إسفنج الذاكرة بالجل شكل الجسم ويساعد في توزيع الضغط. وتوفر وحدة النوابض الجيبية 1000C تحته الدعم. بارتفاع ٣٩ سم، هو ثاني أعلى نموذج في المجموعة.',
      ku: 'تێرمۆ مێمۆری بۆ ئەو کەسانە دروستکراوە کە لە کاتی خەودا گەرم دەبن. قوماشی PCM لە ڕووی چنارەکراودایە و گەرمی پێست ڕێکدەخات، و فۆمی بیرگەی جێل لە ژێرەوە لەگەڵ لەش دەگونجێت و یارمەتی دابەشکردنی گوشار دەدات. یەکەی سپرینی گیرفانی 1000C لە خوارەوە پاڵپشتی دەدات. بە ٣٩ سم، دووەم بەرزترین مۆدێلی کۆلێکشنە.'
    },
    who: {
      en: 'Designed for warm sleepers and for anyone who wants pressure relief and deep muscle comfort in a soft, contouring surface.',
      ar: 'مصممة لمن يشعر بالحرارة أثناء النوم ولمن يريد تخفيف الضغط وراحة عضلية عميقة في سطح ناعم يتبع الجسم.',
      ku: 'بۆ ئەو کەسانە دروستکراوە کە گەرم دەبن لە خەودا و بۆ هەر کەسێک کە کەمکردنەوەی گوشار و ئارامی قووڵی ماسولکە دەوێت لە ڕوویەکی نەرم.'
    },
    features: {
      en: [
        'PCM temperature-regulating fabric',
        'Gel memory foam comfort layer',
        '1000C pocket spring unit',
        'Quilted surface',
        '39 cm height'
      ],
      ar: [
        'قماش PCM لتنظيم الحرارة',
        'طبقة راحة من إسفنج الذاكرة بالجل',
        'وحدة نوابض جيبية 1000C',
        'سطح مبطّن',
        'ارتفاع ٣٩ سم'
      ],
      ku: [
        'قوماشی PCM بۆ ڕێکخستنی گەرمی',
        'چینی ئاسوودەیی فۆمی بیرگەی جێل',
        'یەکەی سپرینی گیرفانی 1000C',
        'ڕووی چنارەکراو',
        'بەرزی ٣٩ سم'
      ]
    },
    layers: [
      {
        name: { en: 'Quilted surface fabric', ar: 'قماش السطح المبطّن', ku: 'قوماشی ڕووی چنارەکراو' },
        pos: { en: 'Top surface', ar: 'السطح العلوي', ku: 'ڕووی سەرەوە' },
        desc: {
          en: 'The quilted top gives the mattress its soft, finished surface and holds the layers beneath it in place.',
          ar: 'يمنح السطح المبطّن السرير سطحه الناعم والمكتمل ويثبّت الطبقات تحته.',
          ku: 'ڕووی چنارەکراو ڕوویەکی نەرم و تەواو دەبەخشێت و چینەکانی ژێرەوە جێگیر دەکات.'
        }
      },
      {
        name: { en: 'PCM temperature-regulating fabric', ar: 'قماش PCM لتنظيم الحرارة', ku: 'قوماشی PCM بۆ ڕێکخستنی گەرمی' },
        pos: { en: 'Upper comfort', ar: 'الراحة العلوية', ku: 'ئاسوودەیی سەرەوە' },
        desc: {
          en: 'PCM — phase change material — absorbs heat as the surface warms and releases it again as it cools, which is why it is used in the layer closest to your body.',
          ar: 'مادة تغيّر الطور (PCM) تمتص الحرارة عند دفء السطح وتحررها مجدداً عند برودته، ولهذا تُستخدم في الطبقة الأقرب إلى جسمك.',
          ku: 'PCM کەرەستەیەکە کە گەرمی هەڵدەمژێت کاتێک ڕووکە گەرم دەبێت و دووبارە بەری دەداتەوە کاتێک سارد دەبێتەوە، بۆیە لە نزیکترین چین لە لەشت بەکاردێت.'
        }
      },
      {
        name: { en: 'Gel memory foam', ar: 'إسفنج ذاكرة بالجل', ku: 'فۆمی بیرگەی جێل' },
        pos: { en: 'Comfort layer', ar: 'طبقة الراحة', ku: 'چینی ئاسوودەیی' },
        desc: {
          en: 'Memory foam softens under body heat and moulds to your outline, then returns slowly — the source of the model’s deep, enveloping pressure relief.',
          ar: 'يلين إسفنج الذاكرة بحرارة الجسم ويتشكل على حدود جسمك ثم يعود ببطء — وهو مصدر تخفيف الضغط العميق والمحيط في هذا النموذج.',
          ku: 'فۆمی بیرگە بە گەرمی لەش نەرم دەبێت و لەگەڵ شێوەی لەش دەگونجێت و دواتر بە هێواشی دەگەڕێتەوە — سەرچاوەی کەمکردنەوەی قووڵی گوشار لەم مۆدێلەدا.'
        }
      },
      {
        name: { en: '1000C pocket spring unit', ar: 'وحدة نوابض جيبية 1000C', ku: 'یەکەی سپرینی گیرفانی 1000C' },
        pos: { en: 'Support core', ar: 'قلب الدعم', ku: 'ناوەندی پاڵپشتی' },
        desc: {
          en: 'The pocket spring base gives the soft upper layers a supportive, independent foundation rather than a solid foam slab.',
          ar: 'تمنح قاعدة النوابض الجيبية الطبقات العلوية الناعمة أساساً داعماً ومستقلاً بدل قاعدة إسفنجية صلبة.',
          ku: 'بنکەی سپرینی گیرفانی بۆ چینە نەرمەکانی سەرەوە بنکەیەکی پاڵپشتیکەر و سەربەخۆ دەبەخشێت لە جیاتی تەختەیەکی فۆمی ڕەق.'
        }
      }
    ],
    score: {
      position: { side: 0.9, back: 0.74, stomach: 0.56, combination: 0.84 },
      comfort: 2.3,
      temp: { hot: 1, comfortable: 0.74, cold: 0.5, seasonal: 0.62 },
      physical: { pressure: 0.88, spine: 0.74, joint: 0.76, muscle: 0.94, general: 0.82 },
      materials: { natural: 0.15, memory: 1, pocket: 0.7, antibacterial: 0.3, cooling: 1, foam: 0.6 },
      extras: { motion: 0.85, breathable: 0.8, hotel: 0.62, extraSoft: 0.7, supportive: 0.6, seasonal: 0.55, antibacterial: 0.3 }
    }
  },

  /* ---------------- 04 FOUR SEASONS ---------------- */
  {
    id: 'four-seasons',
    num: '04',
    order: 4,
    image: 'four-seasons',
    room: 'four-seasons-room',
    name: { en: 'Four Seasons', ar: 'فور سيزونز', ku: 'فۆر سیزنس' },
    tagline: {
      en: 'Dual season comfort. Year-round perfect sleep.',
      ar: 'راحة لموسمين. نوم مثالي طوال العام.',
      ku: 'ئاسوودەیی دوو وەرزی. خەوی تەواو بە درێژایی ساڵ.'
    },
    height: 30,
    topKey: 'euro',
    top: { en: 'Euro top', ar: 'سطح أوروبي', ku: 'سەرەوەی ئەوروپی' },
    springKey: 'pocket',
    springs: { en: '1000C pocket springs', ar: 'نوابض جيبية 1000C', ku: 'سپرینی گیرفانی 1000C' },
    construction: { en: 'Reversible pocket spring', ar: 'نوابض جيبية قابلة للقلب', ku: 'سپرینی گیرفانی ئەگەڕاو' },
    mainTech: { en: 'Ice Technology & wool', ar: 'تقنية Ice وصوف', ku: 'Ice Technology و خوری' },
    techKeys: ['icetech', 'wool', 'pocket'],
    filters: ['cooling', 'spine', 'seasonal'],
    sizes: [{ w: 180, h: 200, price: 864000 }],
    overview: {
      en: 'Four Seasons is a reversible mattress with two different faces. Turn it one way for the Ice Technology side, built for summer; turn it the other way for the wool-infused side, built for winter. Both faces sit on a 1000C pocket spring unit, and the Euro top gives a smooth, tailored finish at 30 cm.',
      ar: 'فور سيزونز سرير قابل للقلب بوجهين مختلفين. اقلبه على وجه لتجد جانب تقنية Ice المصمم للصيف، واقلبها على الوجه الآخر لتجد الجانب المدعّم بالصوف المصمم للشتاء. كلا الوجهين يقوم على وحدة نوابض جيبية 1000C، ويمنح السطح الأوروبي لمسة نهائية ناعمة ومنظمة بارتفاع ٣٠ سم.',
      ku: 'فۆر سیزنس دۆشەکێکی ئەگەڕاوە بە دوو ڕووی جیاواز. بە یەک لاوە ئەگەڕێنەوە بۆ لای Ice Technology کە بۆ هاوین دروستکراوە، و بە لایەکەی تر بۆ لای خوری کە بۆ زستانە. هەردوو ڕووەکە لەسەر یەکەی سپرینی گیرفانی 1000C دان و سەرەوەی ئەوروپی کۆتاییەکی نەرم و ڕێک دەبەخشێت بە ٣٠ سم.'
    },
    who: {
      en: 'Designed for sleepers whose comfort changes with the seasons, and for anyone who wants one mattress that can be adapted twice a year.',
      ar: 'مصممة لمن تتغير راحتهم مع الفصول، ولمن يريد سرير واحد يمكن تكييفه مرتين في السنة.',
      ku: 'بۆ ئەو کەسانە دروستکراوە کە ئاسوودەییان لەگەڵ وەرزەکان دەگۆڕێت، و بۆ هەر کەسێک کە دۆشەکێکی وابەستە دەوێت کە ساڵانە دوو جار بگۆڕدرێت.'
    },
    features: {
      en: [
        'Reversible dual-season construction',
        'Ice Technology summer side',
        'Wool-infused winter side',
        '1000C pocket spring unit',
        'Euro top surface, 30 cm'
      ],
      ar: [
        'بنية قابلة للقلب لموسمين',
        'جانب صيفي بتقنية Ice',
        'جانب شتوي مدعّم بالصوف',
        'وحدة نوابض جيبية 1000C',
        'سطح أوروبي بارتفاع ٣٠ سم'
      ],
      ku: [
        'پێکهاتەی ئەگەڕاوی دوو وەرزی',
        'لای هاوین بە Ice Technology',
        'لای زستان بە خوری',
        'یەکەی سپرینی گیرفانی 1000C',
        'سەرەوەی ئەوروپی بە ٣٠ سم'
      ]
    },
    layers: [
      {
        name: { en: 'Ice Technology summer side', ar: 'الجانب الصيفي بتقنية Ice', ku: 'لای هاوین بە Ice Technology' },
        pos: { en: 'Top surface — summer', ar: 'السطح العلوي — الصيف', ku: 'ڕووی سەرەوە — هاوین' },
        desc: {
          en: 'The Ice Technology face is designed for warm months: a cooler-touch sleeping surface that you turn upward in summer.',
          ar: 'وجه تقنية Ice مصمم للأشهر الحارة: سطح نوم أكثر برودة تقلبونه للأعلى في الصيف.',
          ku: 'لای Ice Technology بۆ مانگە گەرمەکان دروستکراوە: ڕووی نوستنێکی ساردتر کە لە هاویندا بەرەو سەرەوە دەگەڕێنرێت.'
        }
      },
      {
        name: { en: 'Wool-infused winter side', ar: 'الجانب الشتوي المدعّم بالصوف', ku: 'لای زستان بە خوری' },
        pos: { en: 'Reverse face — winter', ar: 'الوجه المقابل — الشتاء', ku: 'ڕووی بەرەوژێر — زستان' },
        desc: {
          en: 'The reverse face incorporates wool, chosen for its natural insulating character. Turn the mattress over when the season changes.',
          ar: 'يحتوي الوجه المقابل على الصوف، المختار لخاصيته العازلة الطبيعية. اقلب السرير عند تغيّر الموسم.',
          ku: 'ڕووی بەرەوژێر خوری تێدایە کە بۆ تایبەتمەندی گەرمکەری سروشتی هەڵبژێردراوە. کاتێک وەرز دەگۆڕێت دۆشەکەکە ئەگەڕێنەوە.'
        }
      },
      {
        name: { en: 'Reversible construction', ar: 'بنية قابلة للقلب', ku: 'پێکهاتەی ئەگەڕاو' },
        pos: { en: 'Whole mattress', ar: 'السرير بالكامل', ku: 'هەموو دۆشەکەکە' },
        desc: {
          en: 'The two faces are built to be used in turn, so one mattress covers both halves of the year.',
          ar: 'الوجهان مصممان للاستخدام بالتناوب، فسرير واحد يغطي نصفَي السنة.',
          ku: 'هەردوو ڕووەکە بۆ بەکارهێنانی نۆرەیی دروستکراون، بۆیە یەک دۆشەک هەردوو نیوەی ساڵ دەگرێتەوە.'
        }
      },
      {
        name: { en: '1000C pocket spring unit', ar: 'وحدة نوابض جيبية 1000C', ku: 'یەکەی سپرینی گیرفانی 1000C' },
        pos: { en: 'Support core', ar: 'قلب الدعم', ku: 'ناوەندی پاڵپشتی' },
        desc: {
          en: 'A single 1000C pocket spring unit sits at the centre of the mattress, shared by both seasonal faces.',
          ar: 'وحدة نوابض جيبية 1000C واحدة في مركز السرير، يشترك فيه الوجهان الموسميان.',
          ku: 'یەک یەکەی سپرینی گیرفانی 1000C لە ناوەڕاستی دۆشەکەکەدایە و هەردوو لای وەرزی بەکاری دەهێنن.'
        }
      }
    ],
    score: {
      position: { side: 0.84, back: 0.86, stomach: 0.72, combination: 0.9 },
      comfort: 3,
      temp: { hot: 0.86, comfortable: 0.8, cold: 0.88, seasonal: 1 },
      physical: { pressure: 0.74, spine: 0.86, joint: 0.72, muscle: 0.68, general: 0.88 },
      materials: { natural: 0.62, memory: 0.2, pocket: 1, antibacterial: 0.35, cooling: 0.95, foam: 0.1 },
      extras: { motion: 0.88, breathable: 0.88, hotel: 0.45, extraSoft: 0.35, supportive: 0.78, seasonal: 1, antibacterial: 0.35 }
    }
  },

  /* ---------------- 05 BIOLUX ---------------- */
  {
    id: 'biolux',
    num: '05',
    order: 5,
    image: 'biolux',
    room: 'biolux-room',
    name: { en: 'Biolux', ar: 'بيولوكس', ku: 'بیولۆکس' },
    tagline: {
      en: 'Silky luxury touch, cloud-like pillow top.',
      ar: 'ملمس حريري فاخر، سطح وسادة كالغيمة.',
      ku: 'دەستی ئاوریشمی لوکس، سەرەوەی سەرین وەک هەور.'
    },
    height: 30,
    topKey: 'pillow',
    top: { en: 'Pillow top', ar: 'سطح وسادة', ku: 'سەرەوەی سەرین' },
    springKey: 'pocket',
    springs: { en: 'Pocket springs', ar: 'نوابض جيبية', ku: 'سپرینی گیرفانی' },
    construction: { en: 'Pocket spring', ar: 'نوابض جيبية', ku: 'سپرینی گیرفانی' },
    mainTech: { en: 'Double jacquard silky fabric', ar: 'قماش حريري جاكار مزدوج', ku: 'قوماشی ئاوریشمی جاکاردی دووانە' },
    techKeys: ['jacquard', 'pocket'],
    filters: ['luxury', 'soft'],
    sizes: [
      { w: 160, h: 200, price: 810000 },
      { w: 180, h: 200, price: 876000 }
    ],
    overview: {
      en: 'Biolux is the softest way into the collection. A double jacquard silky fabric covers a generous pillow top over pocket springs — a tactile, hotel-style surface at 30 cm. It is the model we recommend when the feeling of the fabric matters as much as the support beneath it.',
      ar: 'بيولوكس هو المدخل الأكثر نعومة إلى المجموعة. قماش حريري جاكار مزدوج يغطي سطح وسادة كريماً فوق نوابض جيبية — سطح ملموس بأسلوب الفنادق بارتفاع ٣٠ سم. وهو النموذج الذي نوصي به عندما يكون إحساس القماش مهماً بقدر الدعم تحته.',
      ku: 'بیولۆکس نەرمترین دەروازەی کۆلێکشنەکەیە. قوماشێکی ئاوریشمی جاکاردی دووانە سەرەوەی سەرینێکی فراوان دەپۆشێت لەسەر سپرینی گیرفانی — ڕوویەکی هەستپێکراو بە شێوازی هۆتێل بە ٣٠ سم. ئەم مۆدێلە پێشنیار دەکەین کاتێک هەستی قوماشەکە هێندەی پاڵپشتی ژێرەوە گرنگە.'
    },
    who: {
      en: 'Designed for sleepers who love a plush, silky surface and hotel-like softness, and who want pocket spring support underneath it.',
      ar: 'مصممة لمن يحب السطح الناعم الحريري ونعومة الفنادق، ويريد دعماً من النوابض الجيبية تحته.',
      ku: 'بۆ ئەو کەسانە دروستکراوە کە ڕوویەکی نەرم و ئاوریشمیان خۆشدەوێت و نەرمی وەک هۆتێل دەوێت، و پاڵپشتی سپرینی گیرفانیان لە ژێرەوە دەوێت.'
    },
    features: {
      en: [
        'Double jacquard silky fabric cover',
        'Generous pillow top',
        'Pocket spring support',
        'Soft, hotel-style feel',
        '30 cm height · also available in 160 × 200'
      ],
      ar: [
        'غطاء قماش حريري جاكار مزدوج',
        'سطح وسادة كريم',
        'دعم بنوابض جيبية',
        'إحساس ناعم بأسلوب الفنادق',
        'ارتفاع ٣٠ سم · متوفرة أيضاً بمقاس ١٦٠ × ٢٠٠'
      ],
      ku: [
        'ڕووپۆشی قوماشی ئاوریشمی جاکاردی دووانە',
        'سەرەوەی سەرینی فراوان',
        'پاڵپشتی سپرینی گیرفانی',
        'هەستی نەرم بە شێوازی هۆتێل',
        'بەرزی ٣٠ سم · بە ١٦٠ × ٢٠٠یش بەردەستە'
      ]
    },
    layers: [
      {
        name: { en: 'Double jacquard silky fabric', ar: 'قماش حريري جاكار مزدوج', ku: 'قوماشی ئاوریشمی جاکاردی دووانە' },
        pos: { en: 'Top surface', ar: 'السطح العلوي', ku: 'ڕووی سەرەوە' },
        desc: {
          en: 'A double jacquard weave creates a dense, silky surface with a subtle sheen — the defining texture of Biolux.',
          ar: 'نسيج جاكار مزدوج يخلق سطحاً كثيفاً حريرياً بلمعة خفيفة — وهو الملمس المميز لبيولوكس.',
          ku: 'چنینی جاکاردی دووانە ڕوویەکی چڕ و ئاوریشمی بە درەوشانەوەیەکی هێواش دروست دەکات — تایبەتمەندی دەستی بیولۆکس.'
        }
      },
      {
        name: { en: 'Pillow top', ar: 'سطح وسادة', ku: 'سەرەوەی سەرین' },
        pos: { en: 'Upper comfort', ar: 'الراحة العلوية', ku: 'ئاسوودەیی سەرەوە' },
        desc: {
          en: 'The pillow top is the softness you notice first: a cushioned upper layer that lets you settle in before the springs take the load.',
          ar: 'سطح الوسادة هو النعومة التي تلاحظها أولاً: طبقة عليا مبطّنة تسمح لك بالاستقرار قبل أن تتحمل النوابض الحمل.',
          ku: 'سەرەوەی سەرین ئەو نەرمییەیە کە سەرەتا هەستی پێدەکەیت: چینێکی سەرەوەی نەرم کە ڕێگەت دەدات جێگیر بیت پێش ئەوەی سپرینەکان بارەکە هەڵبگرن.'
        }
      },
      {
        name: { en: 'Pocket spring unit', ar: 'وحدة نوابض جيبية', ku: 'یەکەی سپرینی گیرفانی' },
        pos: { en: 'Support core', ar: 'قلب الدعم', ku: 'ناوەندی پاڵپشتی' },
        desc: {
          en: 'Individually pocketed springs support the body locally while limiting movement transfer across the surface.',
          ar: 'تدعم النوابض الجيبية المستقلة الجسم محلياً وتحدّ من انتقال الحركة عبر السطح.',
          ku: 'سپرینە گیرفانییە سەربەخۆکان بە شێوەی خۆجێیی پاڵپشتی لەش دەکەن و گواستنەوەی جووڵە کەم دەکەنەوە.'
        }
      }
    ],
    score: {
      position: { side: 0.9, back: 0.76, stomach: 0.58, combination: 0.86 },
      comfort: 2.2,
      temp: { hot: 0.6, comfortable: 0.84, cold: 0.58, seasonal: 0.5 },
      physical: { pressure: 0.86, spine: 0.72, joint: 0.7, muscle: 0.8, general: 0.86 },
      materials: { natural: 0.35, memory: 0.35, pocket: 1, antibacterial: 0.3, cooling: 0.45, foam: 0.15 },
      extras: { motion: 0.92, breathable: 0.58, hotel: 1, extraSoft: 0.85, supportive: 0.55, seasonal: 0.4, antibacterial: 0.3 }
    }
  },

  /* ---------------- 06 NEOCOMFORT ---------------- */
  {
    id: 'neocomfort',
    num: '06',
    order: 6,
    image: 'neocomfort',
    room: 'neocomfort-room',
    name: { en: 'Neocomfort', ar: 'نيو كومفورت', ku: 'نیو کۆمفۆرت' },
    tagline: {
      en: 'Breathable soft surface. Cloud-like body support.',
      ar: 'سطح ناعم قابل للتنفس. دعم للجسم كالغيمة.',
      ku: 'ڕووی نەرمی هەناسەدەر. پاڵپشتی لەش وەک هەور.'
    },
    height: 25,
    topKey: 'flat',
    top: { en: 'Flat top', ar: 'سطح مستوٍ', ku: 'سەرەوەی تەخت' },
    springKey: 'foam',
    springs: { en: 'No springs — all-foam construction', ar: 'بدون نوابض — بنية إسفنجية بالكامل', ku: 'بێ سپرین — پێکهاتەی تەواو فۆم' },
    construction: { en: 'Foam-only', ar: 'إسفنج فقط', ku: 'فۆم تەنها' },
    mainTech: { en: 'Gel Fusion memory foam', ar: 'إسفنج ذاكرة Gel Fusion', ku: 'فۆمی بیرگەی Gel Fusion' },
    techKeys: ['gel-fusion', 'foam', 'memory'],
    filters: ['foam', 'soft', 'spine'],
    sizes: [{ w: 180, h: 200, price: 1008000 }],
    overview: {
      en: 'Neocomfort is the only all-foam model in the collection — no springs at all. A breathable soft surface sits over Gel Fusion memory foam, which conforms to the body and helps spread pressure evenly. At 25 cm with a flat top, it is a clean, quiet, motion-isolating mattress for people who prefer foam to springs.',
      ar: 'نيو كومفورت هو النموذج الوحيد في المجموعة المصنوع من الإسفنج بالكامل — بدون نوابض إطلاقاً. سطح ناعم قابل للتنفس فوق إسفنج ذاكرة Gel Fusion يتبع الجسم ويساعد في توزيع الضغط بالتساوي. بارتفاع ٢٥ سم وسطح مستوٍ، هو سرير نظيف وهادئ وعازل للحركة لمن يفضّل الإسفنج على النوابض.',
      ku: 'نیو کۆمفۆرت تاکە مۆدێلی تەواو فۆمە لە کۆلێکشن — هیچ سپرینێک نییە. ڕوویەکی نەرمی هەناسەدەر لەسەر فۆمی بیرگەی Gel Fusion دان کە لەگەڵ لەش دەگونجێت و یارمەتی دابەشکردنی یەکسانی گوشار دەدات. بە ٢٥ سم و ڕووی تەخت، دۆشەکێکی پاک و هێمن و جیاکەرەوەی جووڵەیە بۆ ئەو کەسانەی فۆم بە سپرین ترجیح دەدەن.'
    },
    who: {
      en: 'Designed for foam-preferring sleepers, couples who are disturbed by movement, and anyone who wants a lower, no-spring mattress.',
      ar: 'مصممة لمن يفضّل الإسفنج، وللأزواج الذين تزعجهم الحركة، ولمن يريد سرير أقل ارتفاعاً وبدون نوابض.',
      ku: 'بۆ ئەو کەسانە دروستکراوە کە فۆم ترجیح دەدەن، و بۆ هاوسەرەکان کە جووڵە بێزار دەکات، و بۆ هەر کەسێک کە دۆشەکێکی نزم و بێ سپرین دەوێت.'
    },
    features: {
      en: [
        'All-foam construction — no springs',
        'Gel Fusion memory foam',
        'Breathable soft surface',
        'Flat top',
        '25 cm height'
      ],
      ar: [
        'بنية إسفنجية بالكامل — بدون نوابض',
        'إسفنج ذاكرة Gel Fusion',
        'سطح ناعم قابل للتنفس',
        'سطح مستوٍ',
        'ارتفاع ٢٥ سم'
      ],
      ku: [
        'پێکهاتەی تەواو فۆم — بێ سپرین',
        'فۆمی بیرگەی Gel Fusion',
        'ڕووی نەرمی هەناسەدەر',
        'سەرەوەی تەخت',
        'بەرزی ٢٥ سم'
      ]
    },
    layers: [
      {
        name: { en: 'Breathable soft surface', ar: 'سطح ناعم قابل للتنفس', ku: 'ڕووی نەرمی هەناسەدەر' },
        pos: { en: 'Top surface', ar: 'السطح العلوي', ku: 'ڕووی سەرەوە' },
        desc: {
          en: 'The top fabric is chosen for airflow — important in a foam mattress, where trapped warmth is the usual weakness.',
          ar: 'اختير القماش العلوي لتدفق الهواء — وهذا مهم في سرير إسفنجي حيث تكون الحرارة المحتجزة هي الضعف المعتاد.',
          ku: 'قوماشی سەرەوە بۆ تێپەڕینی هەوا هەڵبژێردراوە — ئەمە لە دۆشەکی فۆمیدا گرنگە، چونکە گیرسانەوەی گەرمی لاوازییەکی باوە.'
        }
      },
      {
        name: { en: 'Gel Fusion memory foam', ar: 'إسفنج ذاكرة Gel Fusion', ku: 'فۆمی بیرگەی Gel Fusion' },
        pos: { en: 'Comfort layer', ar: 'طبقة الراحة', ku: 'چینی ئاسوودەیی' },
        desc: {
          en: 'A gel-infused memory foam that softens under body heat and moulds to your shape, giving a slow, enveloping release of pressure.',
          ar: 'إسفنج ذاكرة مدعّم بالجل يلين بحرارة الجسم ويتشكل على شكل جسمك، فيمنح إفراجاً بطيئاً ومحيطاً عن الضغط.',
          ku: 'فۆمی بیرگەی تێکەڵ بە جێل کە بە گەرمی لەش نەرم دەبێت و لەگەڵ شێوەی لەشت دەگونجێت، ئازادکردنێکی هێواش و گشتگیر لە گوشار دەدات.'
        }
      },
      {
        name: { en: 'All-foam support core', ar: 'قلب دعم إسفنجي', ku: 'ناوەندی پاڵپشتی فۆمی' },
        pos: { en: 'Support core', ar: 'قلب الدعم', ku: 'ناوەندی پاڵپشتی' },
        desc: {
          en: 'With no springs anywhere in the build, the base is a solid foam core. Movement is absorbed rather than transferred, and the mattress stays quiet.',
          ar: 'بما أنه لا توجد نوابض في البنية، فالقاعدة قلب إسفنجي صلب. تُخزّن الحركة بدل نقلها، ويبقى السرير هادئاً.',
          ku: 'چونکە هیچ سپرینێک لە پێکهاتەکەدا نییە، بنکەکە ناوەندی فۆمی ڕەقە. جووڵە هەڵدەمژرێت نەک بگوازرێتەوە، و دۆشەکەکە هێمن دەمێنێتەوە.'
        }
      }
    ],
    score: {
      position: { side: 0.84, back: 0.8, stomach: 0.62, combination: 0.84 },
      comfort: 2.7,
      temp: { hot: 0.55, comfortable: 0.8, cold: 0.62, seasonal: 0.5 },
      physical: { pressure: 0.92, spine: 0.78, joint: 0.82, muscle: 0.9, general: 0.86 },
      materials: { natural: 0.1, memory: 0.92, pocket: 0.05, antibacterial: 0.25, cooling: 0.4, foam: 1 },
      extras: { motion: 1, breathable: 0.9, hotel: 0.65, extraSoft: 0.65, supportive: 0.55, seasonal: 0.4, antibacterial: 0.25 }
    }
  },

  /* ---------------- 07 RABBIT COMFORT ---------------- */
  {
    id: 'rabbit-comfort',
    num: '07',
    order: 7,
    image: 'rabbit-comfort',
    room: 'rabbit-comfort-room',
    name: { en: 'Rabbit Comfort', ar: 'رابيت كومفورت', ku: 'ڕابیت کۆمفۆرت' },
    tagline: {
      en: 'Super soft rabbit fabric. Specialised pain relief.',
      ar: 'قماش ناعم كفراء الأرنب. راحة متخصصة للألم.',
      ku: 'قوماشی زۆر نەرمی وەک مووی کەروێشک. ئارامکردنەوەی تایبەت بۆ ئازار.'
    },
    height: 25,
    topKey: 'quilted',
    top: { en: 'Quilted', ar: 'مبطّن', ku: 'چنارەکراو' },
    springKey: 'pocket',
    springs: { en: '1000C pocket springs', ar: 'نوابض جيبية 1000C', ku: 'سپرینی گیرفانی 1000C' },
    construction: { en: 'Pocket spring with Ergo-Support foam', ar: 'نوابض جيبية مع إسفنج Ergo-Support', ku: 'سپرینی گیرفانی لەگەڵ فۆمی Ergo-Support' },
    mainTech: { en: 'Rabbit-touch fabric & Ergo-Support foam', ar: 'قماش بملمس الأرنب وإسفنج Ergo-Support', ku: 'قوماشی دەستی کەروێشک و فۆمی Ergo-Support' },
    techKeys: ['rabbit', 'ergo', 'pocket'],
    filters: ['spine', 'soft'],
    sizes: [
      { w: 120, h: 200, price: 504000 },
      { w: 180, h: 200, price: 678000 }
    ],
    overview: {
      en: 'Rabbit Comfort takes its name from its fabric: a super-soft, rabbit-touch surface over a quilted build with Ergo-Support foam and a 1000C pocket spring unit. It is a 25 cm mattress aimed squarely at comfort that supports the body where it needs it — back, joints and hips — without a hard surface.',
      ar: 'يأخذ رابيت كومفورت اسمه من قماشه: سطح فائق النعومة بملمس فراء الأرنب فوق بنية مبطّنة مع إسفنج Ergo-Support ووحدة نوابض جيبية 1000C. وهو سرير بارتفاع ٢٥ سم موجّه صراحةً إلى راحة تدعم الجسم حيث يحتاج — الظهر والمفاصل والوركين — دون سطح قاسٍ.',
      ku: 'ڕابیت کۆمفۆرت ناوەکەی لە قوماشەکەیەوە هاتووە: ڕوویەکی زۆر نەرم بە دەستی مووی کەروێشک لەسەر پێکهاتەیەکی چنارەکراو لەگەڵ فۆمی Ergo-Support و یەکەی سپرینی گیرفانی 1000C. دۆشەکێکی ٢٥ سمە کە بە ڕاستەوخۆ بۆ ئاسوودەیی پاڵپشتیکەر دروستکراوە — پشت، جومگە و کەمەر — بەبێ ڕووی ڕەق.'
    },
    who: {
      en: 'Designed for sleepers who want back and joint support with a very soft touch, and for smaller rooms or single sleepers who need a 120 × 200 option.',
      ar: 'مصممة لمن يريد دعماً للظهر والمفاصل مع ملمس ناعم جداً، وللغرف الصغيرة أو للنائمين منفردين الذين يحتاجون مقاس ١٢٠ × ٢٠٠.',
      ku: 'بۆ ئەو کەسانە دروستکراوە کە پاڵپشتی پشت و جومگە دەوێت لەگەڵ دەستێکی زۆر نەرم، و بۆ ژوورە بچووکەکان یان کەسانی تەنیا کە پێویستیان بە ١٢٠ × ٢٠٠ هەیە.'
    },
    features: {
      en: [
        'Super soft rabbit-touch fabric',
        'Ergo-Support foam comfort layer',
        '1000C pocket spring unit',
        'Quilted surface',
        '25 cm height · 120 × 200 and 180 × 200'
      ],
      ar: [
        'قماش فائق النعومة بملمس الأرنب',
        'طبقة راحة من إسفنج Ergo-Support',
        'وحدة نوابض جيبية 1000C',
        'سطح مبطّن',
        'ارتفاع ٢٥ سم · ١٢٠ × ٢٠٠ و١٨٠ × ٢٠٠'
      ],
      ku: [
        'قوماشی زۆر نەرم بە دەستی کەروێشک',
        'چینی ئاسوودەیی فۆمی Ergo-Support',
        'یەکەی سپرینی گیرفانی 1000C',
        'ڕووی چنارەکراو',
        'بەرزی ٢٥ سم · ١٢٠ × ٢٠٠ و ١٨٠ × ٢٠٠'
      ]
    },
    layers: [
      {
        name: { en: 'Rabbit-touch fabric', ar: 'قماش بملمس الأرنب', ku: 'قوماشی دەستی کەروێشک' },
        pos: { en: 'Top surface', ar: 'السطح العلوي', ku: 'ڕووی سەرەوە' },
        desc: {
          en: 'A super-soft fabric with a dense, furry hand-feel. It is the first thing you notice about Rabbit Comfort, and the reason for its name.',
          ar: 'قماش فائق النعومة بملمس كثيف كالفراء. وهو أول ما تلاحظه في رابيت كومفورت، وسبب تسميته.',
          ku: 'قوماشێکی زۆر نەرم بە دەستێکی چڕ و موودار. یەکەم شتە کە هەستی پێدەکەیت لە ڕابیت کۆمفۆرت، و هۆکاری ناوەکەیەتی.'
        }
      },
      {
        name: { en: 'Quilted comfort layer', ar: 'طبقة راحة مبطّنة', ku: 'چینی ئاسوودەیی چنارەکراو' },
        pos: { en: 'Upper comfort', ar: 'الراحة العلوية', ku: 'ئاسوودەیی سەرەوە' },
        desc: {
          en: 'The quilted build spreads softness evenly across the surface, so there is no hard spot where you first lie down.',
          ar: 'توزّع البنية المبطّنة النعومة بالتساوي على السطح، فلا توجد نقطة قاسية عند الاستلقاء.',
          ku: 'پێکهاتەی چنارەکراو نەرمی بە یەکسانی بەسەر ڕووکەدا دابەش دەکات، بۆیە هیچ شوێنێکی ڕەق نامێنێت لە کاتی پاڵکەوتن.'
        }
      },
      {
        name: { en: 'Ergo-Support foam', ar: 'إسفنج Ergo-Support', ku: 'فۆمی Ergo-Support' },
        pos: { en: 'Comfort layer', ar: 'طبقة الراحة', ku: 'چینی ئاسوودەیی' },
        desc: {
          en: 'A support-oriented foam that holds the body’s heavier zones — hips and lower back — while the softer top stays comfortable.',
          ar: 'إسفنج موجّه للدعم يثبّت مناطق الجسم الأثقل — الوركين وأسفل الظهر — بينما يبقى السطح الأنعم مريحاً.',
          ku: 'فۆمێک کە بەرەو پاڵپشتی ئاراستە کراوە و ناوچە قورسەکانی لەش — کەمەر و خوارەوەی پشت — ڕادەگرێت، لە کاتێکدا ڕووی نەرمتر ئاسوودە دەمێنێتەوە.'
        }
      },
      {
        name: { en: '1000C pocket spring unit', ar: 'وحدة نوابض جيبية 1000C', ku: 'یەکەی سپرینی گیرفانی 1000C' },
        pos: { en: 'Support core', ar: 'قلب الدعم', ku: 'ناوەندی پاڵپشتی' },
        desc: {
          en: 'Individually pocketed springs complete the support, responding to each part of the body separately.',
          ar: 'تكمل النوابض الجيبية المستقلة الدعم، وتستجيب لكل جزء من الجسم على حدة.',
          ku: 'سپرینە گیرفانییە سەربەخۆکان پاڵپشتی تەواو دەکەن و بۆ هەر بەشێکی لەش بە جیا وەڵام دەدەنەوە.'
        }
      }
    ],
    score: {
      position: { side: 0.86, back: 0.9, stomach: 0.76, combination: 0.88 },
      comfort: 2.8,
      temp: { hot: 0.58, comfortable: 0.82, cold: 0.6, seasonal: 0.5 },
      physical: { pressure: 0.9, spine: 0.92, joint: 0.96, muscle: 0.82, general: 0.88 },
      materials: { natural: 0.25, memory: 0.4, pocket: 1, antibacterial: 0.3, cooling: 0.45, foam: 0.3 },
      extras: { motion: 0.9, breathable: 0.68, hotel: 0.5, extraSoft: 0.6, supportive: 1, seasonal: 0.4, antibacterial: 0.3 }
    }
  },

  /* ---------------- 08 LUXEREST ---------------- */
  {
    id: 'luxerest',
    num: '08',
    order: 8,
    image: 'luxerest',
    room: 'luxerest-room',
    name: { en: 'LuxeRest', ar: 'لوكس ريست', ku: 'لوکس ڕێست' },
    tagline: {
      en: 'Breathable viscose fabric. Plush pillow top comfort.',
      ar: 'قماش فيسكوز قابل للتنفس. راحة سطح وسادة فاخرة.',
      ku: 'قوماشی ڤیسکۆسی هەناسەدەر. ئاسوودەیی سەرەوەی سەرینی نەرم.'
    },
    height: 30,
    topKey: 'pillow',
    top: { en: 'Pillow top', ar: 'سطح وسادة', ku: 'سەرەوەی سەرین' },
    springKey: 'pocket',
    springs: { en: 'Pocket springs', ar: 'نوابض جيبية', ku: 'سپرینی گیرفانی' },
    construction: { en: 'Pocket spring', ar: 'نوابض جيبية', ku: 'سپرینی گیرفانی' },
    mainTech: { en: 'Breathable viscose fabric', ar: 'قماش فيسكوز قابل للتنفس', ku: 'قوماشی ڤیسکۆسی هەناسەدەر' },
    techKeys: ['viscose', 'pocket'],
    filters: ['cooling', 'soft', 'luxury'],
    sizes: [
      { w: 100, h: 200, price: 408000 },
      { w: 120, h: 200, price: 456000 },
      { w: 180, h: 200, price: 636000 }
    ],
    overview: {
      en: 'LuxeRest combines a plush pillow top with a breathable viscose cover over pocket springs. Viscose is chosen here for airflow and a smooth, cool hand-feel, which makes this one of the most comfortable options for warm sleepers who still want a soft, hotel-like surface. Available from 100 cm wide.',
      ar: 'يجمع لوكس ريست بين سطح وسادة فاخر وغطاء فيسكوز قابل للتنفس فوق نوابض جيبية. اختير الفيسكوز هنا لتدفق الهواء وملمسه الناعم البارد، ما يجعله من أكثر الخيارات راحة لمن يشعرون بالحرارة ويريدون سطحاً ناعماً بأسلوب الفنادق. متوفر من عرض ١٠٠ سم.',
      ku: 'لوکس ڕێست سەرەوەی سەرینێکی نەرم لەگەڵ ڕووپۆشی ڤیسکۆسی هەناسەدەر پێکەوە دەبەستێت لەسەر سپرینی گیرفانی. ڤیسکۆس لێرە بۆ تێپەڕینی هەوا و دەستێکی نەرم و سارد هەڵبژێردراوە، ئەمەیش یەکێک لە ئاسوودەترین بژاردەکانە بۆ ئەو کەسانەی گەرم دەبن و ڕوویەکی نەرمی وەک هۆتێل دەوێت. لە پانی ١٠٠ سمەوە بەردەستە.'
    },
    who: {
      en: 'Designed for warm sleepers who want plushness, and for singles or guest rooms that need a 100 cm mattress.',
      ar: 'مصممة لمن يشعرون بالحرارة ويريدون نعومة، وللغرف الفردية أو غرف الضيوف التي تحتاج مقاس ١٠٠ سم.',
      ku: 'بۆ ئەو کەسانەی گەرم دەبن و نەرمیان دەوێت، و بۆ ژووری تاکەکەسی یان میوان کە پێویستی بە ١٠٠ سم هەیە.'
    },
    features: {
      en: [
        'Breathable viscose fabric cover',
        'Plush pillow top',
        'Pocket spring support',
        'Available from 100 × 200 cm',
        '30 cm height'
      ],
      ar: [
        'غطاء قماش فيسكوز قابل للتنفس',
        'سطح وسادة فاخر',
        'دعم بنوابض جيبية',
        'متوفر من ١٠٠ × ٢٠٠ سم',
        'ارتفاع ٣٠ سم'
      ],
      ku: [
        'ڕووپۆشی قوماشی ڤیسکۆسی هەناسەدەر',
        'سەرەوەی سەرینی نەرم',
        'پاڵپشتی سپرینی گیرفانی',
        'لە ١٠٠ × ٢٠٠ سمەوە بەردەستە',
        'بەرزی ٣٠ سم'
      ]
    },
    layers: [
      {
        name: { en: 'Breathable viscose fabric', ar: 'قماش فيسكوز قابل للتنفس', ku: 'قوماشی ڤیسکۆسی هەناسەدەر' },
        pos: { en: 'Top surface', ar: 'السطح العلوي', ku: 'ڕووی سەرەوە' },
        desc: {
          en: 'Viscose gives a smooth, slightly cool surface and is chosen here for breathability rather than gloss.',
          ar: 'يمنح الفيسكوز سطحاً ناعماً ومائلاً للبرودة، واختير هنا لقابليته للتنفس لا لللمعان.',
          ku: 'ڤیسکۆس ڕوویەکی نەرم و کەمێک سارد دەبەخشێت و لێرە بۆ هەناسەدان هەڵبژێردراوە نەک بۆ درەوشانەوە.'
        }
      },
      {
        name: { en: 'Plush pillow top', ar: 'سطح وسادة فاخر', ku: 'سەرەوەی سەرینی نەرم' },
        pos: { en: 'Upper comfort', ar: 'الراحة العلوية', ku: 'ئاسوودەیی سەرەوە' },
        desc: {
          en: 'A full pillow-top layer, the main source of LuxeRest’s plush, sinking-in comfort.',
          ar: 'طبقة سطح وسادة كاملة، وهي المصدر الأساسي لراحة لوكس ريست الناعمة والغائرة.',
          ku: 'چینێکی تەواوی سەرەوەی سەرین، سەرچاوەی سەرەکی ئاسوودەیی نەرم و قووڵی لوکس ڕێست.'
        }
      },
      {
        name: { en: 'Pocket spring unit', ar: 'وحدة نوابض جيبية', ku: 'یەکەی سپرینی گیرفانی' },
        pos: { en: 'Support core', ar: 'قلب الدعم', ku: 'ناوەندی پاڵپشتی' },
        desc: {
          en: 'Individually pocketed springs provide local support and reduce movement transfer between sleepers.',
          ar: 'توفر النوابض الجيبية المستقلة دعماً موضعياً وتقلل انتقال الحركة بين النائمين.',
          ku: 'سپرینە گیرفانییە سەربەخۆکان پاڵپشتی خۆجێیی دەدەن و گواستنەوەی جووڵە لە نێوان نوستەکان کەم دەکەنەوە.'
        }
      }
    ],
    score: {
      position: { side: 0.88, back: 0.78, stomach: 0.58, combination: 0.86 },
      comfort: 2.3,
      temp: { hot: 0.9, comfortable: 0.84, cold: 0.52, seasonal: 0.6 },
      physical: { pressure: 0.88, spine: 0.74, joint: 0.72, muscle: 0.78, general: 0.86 },
      materials: { natural: 0.4, memory: 0.3, pocket: 1, antibacterial: 0.3, cooling: 0.72, foam: 0.15 },
      extras: { motion: 0.9, breathable: 0.86, hotel: 0.9, extraSoft: 0.8, supportive: 0.55, seasonal: 0.5, antibacterial: 0.3 }
    }
  },

  /* ---------------- 09 LUNA ---------------- */
  {
    id: 'luna',
    num: '09',
    order: 9,
    image: 'luna',
    room: 'luna-room',
    name: { en: 'Luna', ar: 'لونا', ku: 'لونا' },
    tagline: {
      en: 'Breathable soft fabric. Targeted spine alignment.',
      ar: 'قماش ناعم قابل للتنفس. محاذاة دقيقة للعمود الفقري.',
      ku: 'قوماشی نەرمی هەناسەدەر. ڕێکخستنی وردی بڕبڕەی پشت.'
    },
    height: 25,
    topKey: 'euro',
    top: { en: 'Euro top', ar: 'سطح أوروبي', ku: 'سەرەوەی ئەوروپی' },
    springKey: 'pocket',
    springs: { en: 'Pocket springs', ar: 'نوابض جيبية', ku: 'سپرینی گیرفانی' },
    construction: { en: 'Pocket spring', ar: 'نوابض جيبية', ku: 'سپرینی گیرفانی' },
    mainTech: { en: 'Nano-knitted fabric & spine-support layer', ar: 'قماش نانو مضغوط وطبقة دعم للعمود الفقري', ku: 'قوماشی نانۆ و چینی پاڵپشتی بڕبڕە' },
    techKeys: ['nano', 'spine-layer', 'pocket'],
    filters: ['spine', 'support'],
    sizes: [
      { w: 100, h: 200, price: 252000 },
      { w: 120, h: 200, price: 288000 },
      { w: 160, h: 200, price: 354000 },
      { w: 180, h: 200, price: 432000 }
    ],
    overview: {
      en: 'Luna is the entry point to the collection and its most focused support model. A nano-knitted breathable cover sits over a Euro top and a specialised spine-support layer on pocket springs. At 25 cm it is the lowest model we make, and the one we recommend first when back alignment is the priority.',
      ar: 'لونا هي المدخل إلى المجموعة والنموذج الأكثر تركيزاً على الدعم. غطاء نانو مضغوط قابل للتنفس فوق سطح أوروبي وطبقة متخصصة لدعم العمود الفقري على نوابض جيبية. بارتفاع ٢٥ سم هو أقل نموذج نصنعه، وهو أول ما نوصي به عندما تكون محاذاة الظهر هي الأولوية.',
      ku: 'لونا دەروازەی کۆلێکشنەکەیە و مۆدێلی سەرنجراکێشترین پاڵپشتییە. ڕووپۆشێکی نانۆی هەناسەدەر لەسەر سەرەوەی ئەوروپی و چینێکی تایبەت بۆ پاڵپشتی بڕبڕەی پشت لەسەر سپرینی گیرفانی. بە ٢٥ سم نزمترین مۆدێلە کە دروستی دەکەین، و یەکەم پێشنیارە کاتێک ڕێکخستنی پشت پێشینەیە.'
    },
    who: {
      en: 'Designed for back sleepers and anyone who wants clear spinal support in a lower, more affordable mattress — and it is the easiest model to size for smaller rooms.',
      ar: 'مصممة لمن ينام على ظهره ولمن يريد دعماً واضحاً للعمود الفقري في سرير أقل ارتفاعاً وأقل سعراً — وهو الأسهل في اختيار المقاس للغرف الصغيرة.',
      ku: 'بۆ ئەو کەسانە دروستکراوە کە لەسەر پشت دەنوێن و بۆ هەر کەسێک کە پاڵپشتی ڕوونی بڕبڕەی پشت دەوێت لە دۆشەکێکی نزمتر و هەرزانتر — و ئاسانترین مۆدێلە بۆ هەڵبژاردنی قەبارە لە ژوورە بچووکەکان.'
    },
    features: {
      en: [
        'Nano-knitted breathable fabric',
        'Specialised spine-support layer',
        'Euro top surface',
        'Pocket spring support',
        '25 cm height · four sizes from 100 × 200 to 180 × 200'
      ],
      ar: [
        'قماش نانو مضغوط قابل للتنفس',
        'طبقة متخصصة لدعم العمود الفقري',
        'سطح أوروبي',
        'دعم بنوابض جيبية',
        'ارتفاع ٢٥ سم · أربعة مقاسات من ١٠٠ × ٢٠٠ إلى ١٨٠ × ٢٠٠'
      ],
      ku: [
        'قوماشی نانۆی هەناسەدەر',
        'چینی تایبەتی پاڵپشتی بڕبڕەی پشت',
        'سەرەوەی ئەوروپی',
        'پاڵپشتی سپرینی گیرفانی',
        'بەرزی ٢٥ سم · چوار قەبارە لە ١٠٠ × ٢٠٠ بۆ ١٨٠ × ٢٠٠'
      ]
    },
    layers: [
      {
        name: { en: 'Nano-knitted fabric', ar: 'قماش نانو مضغوط', ku: 'قوماشی نانۆ' },
        pos: { en: 'Top surface', ar: 'السطح العلوي', ku: 'ڕووی سەرەوە' },
        desc: {
          en: 'A fine nano-knitted cover that feels soft and allows air through — the breathable surface of the model.',
          ar: 'غطاء نانو مضغوط ناعم يسمح بمرور الهواء — وهو السطح القابل للتنفس في هذا النموذج.',
          ku: 'ڕووپۆشێکی نانۆی ناسک کە نەرمە و ڕێگە بە هەوا دەدات — ڕووی هەناسەدەری مۆدێلەکە.'
        }
      },
      {
        name: { en: 'Euro top', ar: 'سطح أوروبي', ku: 'سەرەوەی ئەوروپی' },
        pos: { en: 'Upper comfort', ar: 'الراحة العلوية', ku: 'ئاسوودەیی سەرەوە' },
        desc: {
          en: 'The Euro top adds a tailored comfort layer with a cleaner edge than a free pillow top, keeping the surface smooth at 25 cm.',
          ar: 'يضيف السطح الأوروبي طبقة راحة منظمة بحافة أنظف من سطح الوسادة الحر، فيبقى السطح ناعماً بارتفاع ٢٥ سم.',
          ku: 'سەرەوەی ئەوروپی چینێکی ئاسوودەیی ڕێک دەبەخشێت بە لاتەنیشتێکی پاکتر لە سەرینی ئازاد، بۆیە ڕووکە لە ٢٥ سم نەرم دەمێنێتەوە.'
        }
      },
      {
        name: { en: 'Specialised spine-support layer', ar: 'طبقة متخصصة لدعم العمود الفقري', ku: 'چینی تایبەتی پاڵپشتی بڕبڕەی پشت' },
        pos: { en: 'Comfort layer', ar: 'طبقة الراحة', ku: 'چینی ئاسوودەیی' },
        desc: {
          en: 'A dedicated support layer built to keep the spine in a level line — the reason Luna is our recommended model when back support is the priority.',
          ar: 'طبقة دعم مخصصة للحفاظ على استقامة العمود الفقري — وهي سبب كون لونا نموذجنا الموصى به عندما يكون دعم الظهر هو الأولوية.',
          ku: 'چینێکی پاڵپشتی تایبەت بۆ پاراستنی ڕاستی بڕبڕەی پشت — هۆکاری ئەوەیە کە لونا پێشنیاری سەرەکیمانە کاتێک پاڵپشتی پشت پێشینەیە.'
        }
      },
      {
        name: { en: 'Pocket spring unit', ar: 'وحدة نوابض جيبية', ku: 'یەکەی سپرینی گیرفانی' },
        pos: { en: 'Support core', ar: 'قلب الدعم', ku: 'ناوەندی پاڵپشتی' },
        desc: {
          en: 'The pocket spring core completes the support, working independently under each part of the body.',
          ar: 'يكمل قلب النوابض الجيبية الدعم، ويعمل باستقلال تحت كل جزء من الجسم.',
          ku: 'ناوەندی سپرینی گیرفانی پاڵپشتی تەواو دەکات و بە سەربەخۆیی لە ژێر هەر بەشێکی لەش کار دەکات.'
        }
      }
    ],
    score: {
      position: { side: 0.8, back: 0.96, stomach: 0.82, combination: 0.86 },
      comfort: 3.1,
      temp: { hot: 0.62, comfortable: 0.86, cold: 0.62, seasonal: 0.52 },
      physical: { pressure: 0.8, spine: 0.98, joint: 0.84, muscle: 0.66, general: 0.9 },
      materials: { natural: 0.3, memory: 0.25, pocket: 1, antibacterial: 0.3, cooling: 0.5, foam: 0.15 },
      extras: { motion: 0.85, breathable: 0.88, hotel: 0.4, extraSoft: 0.3, supportive: 0.98, seasonal: 0.4, antibacterial: 0.3 }
    }
  }
];

/* ---------- derived helpers ---------- */
window.PRODUCT_BY_ID = {};
window.PRODUCTS.forEach(function (p) {
  window.PRODUCT_BY_ID[p.id] = p;
  p.priceFrom = Math.min.apply(null, p.sizes.map(function (s) { return s.price; }));
  p.avgPrice = Math.round(p.sizes.reduce(function (a, s) { return a + s.price; }, 0) / p.sizes.length);
  p.priceTier = p.avgPrice < 700000 ? 1 : p.avgPrice < 1000000 ? 2 : p.avgPrice < 1600000 ? 3 : 4;
  p.hasSize = function (w, h) {
    return p.sizes.some(function (s) { return s.w === w && s.h === h; });
  };
});
