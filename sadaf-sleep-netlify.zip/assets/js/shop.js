/* ============================================================
   SADAF SLEEP — SHOP LOGIC
   Model cards · prices · the 5-slider mattress finder
   ============================================================ */
(function () {
  'use strict';

  var SHOP = window.SHOP = {};
  var SS = window.SS;

  /* ---------------- money ---------------- */
  SHOP.money = function (n) {
    return Number(n).toLocaleString('en-US') + ' ' + SS.t('common.currency');
  };

  /* ---------------- per-model feel scores (1 = low, 5 = high) --------------- */
  SHOP.ATTRS = {
    'silver-tech':    { firm: 4, cool: 2, contour: 2, support: 5, best: 'Back and stomach sleepers who want a firm, even surface' },
    'biolatex':       { firm: 2, cool: 3, contour: 5, support: 4, best: 'Side sleepers who want natural materials and a deep, soft hug' },
    'thermo-memory':  { firm: 2, cool: 5, contour: 5, support: 4, best: 'Anyone who sleeps hot and likes memory foam' },
    'four-seasons':   { firm: 3, cool: 4, contour: 3, support: 4, best: 'Erbil summers and cold winters in the same bed' },
    'biolux':         { firm: 2, cool: 2, contour: 4, support: 3, best: 'Couples who want a soft, quiet, hotel-like feel' },
    'neocomfort':     { firm: 3, cool: 4, contour: 5, support: 5, best: 'Back pain and hot sleepers who want foam support' },
    'rabbit-comfort': { firm: 2, cool: 2, contour: 4, support: 4, best: 'A soft first mattress, or a guest room' },
    'luxerest':       { firm: 2, cool: 4, contour: 3, support: 3, best: 'Small rooms and single beds on a budget' },
    'luna':           { firm: 4, cool: 3, contour: 2, support: 5, best: 'Firm support at the lowest price in the collection' }
  };

  var SIZES = [
    { w: 100, h: 200 }, { w: 120, h: 200 }, { w: 160, h: 200 },
    { w: 180, h: 200 }, { w: 200, h: 200 }
  ];
  SHOP.SIZES = SIZES;

  SHOP.sizeLabel = function (s) { return s.w + ' × ' + s.h; };

  /* price of a model for a given size, with a fallback to the nearest one */
  SHOP.priceFor = function (p, size) {
    var hit = p.sizes.filter(function (s) { return s.w === size.w && s.h === size.h; })[0];
    if (hit) return { price: hit.price, exact: true };
    var near = p.sizes.slice().sort(function (a, b) {
      return Math.abs(a.w - size.w) - Math.abs(b.w - size.w);
    })[0];
    return { price: near.price, exact: false, size: near };
  };

  /* ---------------- model card ---------------- */
  SHOP.card = function (p) {
    var a = SHOP.ATTRS[p.id] || {};
    var sizes = p.sizes.map(function (s) { return s.w; }).sort(function (x, y) { return x - y; });
    return '<a class="s-card" href="product.html?model=' + p.id + '">' +
      '<div class="s-card__media">' +
        '<span class="s-card__num">' + p.num + '</span>' +
        '<img src="' + SS.pimg(p) + '" alt="' + SS.L(p.name) + '" loading="lazy" width="976" height="397">' +
        '<span class="s-card__h">' + p.height + ' ' + SS.t('common.cm') + '</span>' +
      '</div>' +
      '<div class="s-card__body">' +
        '<h3 class="s-card__name">' + SS.L(p.name) + '</h3>' +
        '<p class="s-card__tag">' + SS.L(p.tagline) + '</p>' +
        '<div class="s-card__foot">' +
          '<span class="s-price"><small>From</small>' + SHOP.money(p.priceFrom) + '</span>' +
          '<span class="s-card__sizes">' + sizes.join(' / ') + ' ' + SS.t('common.cm') + '</span>' +
        '</div>' +
      '</div>' +
    '</a>';
  };

  SHOP.renderModels = function (el, list) {
    if (!el) return;
    el.innerHTML = list.map(function (p) { return SHOP.card(p); }).join('');
    if (SS.translateDom) SS.translateDom();
  };

  /* ---------------- supplied product photography ---------------- */
  SHOP.PHOTOS = {
    'silver-tech':    ['silver-tech-2', 'silver-tech-3'],
    'biolatex':       ['biolatex-2', 'biolatex-3'],
    'thermo-memory':  ['thermo-memory-2'],
    'four-seasons':   ['four-seasons-2', 'four-seasons-3'],
    'biolux':         ['biolux-2', 'biolux-3'],
    'neocomfort':     ['neocomfort-2', 'neocomfort-3'],
    'rabbit-comfort': ['rabbit-comfort-2', 'rabbit-comfort-3'],
    'luxerest':       ['luxerest-2', 'luxerest-3', 'luxerest-4'],
    'luna':           ['luna-2', 'luna-3']
  };

  /* ---------------- three "best for" lines per model ---------------- */
  SHOP.BEST = {
    'silver-tech': [
      'Back and stomach sleepers who want a firm, even surface',
      'Anyone who wants the cover to work against bacteria and dust mites',
      'Couples who want a double spring unit and strong edges'
    ],
    'biolatex': [
      'Side sleepers who need pressure relief under the shoulder',
      'Anyone who prefers natural latex and horsehair to foam',
      'People who sleep cool and dislike the sinking feel of memory foam'
    ],
    'thermo-memory': [
      'Hot sleepers who still want a soft, hugging surface',
      'Side sleepers with shoulder or hip pressure',
      'Anyone who wants cooling without giving up memory foam'
    ],
    'four-seasons': [
      'Erbil summers and cold winters in the same bed',
      'Couples who disagree about temperature at night',
      'Anyone who wants one mattress instead of a summer and winter pair'
    ],
    'biolux': [
      'Couples who want a soft, quiet, hotel-style bed',
      'Anyone who likes a silk-soft cover over pocket springs',
      'Guest rooms and second bedrooms that still get used'
    ],
    'neocomfort': [
      'Back-pain sleepers who want firm foam support',
      'Hot sleepers who do not want springs',
      'People who want a lower 25 cm bed frame profile'
    ],
    'rabbit-comfort': [
      'A first mattress or a guest room',
      'Soft-feel sleepers who want pocket springs at a lower price',
      'Side sleepers who want a plush surface without memory foam'
    ],
    'luxerest': [
      'Small rooms and single beds 100 or 120 cm wide',
      'Anyone who wants a breathable viscose cover on a budget',
      'Guest beds that need to stay cool between visits'
    ],
    'luna': [
      'Firm support at the lowest price in the collection',
      'Childrens rooms and single beds from 100 cm',
      'Anyone who wants a spine-support layer without a pillow top'
    ]
  };

  /* ---------------- finder ---------------- */
  var POSITIONS = [
    { id: 'side',    label: 'Side',    hint: 'Shoulder and hip pressure' },
    { id: 'back',    label: 'Back',    hint: 'Needs an even, level surface' },
    { id: 'stomach', label: 'Stomach', hint: 'Needs firm lift at the hips' },
    { id: 'mixed',   label: 'Mixed',   hint: 'You turn through the night' }
  ];

  var SIZE_CHOICES = [
    { w: 100, h: 200 }, { w: 120, h: 200 }, { w: 160, h: 200 },
    { w: 180, h: 200 }, { w: 200, h: 200 }
  ];

  var BUDGET_CHOICES = [
    { id: 'b1', max: 500000,  label: 'Under 500,000' },
    { id: 'b2', max: 1000000, label: '500,000 – 1,000,000' },
    { id: 'b3', max: 1600000, label: '1,000,000 – 1,600,000' },
    { id: 'b4', max: 99999999,label: '1,600,000 and above' }
  ];

  /* how well a model isolates a partner turning over, read off its spring system */
  function motionScore(p) {
    var t = ((p.springs && p.springs.en) || '').toLowerCase();
    if (t.indexOf('pocket') > -1) return 5;
    if (t.indexOf('bonnell') > -1) return 2;
    if (t.indexOf('double') > -1) return 2;
    if (t.indexOf('spring') > -1) return 4;
    return 4;
  }

  function clamp01(v) { return Math.max(0, Math.min(1, v)); }

  SHOP.rank = function (state) {
    return window.PRODUCTS.map(function (p) {
      var a = SHOP.ATTRS[p.id] || { firm: 3, cool: 3, contour: 3, support: 3 };
      var reasons = [];

      /* position: what that posture needs most */
      var posScore;
      if (state.pos === 'side')        posScore = (a.contour * .6 + a.support * .4) / 5;
      else if (state.pos === 'back')   posScore = (a.support * .55 + (5 - Math.abs(a.firm - 3.5)) * .45) / 5;
      else if (state.pos === 'stomach')posScore = (a.firm * .6 + a.support * .4) / 5;
      else                             posScore = 1 - Math.abs(a.contour - 3) * .12;
      posScore = clamp01(posScore);
      if (posScore > .78) {
        reasons.push(state.pos === 'side' ? 'gives at the shoulder' :
                     state.pos === 'stomach' ? 'resists at the hips' :
                     state.pos === 'back' ? 'holds the back level' : 'works for mixed sleepers');
      }

      /* firmness: 1 = very soft … 5 = firm */
      var firmScore = clamp01(1 - Math.abs(a.firm - state.firm) / 3);
      if (firmScore > .85) reasons.push('firmness close to what you asked for');

      /* temperature: 1 = always hot … 5 = always cold */
      var tempScore = clamp01(1 - Math.abs(a.cool - state.temp) / 3);
      if (state.temp >= 4 && a.cool >= 4) reasons.push('breathes for hot sleepers');

      /* body weight: heavier bodies need more support under them */
      var supportScore = clamp01(1 - Math.abs(a.support - state.weight) / 3);
      if (state.weight >= 4 && a.support >= 4) reasons.push('support for a heavier body');

      /* motion: how much a partner's movement reaches you */
      var m = motionScore(p);
      var motionFit = clamp01(1 - Math.abs(m - state.motion) / 3);
      if (state.motion >= 4 && m >= 4) reasons.push('quiet when your partner moves');

      /* size + budget: hard filters, shown as passes rather than points */
      var sizeOk = state.sizes.length === 0 || p.sizes.some(function (s) {
        return state.sizes.some(function (c) { return c.w === s.w && c.h === s.h; });
      });
      var chosenSize = (state.sizes[0]) || { w: 180, h: 200 };
      var price = SHOP.priceFor(p, chosenSize);
      var budgetOk = state.budgets.length === 0 || state.budgets.some(function (b) { return price.price <= b.max; });

      var score =
        posScore * 0.27 + firmScore * 0.23 + tempScore * 0.18 +
        supportScore * 0.14 + motionFit * 0.13 + (sizeOk ? 0.03 : 0) + (budgetOk ? 0.02 : 0);

      return {
        p: p, score: Math.round(clamp01(score) * 100),
        price: price, reasons: reasons.slice(0, 2),
        sizeOk: sizeOk, budgetOk: budgetOk
      };
    }).filter(function (r) { return r.sizeOk && r.budgetOk; })
      .sort(function (x, y) { return y.score - x.score; });
  };

  function resultCard(r, i, state) {
    var a = SHOP.ATTRS[r.p.id] || {};
    var media = (SHOP.PHOTOS[r.p.id] || [])[0] || null;
    return '<a class="f-res" href="product.html?model=' + r.p.id + '">' +
      '<div class="f-res__media">' +
        (i === 0 ? '<span class="f-res__tag">Best fit</span>' : '') +
        '<img src="' + (media ? 'assets/img/' + media + '.jpg' : SS.pimg(r.p)) + '" alt="" loading="lazy">' +
      '</div>' +
      '<div class="f-res__body">' +
        '<div class="f-res__top">' +
          '<h3 class="f-res__name">' + SS.L(r.p.name) + '</h3>' +
          '<span class="f-res__score">' + r.score + '<small>%</small></span>' +
        '</div>' +
        '<div class="f-res__bar"><i style="width:' + r.score + '%"></i></div>' +
        '<p class="f-res__why">' + (r.reasons.length ? r.reasons.map(SS.tx).join(' · ') : SS.tx('Closest overall balance')) + '</p>' +
        '<div class="f-res__foot">' +
          '<span class="f-res__price">' + SHOP.money(r.price.price) + '<small>' + SHOP.sizeLabel(r.price.size || state.sizes[0] || { w: 180, h: 200 }) + ' ' + SS.t('common.cm') + '</small></span>' +
          '<span class="f-res__meta">' + r.p.height + ' ' + SS.t('common.cm') + ' · ' + SS.L(r.p.mainTech) + '</span>' +
        '</div>' +
      '</div>' +
    '</a>';
  }

  function noteLine(state) {
    var size = state.sizes[0] ? SHOP.sizeLabel(state.sizes[0]) + ' cm' : '180 × 200 cm';
    var L = SS.lang();
    if (L === 'ar') return 'نسبة التوافق توزن وضعية النوم والصلابة والحرارة والدعم والحركة. تُقرأ الأسعار بمقاس ' + size + '.';
    if (L === 'ku') return 'ڕێژەی گونجان شێوازی نوستن و سەختی و گەرمی و پاڵپشتی و جووڵە هەڵدەسەنگێنێت. نرخەکان بۆ قەبارەی ' + size + ' هەژمار کراون.';
    return 'Fit % weighs posture, firmness, temperature, support and motion. Prices are read in ' + size + '.';
  }

  SHOP.finder = function (root) {
    if (!root) return;
    var state = {
      pos: 'back',
      firm: 3, temp: 3, weight: 3, motion: 3,
      sizes: [{ w: 180, h: 200 }],
      budgets: []
    };

    var posHTML = POSITIONS.map(function (o, i) {
      return '<button type="button" class="f-seg__btn' + (i === 1 ? ' is-on' : '') + '" data-pos="' + o.id + '">' +
        '<b>' + o.label + '</b><small>' + o.hint + '</small></button>';
    }).join('');

    var sizeHTML = SIZE_CHOICES.map(function (s) {
      var on = s.w === 180;
      return '<button type="button" class="s-chip' + (on ? ' is-on' : '') + '" data-size="' + s.w + 'x' + s.h + '" aria-pressed="' + on + '">' +
        '<span class="box"></span>' + s.w + ' × ' + s.h + '</button>';
    }).join('');

    var budgetHTML = BUDGET_CHOICES.map(function (b) {
      return '<button type="button" class="s-chip" data-budget="' + b.id + '" aria-pressed="false">' +
        '<span class="box"></span><span dir="ltr">' + b.label + '</span> <span class="cur">' + SS.t('common.currency') + '</span></button>';
    }).join('');

    function slider(id, step, num, title, hint, min, max, start, ends) {
      return '<div class="f-block">' +
        '<div class="f-block__head"><span class="f-step">' + num + '</span>' +
          '<div><h3>' + title + '</h3><p>' + hint + '</p></div></div>' +
        '<div class="s-slider">' +
          '<div class="s-slider__top">' +
            '<span class="s-slider__value" data-value="' + id + '"></span>' +
          '</div>' +
          '<input type="range" data-slider="' + id + '" min="' + min + '" max="' + max + '" step="' + step + '" value="' + start + '" aria-label="' + title + '">' +
          '<div class="f-ends"><span>' + ends[0] + '</span><span>' + ends[1] + '</span></div>' +
        '</div>' +
      '</div>';
    }

    root.innerHTML =
      '<div class="f-grid">' +
        '<div class="f-panel">' +
          '<div class="f-block">' +
            '<div class="f-block__head"><span class="f-step">01</span>' +
              '<div><h3>You sleep on your…</h3><p>Pick the position that is true on most nights.</p></div></div>' +
            '<div class="f-seg" id="fPos">' + posHTML + '</div>' +
          '</div>' +
          slider('firm', 1, '02', 'How firm do you like it?', 'Slide until it sounds like your bed.', 1, 5, 3, ['Very soft', 'Firm']) +
          slider('temp', 1, '03', 'How warm do you sleep?', 'Most people in Erbil answer “hot” in summer.', 1, 5, 3, ['Always cold', 'Always hot']) +
          slider('weight', 1, '04', 'Your body build', 'Heavier bodies ask more of the support layer.', 1, 5, 3, ['Light', 'Heavy']) +
          slider('motion', 1, '05', 'Does a partner wake you?', 'If you share the bed, how much do you feel them turn?', 1, 5, 3, ['Never', 'Every time']) +
          '<div class="f-block">' +
            '<div class="f-block__head"><span class="f-step">06</span>' +
              '<div><h3>Which sizes could work?</h3><p>Choose one or more — tick every size your room allows.</p></div></div>' +
            '<div class="s-chips" id="fSizes">' + sizeHTML + '</div>' +
          '</div>' +
          '<div class="f-block">' +
            '<div class="f-block__head"><span class="f-step">07</span>' +
              '<div><h3>Budget range</h3><p>Tick every band you would consider. Nothing is picked automatically.</p></div></div>' +
            '<div class="s-chips" id="fBudgets">' + budgetHTML + '</div>' +
            '<p class="f-hint" id="fBudgetHint">No band ticked — showing every price.</p>' +
          '</div>' +
        '</div>' +
        '<aside class="f-side">' +
          '<div class="f-side__card">' +
            '<span class="s-kicker">Your brief</span>' +
            '<h3 class="f-brief" id="fBrief">—</h3>' +
            '<ul class="f-brieflist" id="fBriefList"></ul>' +
          '</div>' +
          '<div class="f-side__results" id="fResults" aria-live="polite"></div>' +
        '</aside>' +
      '</div>';

    var results = root.querySelector('#fResults');
    var brief = root.querySelector('#fBrief');
    var briefList = root.querySelector('#fBriefList');
    var budgetHint = root.querySelector('#fBudgetHint');

    var FIRM = ['Very soft', 'Soft', 'Medium', 'Medium-firm', 'Firm'];
    var TEMP = ['Always cold', 'Cool', 'Neutral', 'Runs hot', 'Always hot'];
    var WEIGHT = ['Light', 'Slim', 'Average', 'Solid', 'Heavy'];
    var MOTION = ['Never', 'Rarely', 'Sometimes', 'Often', 'Every time'];

    function labelFor(id, v) {
      if (id === 'firm') return FIRM[v - 1];
      if (id === 'temp') return TEMP[v - 1];
      if (id === 'weight') return WEIGHT[v - 1];
      return MOTION[v - 1];
    }

    function trackFill(input) {
      var min = +input.min, max = +input.max, v = +input.value;
      input.style.setProperty('--fill', ((v - min) / (max - min)) * 100 + '%');
    }

    function briefLine(id) {
      var v = state[id];
      return '<li><span>' + id + '</span><b>' + labelFor(id, v) + '</b></li>';
    }

    function sync() {
      [].forEach.call(root.querySelectorAll('[data-slider]'), function (inp) {
        var id = inp.getAttribute('data-slider');
        state[id] = +inp.value;
        trackFill(inp);
        var valEl = root.querySelector('[data-value="' + id + '"]');
        if (valEl) valEl.textContent = labelFor(id, state[id]);
      });

      var posLabel = (POSITIONS.filter(function (o) { return o.id === state.pos; })[0] || POSITIONS[1]).label;
      var sizeTxt = state.sizes.length ? state.sizes.map(SHOP.sizeLabel).join(', ') + ' ' + SS.t('common.cm') : SS.tx('Any size');
      var budgetTxt = state.budgets.length
        ? 'up to ' + SHOP.money(Math.max.apply(null, state.budgets.map(function (b) { return b.max; })))
        : 'any budget';

      var firmTxt = SS.tx(FIRM[state.firm - 1]);
      var L = SS.lang();
      if (L === 'ar') {
        brief.textContent = 'تنام على ' + SS.tx(posLabel) + '، ' + firmTxt + '، ' + sizeTxt + '، ' + SS.tx(budgetTxt) + '.';
      } else if (L === 'ku') {
        brief.textContent = 'بە ' + SS.tx(posLabel) + ' دەخەویت، ' + firmTxt + '، ' + sizeTxt + '، ' + SS.tx(budgetTxt) + '.';
      } else {
        brief.textContent = posLabel + ' sleeper, ' + FIRM[state.firm - 1].toLowerCase() + ', ' + sizeTxt + ', ' + budgetTxt + '.';
      }
      briefList.innerHTML =
        '<li><span>Position</span><b>' + posLabel + '</b></li>' +
        briefLine('firm') +
        briefLine('temp') +
        briefLine('weight') +
        briefLine('motion') +
        '<li><span>Sizes</span><b>' + (state.sizes.length ? state.sizes.map(function (s) { return s.w + '×' + s.h; }).join(' · ') : 'Any') + '</b></li>' +
        '<li><span>Budget</span><b>' + (state.budgets.length ? budgetTxt.replace('up to ', '') : 'Any') + '</b></li>';

      budgetHint.textContent = state.budgets.length
        ? (SS.lang() === 'en'
            ? state.budgets.length + ' band' + (state.budgets.length > 1 ? 's' : '') + ' ticked — the price is read in your chosen size.'
            : (SS.lang() === 'ar'
                ? state.budgets.length + ' فئة محددة — يُقرأ السعر بمقاسك المختار.'
                : state.budgets.length + ' مەودا دیاریکراوە — نرخ بەپێی قەبارەی هەڵبژێردراوت پیشان دەدرێت.'))
        : SS.tx('No band ticked — showing every price.');

      var ranked = SHOP.rank(state);
      if (!ranked.length) {
        results.innerHTML =
          '<div class="f-empty">' +
            '<h3>Nothing fits those limits together</h3>' +
            '<p>Widen the sizes, add a budget band, or relax one slider.</p>' +
          '</div>';
        return;
      }
      results.innerHTML =
        '<div class="f-results__head">' +
          '<span class="s-kicker">' + ranked.length + ' match' + (ranked.length > 1 ? 'es' : '') + '</span>' +
          '<h2 class="f-results__title">' + (ranked.length === 1 ? 'One mattress fits' : 'Your best ' + Math.min(3, ranked.length) + ' mattresses') + '</h2>' +
        '</div>' +
        ranked.slice(0, 3).map(function (r, i) { return resultCard(r, i, state); }).join('') +
        '<p class="s-results__note">' + noteLine(state) + '</p>';
    }

    root.querySelector('#fPos').addEventListener('click', function (e) {
      var b = e.target.closest('[data-pos]');
      if (!b) return;
      state.pos = b.getAttribute('data-pos');
      [].forEach.call(this.children, function (c) { c.classList.toggle('is-on', c === b); });
      sync();
    });

    root.querySelector('#fSizes').addEventListener('click', function (e) {
      var b = e.target.closest('[data-size]');
      if (!b) return;
      var wh = b.getAttribute('data-size').split('x').map(Number);
      var label = SHOP.sizeLabel({ w: wh[0], h: wh[1] }) + ' cm';
      var wasOn = b.classList.contains('is-on');
      var target = SIZE_CHOICES.filter(function (s) { return s.w === wh[0] && s.h === wh[1]; })[0];
      if (wasOn) {
        state.sizes = state.sizes.filter(function (s) { return !(s.w === target.w && s.h === target.h); });
      } else {
        state.sizes = state.sizes.concat([{ w: target.w, h: target.h }]);
      }
      b.classList.toggle('is-on', !wasOn);
      b.setAttribute('aria-pressed', String(!wasOn));
      if (label) sync();
    });

    root.querySelector('#fBudgets').addEventListener('click', function (e) {
      var b = e.target.closest('[data-budget]');
      if (!b) return;
      var id = b.getAttribute('data-budget');
      var band = BUDGET_CHOICES.filter(function (x) { return x.id === id; })[0];
      var wasOn = b.classList.contains('is-on');
      state.budgets = wasOn
        ? state.budgets.filter(function (x) { return x.id !== id; })
        : state.budgets.concat([band]);
      b.classList.toggle('is-on', !wasOn);
      b.setAttribute('aria-pressed', String(!wasOn));
      sync();
    });

    [].forEach.call(root.querySelectorAll('[data-slider]'), function (inp) {
      inp.addEventListener('input', sync);
      inp.addEventListener('change', sync);
    });

    sync();
    if (SS.translateDom) SS.translateDom();
    return state;
  };

  /* ---------------- tiny accordion ---------------- */
  SHOP.accordion = function (root) {
    if (!root) return;
    root.addEventListener('click', function (e) {
      var btn = e.target.closest('.s-faq__q');
      if (!btn) return;
      var item = btn.parentElement;
      var open = item.classList.contains('is-open');
      [].forEach.call(root.querySelectorAll('.s-faq__item'), function (x) { x.classList.remove('is-open'); });
      if (!open) item.classList.add('is-open');
      btn.setAttribute('aria-expanded', String(!open));
    });
  };
})();
